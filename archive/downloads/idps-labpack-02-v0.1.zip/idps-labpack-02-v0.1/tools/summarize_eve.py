#!/usr/bin/env python3
import json, sys
from collections import Counter

if len(sys.argv) != 2:
    print("usage: summarize_eve.py /path/to/eve.json", file=sys.stderr)
    raise SystemExit(2)

counts = Counter()
alerts = []
with open(sys.argv[1], "r", encoding="utf-8") as fh:
    for line in fh:
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("event_type") != "alert":
            continue
        sid = event.get("alert", {}).get("signature_id")
        if sid in {2000001, 2000002, 2000003}:
            counts[sid] += 1
            alerts.append((sid, event.get("src_ip"), event.get("dest_ip"), event.get("dest_port")))

print("LAB2 alert counts")
for sid in (2000001, 2000002, 2000003):
    print(f"SID {sid}: {counts[sid]}")
print("Matched alerts")
for item in alerts:
    print(item)
