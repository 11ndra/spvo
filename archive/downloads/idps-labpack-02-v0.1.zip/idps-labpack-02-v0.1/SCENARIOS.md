# Lab 02 scenario matrix

| PCAP | Class | Purpose |
|---|---|---|
| `01-normal-root.pcap` | normal | GET / |
| `02-attack-passwd.pcap` | attack-like | traversal-like URI targeting etc/passwd |
| `03-benign-navigation.pcap` | benign-like | URI contains ../ but represents navigation inside web content |
| `04-body-marker.pcap` | normal-for-uri-use-case | ../ exists in HTTP request body, not URI |
| `05-variant-authlog.pcap` | attack-like | same behavior, different sensitive target |

`00-all-cases.pcap` contains all five TCP/HTTP sessions in one capture.
