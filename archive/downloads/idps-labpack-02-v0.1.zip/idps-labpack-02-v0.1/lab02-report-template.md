# ЛР №2 — отчёт

Режим выполнения: Live / Offline PCAP / Browser Accessibility

## Detection hypothesis
Какое поведение мы пытаемся обнаружить?
Какой observable используется?
Почему выбран именно этот network representation / buffer?

## Regression matrix
| Case | Rule A | Rule B | Rule C | TP/FP/TN/FN | Комментарий |
|---|---|---|---|---|---|
| T1 normal root | | | | | |
| T2 attack passwd | | | | | |
| T3 benign navigation | | | | | |
| T4 body marker | | | | | |
| T5 variant auth.log | | | | | |

## Выводы
1. Какой FP устранило использование HTTP URI buffer?
2. Какой FP остался после Rule B?
3. Почему Rule C создаёт новый FN?
4. Какой use case вы бы зафиксировали перед дальнейшим tuning?
5. Какое дополнительное наблюдение помогло бы отличить benign navigation от attack-like traversal?
6. Какие ограничения есть у выбранного режима выполнения?
