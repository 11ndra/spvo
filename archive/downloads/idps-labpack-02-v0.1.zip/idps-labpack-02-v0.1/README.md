# IDPS Lab Pack 02 v0.1

Offline test corpus for Lab №2 — Network Detection Engineering.

Contents:
- `pcaps/00-all-cases.pcap` — all five cases;
- `pcaps/01-...05-...` — one case per PCAP;
- `rules/starter.rules` — deliberately broad starter rule (SID 2000001);
- `tools/summarize_eve.py` — counts selected LAB2 SIDs in EVE JSON;
- `SCENARIOS.md` — scenario labels.

The PCAPs contain synthetic, non-exploit HTTP traffic only.
The pack does not contain finished student solutions for Rule B / Rule C.
