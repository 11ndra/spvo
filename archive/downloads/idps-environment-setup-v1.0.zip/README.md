# IDPS Environment Setup v1.0

Набор вспомогательных скриптов для самостоятельной подготовки двух VM курса.

- `bootstrap-client.sh` — ставит системные пакеты на Ubuntu Desktop.
- `bootstrap-server.sh` — ставит системные пакеты на Ubuntu Server и включает auditd/SSH.
- `show-network-candidates.sh` — показывает интерфейсы и маршрут по умолчанию; ничего не изменяет.
- `check-client-environment.sh` — проверяет адрес, команды и связь с сервером.
- `check-server-environment.sh` — проверяет адрес, Suricata, Linux Audit и связь с клиентом.

Скрипты намеренно НЕ создают VM и НЕ выбирают сетевой интерфейс за студента. Настройка двух адаптеров и статических адресов остаётся частью подготовки среды.
