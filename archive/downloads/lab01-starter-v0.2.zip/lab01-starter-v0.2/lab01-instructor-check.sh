#!/usr/bin/env bash
set -euo pipefail
if [[ ${EUID} -ne 0 ]]; then echo 'Run with sudo/root.' >&2; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RULES="${SCRIPT_DIR}/lab01.rules"
CONF="/etc/suricata/suricata.yaml"
OUT="/tmp/idps-lab01-instructor-check"
SURICATA_PID=""
SURICATA_WAS_ACTIVE=0
cleanup(){
  set +e
  [[ -n "$SURICATA_PID" ]] && kill "$SURICATA_PID" >/dev/null 2>&1
  wait "$SURICATA_PID" >/dev/null 2>&1 || true
  if [[ "$SURICATA_WAS_ACTIVE" -eq 1 ]]; then systemctl start suricata >/dev/null 2>&1 || true; fi
}
trap cleanup EXIT

bash "${SCRIPT_DIR}/lab01-preflight.sh"
if systemctl is-active --quiet suricata 2>/dev/null; then SURICATA_WAS_ACTIVE=1; systemctl stop suricata; fi
rm -rf "$OUT"; mkdir -p "$OUT"
suricata -k none -c "$CONF" -S "$RULES" -i lab-client0 -l "$OUT" >"$OUT/suricata-console.log" 2>&1 &
SURICATA_PID=$!
for _ in $(seq 1 30); do
  [[ -f "$OUT/eve.json" ]] && break
  kill -0 "$SURICATA_PID" 2>/dev/null || { echo '[FAIL] Suricata exited early'; cat "$OUT/suricata-console.log"; exit 1; }
  sleep 0.2
done

ip netns exec idps-client curl -sS 'http://10.13.37.20:8080/normal' >/dev/null
sleep 0.5
if jq -e 'select(.event_type=="alert" and .alert.signature_id==1000001)' "$OUT/eve.json" >/dev/null 2>&1; then
  echo '[FAIL] SID 1000001 fired on negative request'; exit 1
fi

ip netns exec idps-client curl -sS 'http://10.13.37.20:8080/ATTACK-LAB' >/dev/null
POS=0
for _ in $(seq 1 30); do
  if jq -e 'select(.event_type=="alert" and .alert.signature_id==1000001)' "$OUT/eve.json" >/dev/null 2>&1; then POS=1; break; fi
  sleep 0.2
done
[[ "$POS" -eq 1 ]] || { echo '[FAIL] SID 1000001 not found after positive request'; exit 1; }

echo '[PASS] Negative request did not trigger SID 1000001.'
echo '[PASS] Positive request triggered SID 1000001.'
echo 'LAB 1 END-TO-END SMOKE TEST PASSED.'
