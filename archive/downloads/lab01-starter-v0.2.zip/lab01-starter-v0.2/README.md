# Материалы ЛР №1 v0.2

- `lab01.rules` — готовое правило Suricata;
- `lab01-report.md` — шаблон отчёта;
- `lab01-preflight.sh` — обязательная проверка готовности VM;
- `lab01-instructor-check.sh` — end-to-end smoke test для преподавателя.

Работа рассчитана на Ubuntu 24.04 LTS в полноценной VM с поддержкой Linux network namespaces.
