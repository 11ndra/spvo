#!/usr/bin/env bash
set -u

if [[ ${EUID} -ne 0 ]]; then
  echo '[FAIL] Run: sudo bash starter/lab01-preflight.sh' >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RULES="${SCRIPT_DIR}/lab01.rules"
CONF="/etc/suricata/suricata.yaml"
fail=0
ok(){ printf '[ OK ] %s\n' "$1"; }
warn(){ printf '[WARN] %s\n' "$1"; }
bad(){ printf '[FAIL] %s\n' "$1"; fail=1; }

for cmd in ip python3 curl jq tcpdump suricata ethtool; do
  if command -v "$cmd" >/dev/null 2>&1; then ok "command: $cmd"; else bad "missing command: $cmd"; fi
done
[[ -f "$CONF" ]] && ok "Suricata config: $CONF" || bad "missing $CONF"
[[ -f "$RULES" ]] && ok "lab rule: $RULES" || bad "missing $RULES"

for ns in idps-client idps-web; do
  if ip netns list 2>/dev/null | awk '{print $1}' | grep -qx "$ns"; then ok "network namespace: $ns"; else bad "network namespace not found: $ns"; fi
done
if ip link show lab-client0 >/dev/null 2>&1; then ok 'interface: lab-client0'; else bad 'interface not found: lab-client0'; fi

if ip netns exec idps-client curl -fsS --max-time 2 http://10.13.37.20:8080/ >/dev/null 2>&1; then
  ok 'HTTP path idps-client -> idps-web:8080'
else
  bad 'HTTP path is not ready; rerun labbox/scripts/lab-init.sh and lab-status.sh'
fi

if [[ -x "$(command -v suricata 2>/dev/null || true)" && -f "$CONF" && -f "$RULES" ]]; then
  if suricata -T -c "$CONF" -S "$RULES" >/tmp/lab01-suricata-test.log 2>&1; then
    ok 'Suricata configuration + lab01.rules'
  else
    bad 'Suricata configuration test failed; see /tmp/lab01-suricata-test.log'
  fi
fi

if command -v ethtool >/dev/null 2>&1 && ip link show lab-client0 >/dev/null 2>&1; then
  offload_bad=0
  while IFS= read -r line; do
    case "$line" in
      *"generic-receive-offload: on"*|*"generic-segmentation-offload: on"*|*"tcp-segmentation-offload: on"*|*"large-receive-offload: on"*) offload_bad=1 ;;
    esac
  done < <(ethtool -k lab-client0 2>/dev/null || true)
  if [[ $offload_bad -eq 0 ]]; then
    ok 'GRO/GSO/TSO/LRO are disabled on lab-client0 or reported unsupported'
  else
    bad 'virtual-interface offloading is still enabled on lab-client0; rerun LabBox v0.2 init and inspect ethtool output'
  fi
fi

printf '\n'
if [[ $fail -eq 0 ]]; then
  echo 'PRE-FLIGHT PASSED: the VM is ready for Lab 1.'
else
  echo 'PRE-FLIGHT FAILED: fix the items above before starting the experiment.'
fi
exit "$fail"
