#!/usr/bin/env bash
set -u
fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }

for cmd in ip curl; do
  command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"
done

ip -o -4 addr show | grep -q '10\.13\.37\.10/' && ok 'учебный адрес 10.13.37.10 присутствует' || bad 'нет адреса 10.13.37.10/24'

if curl -fsS --max-time 3 http://10.13.37.20:8080/client-check >/dev/null 2>&1; then
  ok 'web-сервис idps-server доступен по TCP/8080'
else
  bad 'не удаётся обратиться к 10.13.37.20:8080'
fi

if [[ $fail -eq 0 ]]; then
  echo 'CLIENT CHECK PASSED.'
else
  echo 'CLIENT CHECK FAILED.'
fi
exit $fail
