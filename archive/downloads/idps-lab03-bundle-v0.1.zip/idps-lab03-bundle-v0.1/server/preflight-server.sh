#!/usr/bin/env bash
set -u

if [[ $EUID -ne 0 ]]; then
  echo '[FAIL] Запустите скрипт через sudo.' >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }

for cmd in ip curl jq tcpdump timeout suricata; do
  command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"
done

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip route show default | awk '/^default / {print $5; exit}')"

[[ -n "$LAB_IFACE" ]] && ok "учебный интерфейс: $LAB_IFACE" || bad 'не найден интерфейс с 10.13.37.20/24'
[[ -n "$NAT_IFACE" ]] && ok "NAT/default-route интерфейс: $NAT_IFACE" || bad 'не найден интерфейс маршрута по умолчанию'
if [[ -n "$LAB_IFACE" && -n "$NAT_IFACE" ]]; then
  [[ "$LAB_IFACE" != "$NAT_IFACE" ]] && ok 'учебный и NAT-интерфейсы различаются' || bad 'учебный и NAT-интерфейсы совпадают'
fi

systemctl is-active --quiet idps-lab-web.service && ok 'учебный web-сервис запущен' || bad 'idps-lab-web.service не запущен'
curl -fsS http://127.0.0.1:8080/health >/dev/null 2>&1 && ok 'локальный HTTP-сервис отвечает' || bad 'локальный HTTP-сервис не отвечает'
[[ -f /var/tmp/idps-lab/lab3-access.log ]] && ok 'журнал приложения существует' || bad 'нет /var/tmp/idps-lab/lab3-access.log'

[[ -f /etc/suricata/suricata.yaml ]] && ok 'конфигурация Suricata существует' || bad 'нет /etc/suricata/suricata.yaml'
if command -v suricata >/dev/null 2>&1 && [[ -f /etc/suricata/suricata.yaml ]]; then
  if suricata -T -c /etc/suricata/suricata.yaml -S "$SCRIPT_DIR/lab03.rules" >/tmp/lab03-suricata-test.log 2>&1; then
    ok 'Suricata принимает конфигурацию и lab03.rules'
  else
    bad 'проверка Suricata не пройдена; см. /tmp/lab03-suricata-test.log'
  fi
fi

if [[ $fail -eq 0 ]]; then
  echo 'SERVER PRE-FLIGHT PASSED.'
else
  echo 'SERVER PRE-FLIGHT FAILED.'
fi
exit $fail
