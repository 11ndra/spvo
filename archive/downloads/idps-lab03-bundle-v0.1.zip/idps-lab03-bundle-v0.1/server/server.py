#!/usr/bin/env python3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os

LOG_DIR = Path('/var/tmp/idps-lab')
ACCESS_LOG = LOG_DIR / 'lab3-access.log'

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        line = (
            f"timestamp={datetime.now(timezone.utc).isoformat()} "
            f"client={self.client_address[0]} method=GET path={self.path}\n"
        )
        with ACCESS_LOG.open('a', encoding='utf-8') as fh:
            fh.write(line)

        body = (
            "IDPS Lab 3 request received\n"
            f"path={self.path}\n"
        ).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return

PORT = int(os.environ.get('IDPS_LAB_PORT', '8080'))
ThreadingHTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
