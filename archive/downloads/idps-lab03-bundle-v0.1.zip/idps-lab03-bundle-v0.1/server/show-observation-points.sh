#!/usr/bin/env bash
set -euo pipefail

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip route show default | awk '/^default / {print $5; exit}')"

if [[ -z "$LAB_IFACE" ]]; then
  echo '[FAIL] Не найден интерфейс с адресом 10.13.37.20/24.' >&2
  exit 1
fi
if [[ -z "$NAT_IFACE" ]]; then
  echo '[FAIL] Не найден интерфейс маршрута по умолчанию (NAT).' >&2
  exit 1
fi
if [[ "$LAB_IFACE" == "$NAT_IFACE" ]]; then
  echo '[FAIL] Учебный и NAT-интерфейс совпали. Проверьте сетевую конфигурацию VM.' >&2
  exit 1
fi

printf 'LAB_IFACE=%s\n' "$LAB_IFACE"
printf 'NAT_IFACE=%s\n' "$NAT_IFACE"
echo
echo 'Краткое состояние интерфейсов:'
ip -br addr show | sed -n "1p; /${LAB_IFACE}/p; /${NAT_IFACE}/p"
