#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo '[FAIL] Запустите скрипт через sudo.' >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! ip -o -4 addr show | grep -q '10\.13\.37\.20/'; then
  echo '[FAIL] На этой VM нет ожидаемого учебного адреса 10.13.37.20/24.' >&2
  ip -br addr
  exit 1
fi

for cmd in python3 curl; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "[FAIL] Не найдена команда: $cmd" >&2; exit 1; }
done

install -d /opt/idps-lab /var/tmp/idps-lab
install -m 0755 "$SCRIPT_DIR/server.py" /opt/idps-lab/lab3-server.py
: > /var/tmp/idps-lab/lab3-access.log
chmod 0644 /var/tmp/idps-lab/lab3-access.log

cat >/etc/systemd/system/idps-lab-web.service <<'UNIT'
[Unit]
Description=IDPS course laboratory web service
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/idps-lab/lab3-server.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable idps-lab-web.service >/dev/null 2>&1 || true
systemctl restart idps-lab-web.service
sleep 1

if ! curl -fsS http://127.0.0.1:8080/health >/dev/null; then
  echo '[FAIL] Учебный web-сервис не отвечает на 127.0.0.1:8080.' >&2
  systemctl status idps-lab-web.service --no-pager || true
  exit 1
fi

echo '[ OK ] Учебный web-сервис доступен на TCP/8080.'
echo '[ OK ] Журнал запросов: /var/tmp/idps-lab/lab3-access.log'
