# IDPS Lab 03 bundle v0.1

ЛР №3 демонстрирует влияние точки наблюдения на доступность сетевого события.

Основная среда:
- idps-client — 10.13.37.10/24;
- idps-server — 10.13.37.20/24;
- отдельный NAT-интерфейс на каждой VM;
- учебная сеть IDPS-LAB.

Порядок начала на idps-server:

```bash
sudo bash server/setup-server.sh
sudo bash server/preflight-server.sh
bash server/show-observation-points.sh
```

На idps-client:

```bash
bash client/check-client.sh
```

Продолжать эксперимент следует только после `SERVER PRE-FLIGHT PASSED.` и `CLIENT CHECK PASSED.`.
