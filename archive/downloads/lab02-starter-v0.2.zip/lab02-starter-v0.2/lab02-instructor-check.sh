#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo 'Run with sudo/root.' >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RULES="${SCRIPT_DIR}/lab02.rules"
CONF="/etc/suricata/suricata.yaml"
OUT="/tmp/idps-lab02-instructor-check"
AUDIT_KEY="idps_lab_host"
AUDIT_DIR="/var/tmp/idps-lab/"
SURICATA_PID=""
SURICATA_WAS_ACTIVE=0

cleanup() {
  set +e
  [[ -n "$SURICATA_PID" ]] && kill "$SURICATA_PID" >/dev/null 2>&1
  wait "$SURICATA_PID" >/dev/null 2>&1 || true
  auditctl -D -k "$AUDIT_KEY" >/dev/null 2>&1 || true
  if [[ "$SURICATA_WAS_ACTIVE" -eq 1 ]]; then
    systemctl start suricata >/dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

bash "${SCRIPT_DIR}/lab02-preflight.sh"

mkdir -p "$AUDIT_DIR"
rm -f "${AUDIT_DIR}/lab2-evidence.txt"
auditctl -D -k "$AUDIT_KEY" >/dev/null 2>&1 || true
auditctl -a always,exit -F arch=b64 -F dir="$AUDIT_DIR" -F perm=wa -F key="$AUDIT_KEY"

if systemctl is-active --quiet suricata 2>/dev/null; then
  SURICATA_WAS_ACTIVE=1
  systemctl stop suricata
fi

rm -rf "$OUT"
mkdir -p "$OUT"

# -k none is deliberate for this virtual-veth lab only. It avoids checksum
# artefacts caused by virtual-interface offloading from invalidating the smoke test.
suricata -k none -c "$CONF" -S "$RULES" -i lab-client0 -l "$OUT" >"$OUT/suricata-console.log" 2>&1 &
SURICATA_PID=$!

for _ in $(seq 1 30); do
  [[ -f "$OUT/eve.json" ]] && break
  kill -0 "$SURICATA_PID" 2>/dev/null || { echo '[FAIL] Suricata exited early'; cat "$OUT/suricata-console.log"; exit 1; }
  sleep 0.2
done

ip netns exec idps-client curl -fsS \
  'http://10.13.37.20:8080/lab2-trigger?marker=LAB2-NET' >"$OUT/http-response.txt"

NET_OK=0
for _ in $(seq 1 30); do
  if [[ -f "$OUT/eve.json" ]] && jq -e 'select(.event_type=="alert" and .alert.signature_id==1000002)' "$OUT/eve.json" >/dev/null 2>&1; then
    NET_OK=1; break
  fi
  sleep 0.2
done
[[ "$NET_OK" -eq 1 ]] || { echo '[FAIL] SID 1000002 not found'; exit 1; }

HOST_OK=0
for _ in $(seq 1 30); do
  if ausearch -k "$AUDIT_KEY" -ts recent -i 2>/dev/null | grep -Fq 'lab2-evidence.txt'; then
    HOST_OK=1; break
  fi
  sleep 0.2
done
[[ "$HOST_OK" -eq 1 ]] || { echo '[FAIL] Linux Audit event for lab2-evidence.txt not found'; exit 1; }

[[ -f "${AUDIT_DIR}/lab2-evidence.txt" ]] || { echo '[FAIL] application side effect file not created'; exit 1; }

echo '[PASS] Network alert SID 1000002 observed.'
echo '[PASS] Linux Audit observed the local file operation.'
echo '[PASS] Application side-effect file exists.'
echo 'LAB 2 END-TO-END SMOKE TEST PASSED.'
