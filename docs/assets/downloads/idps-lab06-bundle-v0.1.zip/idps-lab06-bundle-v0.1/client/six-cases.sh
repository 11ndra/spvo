#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
LABEL="${1:-}"
if [[ "$LABEL" != insecure && "$LABEL" != secure ]]; then
  echo 'Usage: bash client/six-cases.sh insecure|secure' >&2
  exit 2
fi
TARGET='http://10.13.37.20:18086'
mkdir -p "evidence/response-${LABEL}"
probe() {
  local trial="$1" token="$2" resource="$3"
  printf '%s ' "$trial"
  curl --noproxy '*' --connect-timeout 3 --max-time 8 -sS \
    -H "Authorization: Bearer ${token}" \
    -o "evidence/response-${LABEL}/${trial}.json" \
    -w 'HTTP %{http_code}\n' "${TARGET}${resource}"
}
probe A alice-demo '/public?trial=A'
probe B alice-demo '/api/tickets?id=1001&trial=B'
probe C alice-demo '/api/tickets?id=2002&trial=C'
probe D alice-demo '/api/archive?id=2002&trial=D'
probe E bob-demo '/api/tickets?id=2002&trial=E'
probe F bob-demo '/api/archive?id=2002&trial=F'
