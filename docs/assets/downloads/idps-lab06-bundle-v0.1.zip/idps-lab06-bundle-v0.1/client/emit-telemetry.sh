#!/usr/bin/env bash
set -euo pipefail
TARGET='http://10.13.37.20:18086'
for source in mobile iot; do
  echo "Source: $source"
  curl --noproxy '*' --connect-timeout 3 --max-time 8 -sS \
    -X POST -H 'Content-Type: application/json' \
    -d "{\"event\":\"lab6-training-$source\",\"value\":1}" \
    "${TARGET}/api/telemetry?source=${source}&trial=TEL-${source}"
  echo
done
