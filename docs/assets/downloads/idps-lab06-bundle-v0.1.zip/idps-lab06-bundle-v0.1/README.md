# IDPS Lab06 v0.1 — integrated assessment (training only)

Separate scenario. Does NOT install or modify Lab01–Lab05, :8080, :9090, Suricata system config or existing rules. Server is standard-library Python bound to lab IP 10.13.37.20 on port 18086 only by `server/start-case.sh`. `secure`/`insecure` modes are deliberately different for educational authorization comparison.

## Start

On idps-server: `bash server/start-case.sh insecure`. Keep it running, stop with Ctrl+C. On idps-client: `bash client/six-cases.sh insecure`. Repeat only as directed in the website instructions. All six HTTP responses are written on the *client*. Application JSONL is written in `evidence/` on the *server*.

Server requires Python3 and `ip`. Client requires curl. Capture and replay require existing tcpdump/Suricata/jq; scanning with Nmap if installed. Do not install software or modify VirtualBox NIC types from this package.

Interactive practice in the client browser: `http://10.13.37.20:18086/board`. UI-marked trials use `UI-*`, unlike canonical A–F from `six-cases.sh` and cannot replace PCAP/EVE evidence.

## Files

- `server/board.html`: interactive hypothesis/HTTP testing UI, no external libraries.
- `server/lab6_case.py`: classroom case server and local JSONL evidence (no token contents logged).
- `server/start-case.sh`: exact lab-IP binding and mode selection.
- `server/lab06-v1.rules`: original intentionally broad detection logic; **keep unchanged** when developing v2.
- `client/six-cases.sh`: six real tagged HTTP requests A–F; preserves responses.
- `client/emit-telemetry.sh`: two simulated-source but real HTTP requests.
- `tools/evidence_matrix.py`: joins local app journal with EVE alerts using URI `trial=`; no fabricated results.
- `offline/*`: synthetic sources, **not** produced by the student's real VMs.
- `report/lab06-report.md`: deliverable template, 13 checkpoints.

Do not use this deliberately insecure service on a network accessible by strangers, on a public host or with real secrets. The lab is designed only for assigned VirtualBox Host-Only VMs.
