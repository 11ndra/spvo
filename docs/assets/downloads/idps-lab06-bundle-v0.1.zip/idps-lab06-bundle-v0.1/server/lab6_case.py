#!/usr/bin/env python3
"""Isolated educational HTTP case. Never deploy outside a private lab."""
import argparse
import hashlib
import json
import pathlib
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

OWNERS = {"1001": "alice", "2002": "bob"}
DATA = {
    "1001": {"ticket": "TRAIN-1001", "owner": "alice", "subject": "Test workstation"},
    "2002": {"ticket": "TRAIN-2002", "owner": "bob", "subject": "Test inventory"},
}
TOKENS = {"alice-demo": "alice", "bob-demo": "bob"}


def make_handler(out_file, secure):
    write_lock = threading.Lock()

    class CaseHandler(BaseHTTPRequestHandler):
        server_version = "IDPS-Lab06/0.1"

        def log_message(self, *_args):
            return  # Request metadata is recorded in the lab JSONL instead.

        def respond(self, code, obj, path, actor, trial, owner=None, source=None, digest=None):
            body = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
            event = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "src_ip": self.client_address[0],
                "method": self.command,
                "uri": path,
                "trial": trial,
                "actor": actor,
                "owner": owner,
                "http_status": code,
                "mode": "secure" if secure else "insecure",
            }
            if source is not None:
                event["telemetry_source"] = source
            if digest is not None:
                event["payload_sha256"] = digest
            with write_lock:
                with open(out_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def actor(self):
            auth = self.headers.get("Authorization", "")
            if not auth.startswith("Bearer "):
                return None
            return TOKENS.get(auth[7:])

        def do_GET(self):
            url = urlsplit(self.path)
            qs = parse_qs(url.query, keep_blank_values=True)
            trial = qs.get("trial", [""])[0][:64]
            actor = self.actor()
            endpoint = url.path
            if endpoint == "/board":
                body = pathlib.Path(__file__).with_name("board.html").read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)
                return
            if endpoint in ("/", "/health", "/public"):
                self.respond(200, {"service": "lab06", "endpoint": endpoint, "scope": "local training only",
                                   "mode": "secure" if secure else "insecure"}, self.path, actor, trial)
                return
            if endpoint == "/robots.txt":
                self.respond(200, {"note": "training discovery", "path": "/api/tickets"}, self.path, actor, trial)
                return
            if endpoint in ("/api/tickets", "/api/archive"):
                item = qs.get("id", [""])[0]
                owner = OWNERS.get(item)
                if not actor:
                    self.respond(401, {"error": "demo token required"}, self.path, actor, trial, owner)
                elif not owner:
                    self.respond(404, {"error": "training object not found"}, self.path, actor, trial)
                elif secure and actor != owner:
                    self.respond(403, {"error": "access denied"}, self.path, actor, trial, owner)
                else:
                    result = DATA[item] if endpoint == "/api/tickets" else {"export": "TRAINING-ONLY", "ticket": DATA[item]["ticket"], "owner": owner}
                    self.respond(200, result, self.path, actor, trial, owner)
                return
            self.respond(404, {"error": "not found"}, self.path, actor, trial)

        def do_POST(self):
            url = urlsplit(self.path)
            qs = parse_qs(url.query)
            trial = qs.get("trial", [""])[0][:64]
            source = qs.get("source", [""])[0]
            actor = self.actor()
            if url.path != "/api/telemetry" or source not in ("iot", "mobile"):
                self.respond(404, {"error": "unknown source or endpoint"}, self.path, actor, trial)
                return
            try:
                length = int(self.headers.get("Content-Length", "-1"))
                if not 0 < length <= 4096:
                    raise ValueError("size")
                payload = self.rfile.read(length)
                parsed = json.loads(payload)
                if not isinstance(parsed, dict) or "event" not in parsed:
                    raise ValueError("schema")
            except (ValueError, json.JSONDecodeError):
                self.respond(400, {"error": "invalid telemetry"}, self.path, actor, trial, source=source)
                return
            self.respond(202, {"accepted": True, "source": source}, self.path, actor, trial,
                         source=source, digest=hashlib.sha256(payload).hexdigest())

    return CaseHandler


def main():
    parser = argparse.ArgumentParser(description="IDPS Lab06 isolated target")
    parser.add_argument("--listen", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18086)
    parser.add_argument("--out", required=True)
    parser.add_argument("--secure", action="store_true")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("use an unprivileged TCP port")
    p = pathlib.Path(args.out)
    p.parent.mkdir(parents=True, exist_ok=True)
    with ThreadingHTTPServer((args.listen, args.port), make_handler(str(p), args.secure)) as server:
        print(f"LAB06 READY {args.listen}:{args.port} secure={args.secure}; events={p}", flush=True)
        try:
            server.serve_forever(poll_interval=0.2)
        except KeyboardInterrupt:
            print("LAB06 STOPPED", flush=True)


if __name__ == "__main__":
    main()
