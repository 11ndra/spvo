#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
MODE="${1:-}"
if [[ "$MODE" != insecure && "$MODE" != secure ]]; then
  echo 'Usage: bash server/start-case.sh insecure|secure' >&2
  exit 2
fi
if ! ip -o -4 addr show | grep -Fq '10.13.37.20/'; then
  echo '[STOP] The expected private lab address 10.13.37.20 is not configured.' >&2
  exit 1
fi
ARGS=()
if [[ "$MODE" == secure ]]; then ARGS+=(--secure); fi
printf 'Mode: %s. Stop with Ctrl+C. Existing ports 8080/9090 are untouched.\n' "$MODE"
exec python3 -u server/lab6_case.py --listen 10.13.37.20 --port 18086 --out "evidence/${MODE}.jsonl" "${ARGS[@]}"
