#!/usr/bin/env python3
"""Local loopback smoke test for the educational application only (NOT Suricata/VM QA)."""
import json
import pathlib
import socket
import subprocess
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = pathlib.Path(__file__).resolve().parents[1]


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def request(url, token=None, data=None):
    hdr = {"Authorization": f"Bearer {token}"} if token else {}
    if data is not None:
        hdr["Content-Type"] = "application/json"
    req = Request(url, headers=hdr, data=data)
    try:
        with urlopen(req, timeout=3) as response:
            return response.status, json.loads(response.read())
    except HTTPError as ex:
        return ex.code, json.loads(ex.read())


def run(secure, out):
    port = free_port()
    args = [sys.executable, str(ROOT / 'server/lab6_case.py'), '--listen', '127.0.0.1', '--port', str(port), '--out', str(out)]
    if secure:
        args.append('--secure')
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        base = f'http://127.0.0.1:{port}'
        for _ in range(50):
            try:
                assert request(base + '/health')[0] == 200
                break
            except (URLError, ConnectionError):
                time.sleep(.05)
        else:
            raise AssertionError('server not reachable')
        with urlopen(base+'/board', timeout=3) as response:
            board = response.read().decode('utf-8')
            assert response.status == 200 and 'Авторизация и доказательства' in board
        def check(path, token, expected):
            status, _ = request(base + path, token)
            assert status == expected, (path, status, expected)
        check('/public?trial=A', 'alice-demo', 200)
        check('/api/tickets?id=1001&trial=B', 'alice-demo', 200)
        check('/api/tickets?id=2002&trial=C', 'alice-demo', 403 if secure else 200)
        check('/api/archive?id=2002&trial=D', 'alice-demo', 403 if secure else 200)
        check('/api/tickets?id=2002&trial=E', 'bob-demo', 200)
        check('/api/archive?id=2002&trial=F', 'bob-demo', 200)
        check('/api/tickets?id=2002&trial=G', None, 401)
        check('/api/tickets?id=9999&trial=H', 'alice-demo', 404)
        status, data = request(base+'/api/telemetry?source=iot&trial=TEL', data=b'{"event":"smoke"}')
        assert status == 202 and data['accepted'] is True
    finally:
        proc.terminate()
        try:
            proc.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.communicate()
    events = [json.loads(s) for s in out.read_text().splitlines()]
    assert len(events) == 10, len(events)
    assert all('alice-demo' not in json.dumps(e) for e in events)
    assert events[-1]['telemetry_source'] == 'iot'
    assert events[-1]['payload_sha256']
    return events


if __name__ == '__main__':
    with tempfile.TemporaryDirectory() as d:
        root = pathlib.Path(d)
        insecure = run(False, root/'insecure.jsonl')
        secure = run(True, root/'secure.jsonl')
        assert [e['http_status'] for e in insecure if e['trial'] in tuple('ABCDEF')] == [200] * 6
        assert [e['http_status'] for e in secure if e['trial'] in tuple('ABCDEF')] == [200,200,403,403,200,200]
    print('PASS: 2 local server modes, six A–F requests, access control, telemetry, logs')
    print('NOT TESTED: Suricata replay, actual IDPS VMs, host-only capture')
