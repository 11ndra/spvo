#!/usr/bin/env python3
"""Join actual lab app events with Suricata HTTP alerts by explicit trial markers."""
import argparse
import json
import pathlib
import sys

TRIALS = tuple("ABCDEF")


def read_jsonl(path):
    for n, line in enumerate(pathlib.Path(path).read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            item = json.loads(line)
            if not isinstance(item, dict):
                raise ValueError("expected JSON object")
        except (json.JSONDecodeError, ValueError) as ex:
            raise ValueError(f"{path}:{n}: {ex}") from ex
        yield item


def analyze(app_file, eve_file, sid):
    app = list(read_jsonl(app_file))
    eve = list(read_jsonl(eve_file))
    # EVE HTTP object contains url; field may vary by Suricata config.
    from urllib.parse import parse_qs, urlsplit
    recorded = {}
    for x in app:
        trial = x.get("trial")
        if trial in TRIALS:
            recorded[trial] = x
    hits = {x: 0 for x in TRIALS}
    for event in eve:
        if event.get("event_type") != "alert" or event.get("alert", {}).get("signature_id") != sid:
            continue
        uri = event.get("http", {}).get("url", "")
        trial = parse_qs(urlsplit(uri).query).get("trial", [None])[0]
        if trial in hits:
            hits[trial] += 1
    print("trial | actor | owner | server HTTP | Suricata alerts | URI")
    print("------|-------|-------|-------------|-----------------|----")
    for trial in TRIALS:
        if trial not in recorded:
            print(f"{trial} | NO SERVER EVIDENCE | | | |")
            continue
        x = recorded[trial]
        print(f"{trial} | {x.get('actor')} | {x.get('owner')} | {x.get('http_status')} | {hits[trial]} | {x.get('uri')}")
    missing = sorted(set(TRIALS) - set(recorded))
    if missing:
        print(f"WARNING: server log has no trial(s) {','.join(missing)}", file=sys.stderr)
    if not any(hits.values()):
        print("WARNING: no matching alert. Check capture, URI visibility, SID and EVE HTTP logging.", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--app", required=True, help="server evidence/insecure.jsonl")
    parser.add_argument("--eve", required=True, help="Suricata eve.json")
    parser.add_argument("--sid", type=int, default=1000006)
    args = parser.parse_args()
    analyze(args.app, args.eve, args.sid)


if __name__ == '__main__':
    main()
