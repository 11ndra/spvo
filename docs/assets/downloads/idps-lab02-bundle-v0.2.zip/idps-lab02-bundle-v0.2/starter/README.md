# Материалы ЛР №2 v0.2

Содержимое:

- `lab02.rules` — готовое правило Suricata;
- `lab02-report.md` — шаблон отчёта;
- `lab02-preflight.sh` — обязательная проверка готовности VM до начала работы;
- `lab02-instructor-check.sh` — end-to-end smoke test для преподавателя перед занятием.

ЛР рассчитана на **Ubuntu 24.04 LTS в полноценной VM**, где доступны Linux network namespaces и kernel audit. Контейнер, WSL без необходимых возможностей или VM с заблокированными audit rules не считаются поддерживаемой средой для этой работы.
