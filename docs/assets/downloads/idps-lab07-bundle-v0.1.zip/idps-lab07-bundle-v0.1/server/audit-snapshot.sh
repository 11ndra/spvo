#!/usr/bin/env bash
set -euo pipefail
case_name=${1:-}
case "$case_name" in A|B|C) ;; *) echo 'Usage: bash server/audit-snapshot.sh A|B|C' >&2; exit 2 ;; esac
cd "$(dirname "$0")/.."
test -f evidence/audit-key.txt || { echo 'Missing evidence/audit-key.txt' >&2; exit 1; }
key=$(cat evidence/audit-key.txt)
file="evidence/audit-after-$case_name.raw"
# ausearch exits 1 when there are no events; this is valid for case A only.
set +e
sudo ausearch -k "$key" --raw > "$file"
rc=$?
set -e
if [[ "$rc" -gt 1 ]]; then echo "FAIL: ausearch exit=$rc" >&2; exit "$rc"; fi
# On no matches, some ausearch builds print a placeholder; keep an empty evidence file.
if [[ "$rc" == 1 ]]; then : > "$file"; fi
if [[ "$case_name" == A && -s "$file" ]]; then
  echo "FAIL: host evidence already exists after HTTP-only case A; inspect the cause." >&2
  exit 1
elif [[ "$case_name" != A && ! -s "$file" ]]; then
  echo "FAIL: expected host evidence absent after case $case_name" >&2; exit 1
fi
if [[ "$case_name" == C ]]; then
  test -f evidence/audit-after-B.raw || { echo 'Missing evidence/audit-after-B.raw' >&2; exit 1; }
  if [[ "$(wc -c < "$file")" -le "$(wc -c < evidence/audit-after-B.raw)" ]]; then
    echo 'FAIL: audit evidence did not grow after case C' >&2; exit 1
  fi
fi
printf 'AUDIT_SNAPSHOT case=%s key=%s bytes=%s file=%s\n' "$case_name" "$key" "$(wc -c < "$file")" "$file"
