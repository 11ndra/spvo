#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
iface=$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')
if [[ -z "$iface" ]]; then
  echo 'FAIL: Host-Only interface for 10.13.37.20 not found' >&2
  exit 1
fi
if [[ -e evidence/suricata/eve.json ]]; then
  echo 'REFUSED: previous evidence/suricata/eve.json exists. Do not mix runs.' >&2
  exit 2
fi
mkdir -p evidence/suricata
printf 'LAB_IFACE=%s\n' "$iface"
sudo suricata -T -c /etc/suricata/suricata.yaml -S "$PWD/server/lab07.rules"
exec sudo suricata -k none -c /etc/suricata/suricata.yaml \
  -S "$PWD/server/lab07.rules" -i "$iface" -l "$PWD/evidence/suricata"
