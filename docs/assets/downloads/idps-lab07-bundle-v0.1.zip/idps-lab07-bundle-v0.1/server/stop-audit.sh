#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test -f evidence/audit-key.txt || { echo 'Missing audit key; check auditctl -l before changing anything.' >&2; exit 1; }
key=$(cat evidence/audit-key.txt)
file=/var/tmp/idps-lab/lab07-evidence.txt
sudo auditctl -W "$file" -p wa -k "$key"
if sudo auditctl -l -k "$key" | grep -Fq "$file"; then
  echo 'FAIL: audit rule still present' >&2; exit 1
fi
printf 'AUDIT_RULE_REMOVED key=%s\n' "$key"
rm evidence/audit-key.txt
