#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p evidence
if [[ -e evidence/audit-key.txt ]]; then
  echo 'REFUSED: evidence/audit-key.txt already exists; clean up the previous lab07 audit rule first.' >&2
  exit 2
fi
if ! sudo auditctl -s | grep -Eq '^enabled[[:space:]]+1([[:space:]]|$)'; then
  echo 'FAIL: Linux Audit is not in enabled=1 state.' >&2; exit 1
fi
file=/var/tmp/idps-lab/lab07-evidence.txt
sudo mkdir -p /var/tmp/idps-lab
sudo touch "$file"
key="idps_l7_$(date +%s)_$$"
sudo auditctl -w "$file" -p wa -k "$key"
if ! sudo auditctl -l -k "$key" | grep -Fq "$file"; then
  echo 'FAIL: audit rule not confirmed.' >&2; exit 1
fi
printf '%s\n' "$key" > evidence/audit-key.txt
printf 'AUDIT_READY key=%s file=%s\n' "$key" "$file"
