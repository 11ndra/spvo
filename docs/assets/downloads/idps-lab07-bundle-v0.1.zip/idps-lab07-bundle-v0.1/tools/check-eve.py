#!/usr/bin/env python3
"""Fail closed if network evidence for cases A/C is incomplete."""
import json
import sys
from pathlib import Path

EXPECTED = {'A': '/LAB7-REVIEW/A?lab7_case=A', 'C': '/LAB7-REVIEW/C?lab7_case=C'}

def main() -> int:
    if len(sys.argv) != 2:
        print('Usage: python3 tools/check-eve.py evidence/suricata/eve.json', file=sys.stderr)
        return 2
    events=[]
    try:
        with Path(sys.argv[1]).open(encoding='utf-8') as stream:
            for lineno,line in enumerate(stream,1):
                if not line.strip(): continue
                try: events.append(json.loads(line))
                except json.JSONDecodeError as exc: raise ValueError(f'line {lineno}: {exc}') from exc
        http={}
        for event in events:
            if event.get('event_type') != 'http': continue
            h=event.get('http') or {}
            url=h.get('url')
            if isinstance(url,str) and '/LAB7-REVIEW/' in url and url not in EXPECTED.values():
                raise ValueError(f'Unexpected LAB07 HTTP URI: {url}')
            for case,expected_url in EXPECTED.items():
                if url != expected_url: continue
                if event.get('src_ip')!='10.13.37.10' or event.get('dest_ip')!='10.13.37.20':
                    raise ValueError(f'HTTP {case}: wrong direction/IP')
                flow=event.get('flow_id')
                if not isinstance(flow,int): raise ValueError(f'HTTP {case}: missing flow_id')
                http.setdefault(case,[]).append(flow)
        if set(http)!=set(EXPECTED) or any(len(v)!=1 for v in http.values()):
            raise ValueError(f'Expected exactly one HTTP event per case A/C; found {http}')
        if http['A'][0]==http['C'][0]:
            raise ValueError('A/C unexpectedly share flow_id; inspect capture')
        lab_alerts=[e for e in events if e.get('event_type')=='alert' and (e.get('alert') or {}).get('signature_id')==1000007]
        if len(lab_alerts)!=2:
            raise ValueError(f'Expected exactly two SID 1000007 alerts; found {len(lab_alerts)}')
        for case,flow in ((key,values[0]) for key,values in http.items()):
            matches=[e for e in lab_alerts if e.get('flow_id')==flow]
            if len(matches)!=1: raise ValueError(f'Expected one alert SID 1000007 for {case}/flow_id={flow}; found {len(matches)}')
        print('EVE VERIFIED: exact HTTP cases A,C, distinct flow_id, one SID1000007 alert each')
        return 0
    except (OSError,ValueError) as exc:
        print(f'EVE NOT ACCEPTED: {exc}',file=sys.stderr)
        return 1

if __name__ == '__main__': raise SystemExit(main())
