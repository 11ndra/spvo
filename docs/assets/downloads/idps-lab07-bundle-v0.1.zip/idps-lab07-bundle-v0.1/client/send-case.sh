#!/usr/bin/env bash
set -euo pipefail
case_name=${1:-}
case "$case_name" in A|C) ;; *) echo 'Usage: bash client/send-case.sh A|C' >&2; exit 2 ;; esac
cd "$(dirname "$0")/.."
mkdir -p evidence
uri="/LAB7-REVIEW/$case_name?lab7_case=$case_name"
output="evidence/response-$case_name.txt"
status=$(curl --noproxy '*' --globoff --path-as-is --connect-timeout 5 --max-time 15 -sS -o "$output" -w '%{http_code}' "http://10.13.37.20:8080$uri")
if [[ "$status" != 200 ]] || ! grep -Fq "path=$uri" "$output"; then
  printf 'FAIL case=%s http=%s expected path=%s\n' "$case_name" "$status" "$uri" >&2
  exit 1
fi
printf 'CASE=%s HTTP=%s VERIFIED_RESPONSE=%s\n' "$case_name" "$status" "$output"
