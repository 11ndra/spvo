#!/usr/bin/env python3
"""Checks actual EVE JSON produced by Suricata; never generates synthetic evidence."""
import json
import sys
from pathlib import Path

SID = 1000008


def run(path):
    lines = Path(path).read_text(encoding='utf-8').splitlines()
    alerts = []
    http_allow = []
    for i, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            e = json.loads(line)
        except ValueError as ex:
            raise ValueError(f'line {i} is invalid JSON: {ex}') from ex
        if e.get('event_type') == 'http' and '/LAB8-ALLOW' in e.get('http', {}).get('url', ''):
            http_allow.append(e)
        if e.get('event_type') == 'alert' and e.get('alert', {}).get('signature_id') == SID:
            alerts.append(e)
    if not http_allow:
        raise ValueError('no actual HTTP event for allowed URI; output/visibility is not validated')
    blocked = [x for x in alerts if x.get('alert', {}).get('action') == 'blocked']
    if not blocked:
        raise ValueError('no alert.action=blocked for SID 1000008; IPS action unproven')
    if any(x.get('alert', {}).get('action') == 'allowed' for x in alerts):
        raise ValueError('same IPS run contains SID 1000008 alert.action=allowed')
    for x in blocked:
        if x.get('src_ip') != '10.13.37.10' or x.get('dest_ip') != '10.13.37.20':
            raise ValueError('SID 1000008 alert has unexpected direction/IP')
    print(f'HTTP_ALLOW_EVENTS={len(http_allow)}')
    print(f'SID_{SID}_BLOCKED_ALERTS={len(blocked)}')
    print('EVE_IPS_CHECK_OK (only proves EVE reports blocked action; compare HTTP responses)')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 tools/check-ips-eve.py evidence/ips/eve.json')
    try:
        run(sys.argv[1])
    except (ValueError, OSError) as exc:
        raise SystemExit(f'[FAIL] {exc}')
