#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
label=${1:-}
case "$label" in
  baseline) uri='/LAB8-BLOCK?lab8_case=baseline' ;;
  allow) uri='/LAB8-ALLOW?lab8_case=allow' ;;
  block) uri='/LAB8-BLOCK?lab8_case=block' ;;
  restore) uri='/LAB8-BLOCK?lab8_case=restore' ;;
  *) echo 'Usage: bash client/try-uri.sh baseline|allow|block|restore' >&2; exit 2 ;;
esac
mkdir -p evidence
body="evidence/response-${label}.txt"; meta="evidence/result-${label}.txt"
set +e
code=$(curl --noproxy '*' --silent --show-error --max-time 6 --output "$body" --write-out '%{http_code}' "http://10.13.37.20:8080${uri}")
rc=$?
set -e
printf 'CASE=%s\nURI=%s\nCURL_EXIT=%s\nHTTP_CODE=%s\n' "$label" "$uri" "$rc" "$code" | tee "$meta"
if [[ "$label" == block ]]; then
  if [[ "$rc" == 0 && "$code" == 200 ]]; then
    echo '[FAIL] blocked probe reached HTTP server normally; prevention not demonstrated' >&2; exit 1
  fi
  echo 'OBSERVED: no HTTP 200 for protected marker; inspect EVE blocked action and restore connectivity before drawing a conclusion'
else
  if [[ "$rc" != 0 || "$code" != 200 ]]; then
    echo '[FAIL] expected HTTP 200; check web service and NFQUEUE before proceeding' >&2; exit 1
  fi
  grep -Fq "path=$uri" "$body" || { echo '[FAIL] HTTP content is not expected path' >&2; exit 1; }
  echo 'HTTP_RESPONSE_CONFIRMED'
fi
