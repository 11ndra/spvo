#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p evidence
if sudo nft list table inet spvo_lab08_ips >/dev/null 2>&1; then
  echo '[REFUSED] Dedicated table exists; no changes made.' >&2; exit 1
fi
sudo nft add table inet spvo_lab08_ips
rollback() { sudo nft delete table inet spvo_lab08_ips >/dev/null 2>&1 || true; }
trap rollback ERR
sudo nft add chain inet spvo_lab08_ips input '{ type filter hook input priority 10; policy accept; }'
sudo nft add chain inet spvo_lab08_ips output '{ type filter hook output priority 10; policy accept; }'
sudo nft add rule inet spvo_lab08_ips input ip saddr 10.13.37.10 ip daddr 10.13.37.20 tcp dport 8080 queue num 8 bypass comment 'SPVO_LAB08_IN'
sudo nft add rule inet spvo_lab08_ips output ip saddr 10.13.37.20 ip daddr 10.13.37.10 tcp sport 8080 queue num 8 bypass comment 'SPVO_LAB08_OUT'
sudo nft list table inet spvo_lab08_ips | tee evidence/nft-enabled.txt
trap - ERR
printf '%s\n' 'NFT_READY: traffic scoped to 10.13.37.10 <-> 10.13.37.20 tcp/8080; NFQUEUE=8; bypass enabled'
