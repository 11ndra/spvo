#!/usr/bin/env bash
set -euo pipefail
if ! sudo nft list table inet spvo_lab08_ips >/dev/null 2>&1; then
  echo 'NFT_ALREADY_ABSENT'; exit 0
fi
rules=$(sudo nft list table inet spvo_lab08_ips)
if [[ "$rules" != *SPVO_LAB08_IN* || "$rules" != *SPVO_LAB08_OUT* ]]; then
  echo '[REFUSED] Table signature differs; inspect manually before removal.' >&2; exit 1
fi
sudo nft delete table inet spvo_lab08_ips
sudo nft list table inet spvo_lab08_ips >/dev/null 2>&1 && { echo '[FAIL] table remains' >&2; exit 1; }
echo 'NFT_REMOVED: only dedicated spvo_lab08_ips table removed'
