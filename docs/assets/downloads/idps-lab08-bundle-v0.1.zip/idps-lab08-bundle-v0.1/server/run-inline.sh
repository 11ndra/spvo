#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! sudo nft list table inet spvo_lab08_ips | grep -q 'SPVO_LAB08_IN'; then
  echo '[FAIL] scoped NFQUEUE rules are not installed' >&2; exit 1
fi
if [ -e evidence/ips/eve.json ]; then
  echo '[REFUSED] evidence/ips/eve.json exists' >&2; exit 1
fi
mkdir -p evidence/ips
sudo suricata -c /etc/suricata/suricata.yaml -S "$PWD/server/lab08.rules" -q 8 -l "$PWD/evidence/ips"
