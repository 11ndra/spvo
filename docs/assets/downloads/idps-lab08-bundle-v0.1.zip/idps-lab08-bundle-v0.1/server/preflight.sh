#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail() { echo "[FAIL] $*" >&2; exit 1; }
for x in curl suricata nft ip grep awk; do command -v "$x" >/dev/null || fail "missing executable $x"; done
suricata --build-info | grep -Eiq 'NFQ|NFQUEUE' || fail 'this Suricata build does not report NFQ support'
if sudo nft list table inet spvo_lab08_ips >/dev/null 2>&1; then
  fail 'table spvo_lab08_ips already exists; never overwrite it'
fi
if [ -d evidence/ips ] && [ "$(find evidence/ips -mindepth 1 -print -quit)" ]; then
  fail 'evidence/ips is not empty; use a clean extraction for a new run'
fi
sudo suricata -T -c /etc/suricata/suricata.yaml -S "$PWD/server/lab08.rules"
if ! ip -o -4 addr show | grep -q '10\.13\.37\.20/'; then fail 'server LAB IPv4 10.13.37.20 not found'; fi
body=$(curl --noproxy '*' --silent --show-error --fail --max-time 5 'http://10.13.37.20:8080/LAB8-BLOCK?lab8_case=preflight') || fail 'web service not reachable before inline test'
case "$body" in *'path=/LAB8-BLOCK?lab8_case=preflight'*) ;; *) fail "unexpected HTTP response: $body" ;; esac
printf '%s\n' 'PREFLIGHT_OK: NFQUEUE supported, rule valid, service responds to /LAB8-BLOCK before protection'
