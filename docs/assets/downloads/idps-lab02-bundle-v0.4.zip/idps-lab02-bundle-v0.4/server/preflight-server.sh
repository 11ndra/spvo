#!/usr/bin/env bash
set -u
[[ $EUID -eq 0 ]] || { echo 'Run with sudo.'; exit 1; }
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0; ok(){ echo "[ OK ] $*"; }; bad(){ echo "[FAIL] $*"; fail=1; }
for c in ip curl jq tcpdump suricata auditctl ausearch; do command -v "$c" >/dev/null 2>&1 && ok "command: $c" || bad "missing command: $c"; done
ip -o -4 addr show | grep -q '10\.13\.37\.20/' && ok 'lab address 10.13.37.20 is present' || bad 'expected address 10.13.37.20/24 is missing'
IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
[[ -n "$IFACE" ]] && ok "lab interface: $IFACE" || bad 'cannot identify lab interface'
systemctl is-active --quiet idps-lab-web.service && ok 'lab web service is running' || bad 'idps-lab-web.service is not running'
curl -fsS http://127.0.0.1:8080/ >/dev/null 2>&1 && ok 'local HTTP service answers' || bad 'local HTTP service does not answer'
[[ -f /etc/suricata/suricata.yaml ]] && ok 'Suricata config exists' || bad 'missing /etc/suricata/suricata.yaml'
if command -v suricata >/dev/null 2>&1; then suricata -T -c /etc/suricata/suricata.yaml -S "$SCRIPT_DIR/lab02.rules" >/tmp/lab02-test.log 2>&1 && ok 'Suricata + lab02.rules' || bad 'Suricata rule/config check failed; see /tmp/lab02-test.log'; fi
if command -v auditctl >/dev/null 2>&1; then
  st="$(auditctl -s 2>/dev/null || true)"; en="$(awk '$1=="enabled" {print $2; exit}' <<<"$st")"
  [[ "$en" == 1 ]] && ok 'Linux Audit is enabled and mutable' || bad "Linux Audit enabled state is ${en:-unknown}; expected 1"
  auditctl -l 2>/dev/null | grep -Eq '(^|[[:space:]])never,task([[:space:]]|$)' && bad 'never,task audit rule is active' || ok 'no never,task rule detected'
fi
(systemctl is-active --quiet auditd 2>/dev/null || pgrep -x auditd >/dev/null 2>&1) && ok 'auditd is running' || bad 'auditd is not running'
[[ $fail -eq 0 ]] && echo 'SERVER PRE-FLIGHT PASSED.' || echo 'SERVER PRE-FLIGHT FAILED.'
exit $fail
