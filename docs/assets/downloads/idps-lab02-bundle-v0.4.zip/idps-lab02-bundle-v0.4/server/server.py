#!/usr/bin/env python3
from datetime import datetime, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

WEBROOT = Path('/opt/idps-lab/webroot')
EVIDENCE_DIR = Path('/var/tmp/idps-lab')
EVIDENCE_FILE = EVIDENCE_DIR / 'lab2-evidence.txt'

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WEBROOT), **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == '/lab2-trigger/LAB2-NET':
            EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
            EVIDENCE_FILE.write_text(
                'LAB2-HOST\n' + f'timestamp={datetime.now(timezone.utc).isoformat()}\n',
                encoding='utf-8',
            )
            body = f'LAB2 event created\nfile={EVIDENCE_FILE}\n'.encode()
            self.send_response(200)
            self.send_header('Content-Type','text/plain; charset=utf-8')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers(); self.wfile.write(body); return
        super().do_GET()

ThreadingHTTPServer(('0.0.0.0',8080), Handler).serve_forever()
