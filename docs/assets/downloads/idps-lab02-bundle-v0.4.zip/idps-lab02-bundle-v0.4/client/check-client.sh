#!/usr/bin/env bash
set -u
fail=0
ok(){ echo "[ OK ] $*"; }; bad(){ echo "[FAIL] $*"; fail=1; }
for c in ip curl; do command -v "$c" >/dev/null 2>&1 && ok "command: $c" || bad "missing command: $c"; done
ip -o -4 addr show | grep -q '10\.13\.37\.10/' && ok 'lab address 10.13.37.10 is present' || bad 'expected address 10.13.37.10/24 is missing'
ping -c 1 -W 1 10.13.37.20 >/dev/null 2>&1 && ok 'idps-server responds to ICMP' || echo '[WARN] ICMP reply not received; HTTP connectivity will be checked next'
curl -fsS --max-time 3 http://10.13.37.20:8080/ >/dev/null 2>&1 && ok 'web service 10.13.37.20:8080 is reachable' || bad 'web service is not reachable; server setup may not be complete'
[[ $fail -eq 0 ]] && echo 'CLIENT CHECK PASSED.' || echo 'CLIENT CHECK FAILED.'
exit $fail
