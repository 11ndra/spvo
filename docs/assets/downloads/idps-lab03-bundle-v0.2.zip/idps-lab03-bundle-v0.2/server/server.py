#!/usr/bin/env python3
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

BIND_IP = "10.13.37.20"
PORT = 8080
LOG_DIR = Path("/var/tmp/idps-lab")
ACCESS_LOG = LOG_DIR / "lab3-access.log"

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        src_ip, src_port = self.client_address
        dst_ip, dst_port = self.server.server_address[:2]
        line = (
            f"timestamp={datetime.now(timezone.utc).isoformat()} "
            f"src={src_ip}:{src_port} dst={dst_ip}:{dst_port} "
            f"method=GET uri={self.path}\n"
        )
        with ACCESS_LOG.open("a", encoding="utf-8") as fh:
            fh.write(line)

        body = (
            "IDPS Lab 3 request received\n"
            f"dst={dst_ip}:{dst_port}\n"
            f"path={self.path}\n"
        ).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return

ThreadingHTTPServer((BIND_IP, PORT), Handler).serve_forever()
