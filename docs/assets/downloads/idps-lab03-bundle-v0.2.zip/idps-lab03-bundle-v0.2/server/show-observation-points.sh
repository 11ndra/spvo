#!/usr/bin/env bash
set -euo pipefail
LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip route show default | awk '/^default / {print $5; exit}')"
NAT_GW="$(ip route show default | awk '/^default / {print $3; exit}')"
[[ -n "$LAB_IFACE" ]] || { echo '[FAIL] Не найден интерфейс 10.13.37.20/24.' >&2; exit 1; }
[[ -n "$NAT_IFACE" ]] || { echo '[FAIL] Не найден интерфейс маршрута по умолчанию.' >&2; exit 1; }
[[ "$LAB_IFACE" != "$NAT_IFACE" ]] || { echo '[FAIL] LAB_IFACE и NAT_IFACE совпали.' >&2; exit 1; }
printf 'LAB_IFACE=%s\nNAT_IFACE=%s\nNAT_GW=%s\n' "$LAB_IFACE" "$NAT_IFACE" "$NAT_GW"
echo
echo 'Маршрут до внутреннего клиента:'
ip route get 10.13.37.10
echo
echo 'Маршрут до шлюза по умолчанию:'
ip route get "$NAT_GW"
