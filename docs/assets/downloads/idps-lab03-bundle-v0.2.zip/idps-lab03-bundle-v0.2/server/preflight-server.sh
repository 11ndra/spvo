#!/usr/bin/env bash
set -u
if [[ $EUID -ne 0 ]]; then echo '[FAIL] Запустите через sudo.' >&2; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0; warn=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
wrn(){ echo "[WARN] $*"; warn=$((warn+1)); }
for cmd in ip curl jq tcpdump timeout suricata ethtool ping; do command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"; done
LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip route show default | awk '/^default / {print $5; exit}')"
NAT_GW="$(ip route show default | awk '/^default / {print $3; exit}')"
[[ -n "$LAB_IFACE" ]] && ok "LAB_IFACE=$LAB_IFACE" || bad 'не найден LAB_IFACE'
[[ -n "$NAT_IFACE" ]] && ok "NAT_IFACE=$NAT_IFACE" || bad 'не найден NAT_IFACE'
[[ -n "$NAT_GW" ]] && ok "NAT_GW=$NAT_GW" || bad 'не найден шлюз маршрута по умолчанию'
if [[ -n "$LAB_IFACE" && -n "$NAT_IFACE" ]]; then [[ "$LAB_IFACE" != "$NAT_IFACE" ]] && ok 'интерфейсы различаются' || bad 'интерфейсы совпадают'; fi
systemctl is-active --quiet idps-lab-web.service && ok 'web-сервис запущен' || bad 'web-сервис не запущен'
curl -fsS http://10.13.37.20:8080/health >/dev/null 2>&1 && ok 'web-сервис отвечает на 10.13.37.20:8080' || bad 'web-сервис не отвечает на учебном адресе'
[[ -f /var/tmp/idps-lab/lab3-access.log ]] && ok 'журнал приложения существует' || bad 'нет lab3-access.log'
if ss -ltn 2>/dev/null | grep -Eq '10\.13\.37\.20:8080[[:space:]]'; then ok 'TCP/8080 привязан к 10.13.37.20'; else bad 'TCP/8080 не привязан строго к 10.13.37.20'; fi
[[ -f /etc/suricata/suricata.yaml ]] && ok 'конфигурация Suricata существует' || bad 'нет suricata.yaml'
if command -v suricata >/dev/null 2>&1 && [[ -f /etc/suricata/suricata.yaml ]]; then
  suricata -T -c /etc/suricata/suricata.yaml -S "$SCRIPT_DIR/lab03.rules" >/tmp/lab03-suricata-test.log 2>&1 && ok 'Suricata принимает lab03.rules' || bad 'suricata -T не пройден; см. /tmp/lab03-suricata-test.log'
fi
for iface in "$LAB_IFACE" "$NAT_IFACE"; do
  [[ -z "$iface" ]] && continue
  if ethtool -k "$iface" >/tmp/lab03-ethtool-$iface.txt 2>/dev/null; then
    if grep -Eq '^(generic-receive-offload|large-receive-offload): on' /tmp/lab03-ethtool-$iface.txt; then
      wrn "$iface: GRO/LRO всё ещё включён; запустите sudo bash server/prepare-capture.sh"
    else
      ok "$iface: GRO/LRO не включены"
    fi
  fi
done
if [[ $fail -eq 0 ]]; then echo 'SERVER PRE-FLIGHT PASSED.'; ((warn>0)) && echo "Предупреждений: $warn"; else echo 'SERVER PRE-FLIGHT FAILED.'; fi
exit $fail
