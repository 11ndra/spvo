#!/usr/bin/env bash
# Этот скрипт нужно source-ить в каждом новом терминале idps-server:
# source server/load-vars.sh
LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip route show default | awk '/^default / {print $5; exit}')"
NAT_GW="$(ip route show default | awk '/^default / {print $3; exit}')"
if [[ -z "$LAB_IFACE" || -z "$NAT_IFACE" || -z "$NAT_GW" || "$LAB_IFACE" == "$NAT_IFACE" ]]; then
  echo '[FAIL] Не удалось определить LAB_IFACE/NAT_IFACE/NAT_GW.' >&2
  return 1 2>/dev/null || exit 1
fi
export LAB_IFACE NAT_IFACE NAT_GW
printf 'LAB_IFACE=%s\nNAT_IFACE=%s\nNAT_GW=%s\n' "$LAB_IFACE" "$NAT_IFACE" "$NAT_GW"
