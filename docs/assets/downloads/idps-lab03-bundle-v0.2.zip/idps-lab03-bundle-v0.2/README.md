# IDPS Lab 03 bundle v0.2

ЛР №3 проверяет размещение относительно двух разных сетевых путей:

- внутренний HTTP: `10.13.37.10 -> 10.13.37.20:8080`;
- исходящий ICMP: `idps-server -> NAT_GW`.

Перед экспериментом на сервере:

```bash
sudo bash server/setup-server.sh
sudo bash server/prepare-capture.sh
sudo bash server/preflight-server.sh
bash server/show-observation-points.sh
source server/load-vars.sh
```

На клиенте:

```bash
bash client/check-client.sh
```

Suricata запускается в foreground с отдельным каталогом журналов для каждого интерфейса и с `-k none`.
