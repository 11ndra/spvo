#!/usr/bin/env bash
set -u

fail=0
warn=0
ok(){ printf '[ OK ] %s\n' "$*"; }
err(){ printf '[FAIL] %s\n' "$*"; fail=$((fail+1)); }
wrn(){ printf '[WARN] %s\n' "$*"; warn=$((warn+1)); }

EXPECTED_IP="10.13.37.10"
PEER_IP="10.13.37.20"
EXPECTED_HOSTNAME="idps-client"

printf 'Проверка клиентской VM (%s)\n\n' "$(hostname)"

for cmd in curl jq tcpdump unzip ethtool ip ping; do
  command -v "$cmd" >/dev/null 2>&1 && ok "Команда $cmd доступна" || err "Команда $cmd не найдена"
done

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.10\/24$/ {print $2; exit}')"
if [[ -n "$LAB_IFACE" ]]; then
  ok "Учебный адрес ${EXPECTED_IP}/24 найден на $LAB_IFACE"
else
  err "Не найден учебный адрес ${EXPECTED_IP}/24"
fi

mapfile -t DEFAULT_LINES < <(ip -4 route show default)
if (( ${#DEFAULT_LINES[@]} == 1 )); then
  DEFAULT_IFACE="$(awk '{for(i=1;i<=NF;i++) if($i=="dev") {print $(i+1); exit}}' <<<"${DEFAULT_LINES[0]}")"
  ok "Найден единственный default route через ${DEFAULT_IFACE:-неизвестный интерфейс}"
else
  DEFAULT_IFACE=""
  err "Ожидался один default route, найдено: ${#DEFAULT_LINES[@]}"
  printf '%s\n' "${DEFAULT_LINES[@]}"
fi

if [[ -n "$LAB_IFACE" && -n "$DEFAULT_IFACE" ]]; then
  [[ "$LAB_IFACE" != "$DEFAULT_IFACE" ]] && ok "LAB-интерфейс не используется как default route" || err "LAB-интерфейс $LAB_IFACE ошибочно используется как default route"
fi

if [[ -n "$LAB_IFACE" ]]; then
  ROUTE_TO_PEER="$(ip -4 route get "$PEER_IP" 2>/dev/null | head -n1 || true)"
  grep -q " dev $LAB_IFACE\( \|$\)" <<<"$ROUTE_TO_PEER" && ok "Маршрут к серверу ${PEER_IP} идёт через LAB-интерфейс $LAB_IFACE" || err "Маршрут к ${PEER_IP} не подтверждён через $LAB_IFACE: ${ROUTE_TO_PEER:-нет маршрута}"
fi

check_virtio(){
  local iface="$1" role="$2" driver
  [[ -n "$iface" ]] || return
  driver="$(ethtool -i "$iface" 2>/dev/null | awk -F': ' '$1=="driver" {print $2; exit}')"
  if [[ "$driver" == "virtio_net" ]]; then
    ok "$role $iface использует virtio_net"
  else
    err "$role $iface использует драйвер ${driver:-не определён}; в VirtualBox выберите Paravirtualized Network (virtio-net)"
  fi
}
check_virtio "$LAB_IFACE" "Host-Only интерфейс"
check_virtio "$DEFAULT_IFACE" "NAT-интерфейс"

if ping -c 2 -W 2 "$PEER_IP" >/dev/null 2>&1; then
  ok "Сервер ${PEER_IP} доступен по учебной сети"
else
  err "Нет ответа от ${PEER_IP}. Проверьте Host-Only Adapter, адресацию и состояние интерфейсов"
fi

if [[ "${HOSTNAME,,}" == "$EXPECTED_HOSTNAME" ]]; then
  ok "Hostname: $(hostname)"
else
  wrn "Hostname отличается от рекомендуемого ${EXPECTED_HOSTNAME}: $(hostname)"
fi

printf '\n'
if (( fail == 0 )); then
  echo "CLIENT ENVIRONMENT READY"
  (( warn > 0 )) && echo "Предупреждений: $warn"
  exit 0
else
  echo "CLIENT ENVIRONMENT NOT READY — ошибок: $fail, предупреждений: $warn"
  exit 1
fi
