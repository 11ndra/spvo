# IDPS Environment Setup v1.2

Этот пакет готовит две постоянные VM курса после того, как студент вручную создал их в VirtualBox и настроил два сетевых адаптера.

| Скрипт | Назначение |
|---|---|
| `bootstrap-client.sh` | устанавливает системные инструменты Ubuntu Desktop |
| `bootstrap-server.sh` | устанавливает Suricata, Linux Audit, SSH и вспомогательные утилиты; системный сервис Suricata отключает |
| `show-network-candidates.sh` | показывает интерфейсы, IPv4, драйверы и default route, ничего не изменяя |
| `check-client-environment.sh` | проверяет адресацию, маршрутизацию, `virtio_net`, инструменты и связь с сервером |
| `check-server-environment.sh` | дополнительно проверяет Suricata, Linux Audit, состояние системного сервиса Suricata и SSH |

Скрипты не создают VM и не выбирают сетевой интерфейс за студента. Это намеренно: студент должен понимать, где находится NAT, где Host-Only и какой адрес принадлежит каждой роли.

## Базовая сеть

```text
Windows host  10.13.37.1/24
idps-client   10.13.37.10/24
idps-server   10.13.37.20/24
```

Обе VM используют одинаковую схему VirtualBox:

| Adapter | Attached to | Type |
|---|---|---|
| 1 | NAT | Paravirtualized Network (`virtio-net`) |
| 2 | Host-Only | Paravirtualized Network (`virtio-net`) |

Host-Only не получает gateway и DNS. Единственный `default` остаётся через NAT.

Checker v1.2 проверяет эту модель фактически, а не по имени интерфейса: определяет LAB-интерфейс по адресу `10.13.37.10/24` или `10.13.37.20/24`, проверяет маршрут к соседней VM, default route и сетевой драйвер.

На сервере дополнительно требуется `auditd` с `enabled 1`, отсутствие блокирующего `never,task`, `suricata` в состоянии `inactive` + `disabled`, а также рабочий SSH listener на TCP/22.
