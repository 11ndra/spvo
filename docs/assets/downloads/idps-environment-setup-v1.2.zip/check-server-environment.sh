#!/usr/bin/env bash
set -u

if [[ $EUID -ne 0 ]]; then
  echo "[ ERROR ] Запустите через sudo: sudo bash check-server-environment.sh" >&2
  exit 2
fi

fail=0
warn=0
ok(){ printf '[ OK ] %s\n' "$*"; }
err(){ printf '[FAIL] %s\n' "$*"; fail=$((fail+1)); }
wrn(){ printf '[WARN] %s\n' "$*"; warn=$((warn+1)); }

EXPECTED_IP="10.13.37.20"
PEER_IP="10.13.37.10"
EXPECTED_HOSTNAME="idps-server"

printf 'Проверка серверной VM (%s)\n\n' "$(hostname)"

for cmd in python3 curl jq tcpdump suricata auditctl ausearch ethtool unzip ss ip ping; do
  command -v "$cmd" >/dev/null 2>&1 && ok "Команда $cmd доступна" || err "Команда $cmd не найдена"
done

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\/24$/ {print $2; exit}')"
if [[ -n "$LAB_IFACE" ]]; then
  ok "Учебный адрес ${EXPECTED_IP}/24 найден на $LAB_IFACE"
else
  err "Не найден учебный адрес ${EXPECTED_IP}/24"
fi

mapfile -t DEFAULT_LINES < <(ip -4 route show default)
if (( ${#DEFAULT_LINES[@]} == 1 )); then
  DEFAULT_IFACE="$(awk '{for(i=1;i<=NF;i++) if($i=="dev") {print $(i+1); exit}}' <<<"${DEFAULT_LINES[0]}")"
  ok "Найден единственный default route через ${DEFAULT_IFACE:-неизвестный интерфейс}"
else
  DEFAULT_IFACE=""
  err "Ожидался один default route, найдено: ${#DEFAULT_LINES[@]}"
  printf '%s\n' "${DEFAULT_LINES[@]}"
fi

if [[ -n "$LAB_IFACE" && -n "$DEFAULT_IFACE" ]]; then
  [[ "$LAB_IFACE" != "$DEFAULT_IFACE" ]] && ok "LAB-интерфейс не используется как default route" || err "LAB-интерфейс $LAB_IFACE ошибочно используется как default route"
fi

if [[ -n "$LAB_IFACE" ]]; then
  ROUTE_TO_PEER="$(ip -4 route get "$PEER_IP" 2>/dev/null | head -n1 || true)"
  grep -q " dev $LAB_IFACE\( \|$\)" <<<"$ROUTE_TO_PEER" && ok "Маршрут к клиенту ${PEER_IP} идёт через LAB-интерфейс $LAB_IFACE" || err "Маршрут к ${PEER_IP} не подтверждён через $LAB_IFACE: ${ROUTE_TO_PEER:-нет маршрута}"
fi

check_virtio(){
  local iface="$1" role="$2" driver
  [[ -n "$iface" ]] || return
  driver="$(ethtool -i "$iface" 2>/dev/null | awk -F': ' '$1=="driver" {print $2; exit}')"
  if [[ "$driver" == "virtio_net" ]]; then
    ok "$role $iface использует virtio_net"
  else
    err "$role $iface использует драйвер ${driver:-не определён}; в VirtualBox выберите Paravirtualized Network (virtio-net)"
  fi
}
check_virtio "$LAB_IFACE" "Host-Only интерфейс"
check_virtio "$DEFAULT_IFACE" "NAT-интерфейс"

if command -v suricata >/dev/null 2>&1; then
  SURICATA_VERSION="$(suricata -V 2>/dev/null | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1 || true)"
  SURICATA_MAJOR="${SURICATA_VERSION%%.*}"
  [[ "$SURICATA_MAJOR" == "8" ]] && ok "Suricata ${SURICATA_VERSION} соответствует поддерживаемой ветке 8.x" || err "Требуется Suricata 8.x; обнаружена версия ${SURICATA_VERSION:-не определена}"
fi

if ping -c 2 -W 2 "$PEER_IP" >/dev/null 2>&1; then
  ok "Клиент ${PEER_IP} доступен по учебной сети"
else
  err "Нет ответа от ${PEER_IP}. Проверьте Host-Only Adapter, адресацию и состояние интерфейсов"
fi

if systemctl is-active --quiet auditd; then ok "auditd запущен"; else err "auditd не запущен"; fi
if auditctl -s 2>/dev/null | grep -Eq '^enabled[[:space:]]+1'; then
  ok "Linux Audit включён (enabled 1)"
else
  err "Linux Audit не находится в состоянии enabled 1"
fi
if auditctl -l 2>/dev/null | grep -Eq '(^|[[:space:]])never,task([[:space:]]|$)'; then
  err "Найдено правило never,task — оно препятствует ожидаемой телеметрии лаборатории"
else
  ok "Правило never,task не обнаружено"
fi

SURICATA_ACTIVE="$(systemctl is-active suricata 2>/dev/null || true)"
SURICATA_ENABLED="$(systemctl is-enabled suricata 2>/dev/null || true)"
[[ "$SURICATA_ACTIVE" == "inactive" ]] && ok "Системный сервис Suricata: inactive" || err "Системный сервис Suricata должен быть inactive; сейчас: ${SURICATA_ACTIVE:-unknown}"
[[ "$SURICATA_ENABLED" == "disabled" ]] && ok "Автозапуск Suricata: disabled" || err "Автозапуск Suricata должен быть disabled; сейчас: ${SURICATA_ENABLED:-unknown}"

if systemctl is-active --quiet ssh; then ok "SSH service запущен"; else err "SSH service не запущен"; fi
if ss -ltn | awk '$4 ~ /:22$/ {found=1} END {exit !found}'; then
  ok "TCP/22 слушается на сервере"
else
  err "TCP/22 не находится в состоянии LISTEN"
fi

if [[ -f /etc/suricata/suricata.yaml ]]; then
  ok "Найдена конфигурация /etc/suricata/suricata.yaml"
  EMPTY_RULES="$(mktemp)"
  if suricata -T -c /etc/suricata/suricata.yaml -S "$EMPTY_RULES" >/tmp/idps-suricata-test.log 2>&1; then
    ok "Suricata проходит проверку базовой конфигурации"
  else
    err "Suricata не проходит -T; см. /tmp/idps-suricata-test.log"
  fi
  rm -f "$EMPTY_RULES"
else
  err "Не найден /etc/suricata/suricata.yaml"
fi

if [[ "${HOSTNAME,,}" == "$EXPECTED_HOSTNAME" ]]; then
  ok "Hostname: $(hostname)"
else
  wrn "Hostname отличается от рекомендуемого ${EXPECTED_HOSTNAME}: $(hostname)"
fi

printf '\n'
if (( fail == 0 )); then
  echo "SERVER ENVIRONMENT READY"
  (( warn > 0 )) && echo "Предупреждений: $warn"
  exit 0
else
  echo "SERVER ENVIRONMENT NOT READY — ошибок: $fail, предупреждений: $warn"
  exit 1
fi
