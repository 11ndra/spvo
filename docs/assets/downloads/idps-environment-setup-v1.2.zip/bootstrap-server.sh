#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "[ ERROR ] Запустите скрипт через sudo: sudo bash bootstrap-server.sh" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive

echo "[1/5] Обновление списка пакетов..."
apt-get update

echo "[2/5] Установка базовых инструментов серверной VM..."
apt-get install -y \
  ca-certificates software-properties-common python3 curl jq tcpdump \
  auditd audispd-plugins ethtool unzip openssh-server \
  iproute2 iputils-ping net-tools

echo "[3/5] Установка поддерживаемой ветки Suricata 8.x..."
get_suricata_major() {
  command -v suricata >/dev/null 2>&1 || return 1
  suricata -V 2>/dev/null | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1 | cut -d. -f1
}

SURICATA_MAJOR="$(get_suricata_major || true)"
if [[ "$SURICATA_MAJOR" != "8" ]]; then
  echo "[ INFO ] Требуется Suricata 8.x; текущая major-версия: ${SURICATA_MAJOR:-не установлена}."
  if add-apt-repository -y ppa:oisf/suricata-stable; then
    apt-get update
    apt-get install -y suricata
  else
    echo "[ ERROR ] Не удалось подключить stable PPA OISF для установки Suricata 8.x." >&2
    echo "[ ERROR ] Не продолжайте лаборатории на неподдерживаемой ветке: подготовьте пакет/образ с Suricata 8.x." >&2
    exit 1
  fi
fi

SURICATA_MAJOR="$(get_suricata_major || true)"
if [[ "$SURICATA_MAJOR" != "8" ]]; then
  echo "[ ERROR ] После установки обнаружена неподдерживаемая major-версия Suricata: ${SURICATA_MAJOR:-не определена}." >&2
  exit 1
fi

echo "[4/5] Подготовка служб..."
systemctl enable --now auditd
systemctl enable --now ssh
systemctl disable --now suricata >/dev/null 2>&1 || true

echo "[5/5] Проверка установленных команд..."
for cmd in python3 curl jq tcpdump suricata auditctl ausearch ethtool unzip ssh ss ip ping; do
  command -v "$cmd" >/dev/null || { echo "[ ERROR ] Не найдена команда: $cmd" >&2; exit 1; }
done

echo
suricata --build-info 2>/dev/null | sed -n '1,8p' || true

echo
cat <<'MSG'
[ OK ] Базовые пакеты серверной VM установлены.

Следующие действия выполняются вручную:
1. Убедитесь, что Adapter 1 = NAT / virtio-net, Adapter 2 = Host-Only / virtio-net.
2. Настройте hostname: idps-server (рекомендуется).
3. Настройте Host-Only-интерфейс: 10.13.37.20/24, без gateway и DNS.
4. Оставьте NAT-интерфейс единственным источником default route.
5. Проверьте SSH с хоста на 10.13.37.20:22.
6. Запустите: sudo bash check-server-environment.sh
MSG
