#!/usr/bin/env bash
set -euo pipefail

echo "=== Сетевые интерфейсы ==="
ip -br link

echo
echo "=== IPv4-адреса ==="
ip -br -4 addr

echo
echo "=== Маршрут по умолчанию ==="
ip -4 route show default || true

echo
echo "=== Маршрут к учебной сети ==="
ip -4 route show 10.13.37.0/24 || true

if command -v ethtool >/dev/null 2>&1; then
  echo
  echo "=== Драйверы Ethernet-интерфейсов ==="
  while read -r iface; do
    [[ "$iface" == "lo" ]] && continue
    driver="$(ethtool -i "$iface" 2>/dev/null | awk -F': ' '$1=="driver" {print $2; exit}')"
    [[ -n "$driver" ]] && printf '%-16s %s\n' "$iface" "$driver"
  done < <(ip -o link show | awk -F': ' '{print $2}' | cut -d@ -f1)
fi

echo
cat <<'MSG'
Интерфейс, через который проходит маршрут default, обычно относится к NAT.
Учебный интерфейс IDPS-LAB — второй виртуальный адаптер Host-Only.

Ожидаемая модель:
- обе виртуальные NIC используют драйвер virtio_net;
- idps-client: LAB = 10.13.37.10/24;
- idps-server: LAB = 10.13.37.20/24;
- LAB-интерфейс не имеет default gateway;
- единственный default route остаётся через NAT.
MSG
