#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "[ ERROR ] Запустите скрипт через sudo: sudo bash bootstrap-client.sh" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive

echo "[1/3] Обновление списка пакетов..."
apt-get update

echo "[2/3] Установка инструментов клиентской VM..."
apt-get install -y \
  ca-certificates curl jq tcpdump unzip openssh-client ethtool \
  iproute2 iputils-ping net-tools

echo "[3/3] Проверка установленных команд..."
for cmd in curl jq tcpdump unzip ssh ethtool ip ping; do
  command -v "$cmd" >/dev/null || { echo "[ ERROR ] Не найдена команда: $cmd" >&2; exit 1; }
done

echo
cat <<'MSG'
[ OK ] Базовые пакеты клиентской VM установлены.

Следующие действия выполняются вручную:
1. Убедитесь, что Adapter 1 = NAT / virtio-net, Adapter 2 = Host-Only / virtio-net.
2. Настройте hostname: idps-client (рекомендуется).
3. Настройте Host-Only-интерфейс: 10.13.37.10/24, без gateway и DNS.
4. Оставьте NAT-интерфейс единственным источником default route.
5. Запустите: bash check-client-environment.sh
MSG
