# IDPS Lab 03 bundle v0.3.3 — runtime candidate

ЛР №3 закрепляет Главу 4 курса: точка наблюдения оценивается относительно конкретного сетевого пути. Стенд не перестраивается. В каждом Suricata-run создаются одни и те же два контролируемых потока: HTTP `10.13.37.10 → 10.13.37.20:8080` и ICMP от `IDPS-server` к шлюзу default route. Меняется только capture interface — LAB или NAT.

Live Console работает на `http://10.13.37.20:9090`. Она не генерирует трафик и не запускает Suricata. В v0.3.3 Console стала навигатором эксперимента: сохраняет prediction в браузере, показывает текущий этап, явно указывает VM/терминал для следующей команды, даёт copy-only команды для LAB/NAT runs и сравнивает prediction с фактическим alert-набором после появления обоих EVE. Raw EVE и CLI-проверки остаются source evidence.

Версия v0.3.3 сохраняет исправление определения capture interface из v0.3.1: реальный `Suricata-Main` определяется отдельно от wrapper-процессов, а interface берётся из `-i` или AF_PACKET socket процесса. Старые EVE-файлы до текущего `setup-server.sh` не выдаются за текущий evidence.


v0.3.3 исправляет UX runtime flow: команды HTTP/ICMP остаются видимыми до остановки текущего Suricata-run, а кнопка «Копировать» имеет fallback для HTTP-origin Live Console, где Clipboard API браузера может быть недоступен.
