#!/usr/bin/env bash
set -euo pipefail

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
NAT_GW="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}')"

[[ -n "$LAB_IFACE" ]] || { echo '[FAIL] Не найден интерфейс 10.13.37.20/24.' >&2; exit 1; }
[[ -n "$NAT_IFACE" ]] || { echo '[FAIL] Не найден интерфейс default route.' >&2; exit 1; }
[[ -n "$NAT_GW" ]] || { echo '[FAIL] Не найден шлюз default route.' >&2; exit 1; }
[[ "$LAB_IFACE" != "$NAT_IFACE" ]] || { echo '[FAIL] LAB_IFACE и NAT_IFACE совпали.' >&2; exit 1; }

printf 'LAB_IFACE=%s\nNAT_IFACE=%s\nNAT_GW=%s\n\n' "$LAB_IFACE" "$NAT_IFACE" "$NAT_GW"
echo 'Маршрут до внутреннего клиента:'
ip route get 10.13.37.10
echo
echo 'Маршрут до шлюза default route:'
ip route get "$NAT_GW"
