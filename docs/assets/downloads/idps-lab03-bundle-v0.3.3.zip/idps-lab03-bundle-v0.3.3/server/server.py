#!/usr/bin/env python3
import glob
import json
import os
import re
import socket
import subprocess
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

LAB_IP = "10.13.37.20"
CLIENT_IP = "10.13.37.10"
TARGET_PORT = 8080
DASHBOARD_PORT = 9090
WEBROOT = Path("/opt/idps-lab/webroot")
LOG_DIR = Path("/var/tmp/idps-lab")
ACCESS_LOG = LOG_DIR / "lab3-access.log"
SESSION_FILE = LOG_DIR / "lab3-session-start"
HTTP_SID = 1000003
ICMP_SID = 1000004


def json_response(handler, payload, status=200):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def run_text(cmd, timeout=3):
    try:
        cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return cp.returncode, cp.stdout or "", cp.stderr or ""
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 127, "", str(exc)


def observation_points():
    rc, out, _ = run_text(["ip", "-o", "-4", "addr", "show"])
    lab_iface = None
    if rc == 0:
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[3].startswith("10.13.37.20/"):
                lab_iface = parts[1]
                break

    rc, routes, _ = run_text(["ip", "-4", "route", "show", "default"])
    nat_iface = None
    nat_gw = None
    if rc == 0:
        for line in routes.splitlines():
            parts = line.split()
            if not parts or parts[0] != "default":
                continue
            if "dev" in parts:
                try:
                    nat_iface = parts[parts.index("dev") + 1]
                except (ValueError, IndexError):
                    pass
            if "via" in parts:
                try:
                    nat_gw = parts[parts.index("via") + 1]
                except (ValueError, IndexError):
                    pass
            break
    return {"lab_iface": lab_iface, "nat_iface": nat_iface, "nat_gw": nat_gw}


def _option(parts, flag):
    try:
        return parts[parts.index(flag) + 1]
    except (ValueError, IndexError):
        return None


def _socket_inodes(pid, proc_root="/proc"):
    out = set()
    fd_dir = Path(proc_root) / str(pid) / "fd"
    try:
        entries = list(fd_dir.iterdir())
    except (OSError, PermissionError):
        return out
    for entry in entries:
        try:
            target = os.readlink(entry)
        except (OSError, PermissionError):
            continue
        match = re.fullmatch(r"socket:\[(\d+)\]", target)
        if match:
            out.add(match.group(1))
    return out


def _packet_socket_ifaces(pid, proc_root="/proc", packet_table="/proc/net/packet"):
    """Return interfaces actually used by this process' AF_PACKET sockets."""
    inodes = _socket_inodes(pid, proc_root=proc_root)
    if not inodes:
        return []
    try:
        lines = Path(packet_table).read_text(encoding="utf-8", errors="replace").splitlines()
    except (OSError, PermissionError):
        return []
    if not lines:
        return []

    header = lines[0].split()
    try:
        iface_col = header.index("Iface")
        inode_col = header.index("Inode")
    except ValueError:
        return []

    found = []
    for line in lines[1:]:
        parts = line.split()
        if len(parts) <= max(iface_col, inode_col) or parts[inode_col] not in inodes:
            continue
        try:
            ifindex = int(parts[iface_col])
            name = socket.if_indextoname(ifindex)
        except (ValueError, OSError):
            continue
        if name not in found:
            found.append(name)
    return found


def sensor_process(proc_root="/proc", packet_table="/proc/net/packet"):
    """Find the real Suricata engine and determine its capture interface.

    Do not require '-i' to remain visible in /proc/<pid>/cmdline: Suricata may
    change its process title. Prefer the explicit command-line interface when
    it is still available and fall back to the process' AF_PACKET sockets.
    """
    candidates = []
    for proc_dir in Path(proc_root).glob("[0-9]*"):
        try:
            raw = (proc_dir / "cmdline").read_bytes().replace(b"\x00", b" ").decode("utf-8", "replace").strip()
            comm = (proc_dir / "comm").read_text(encoding="utf-8", errors="replace").strip()
        except (OSError, PermissionError):
            continue

        parts = raw.split() if raw else []
        argv0 = Path(parts[0]).name if parts else ""
        looks_like_engine = comm == "Suricata-Main" or argv0 == "suricata" or "suricata" in raw.lower()
        if not looks_like_engine:
            continue
        if comm == "sudo" or argv0 == "sudo":
            continue

        pid = int(proc_dir.name)
        cmd_iface = _option(parts, "-i")
        log_dir = _option(parts, "-l")
        packet_ifaces = _packet_socket_ifaces(pid, proc_root=proc_root, packet_table=packet_table)

        if cmd_iface:
            interfaces = [cmd_iface]
            source = "cmdline"
        elif packet_ifaces:
            interfaces = packet_ifaces
            source = "af_packet"
        else:
            interfaces = []
            source = None

        score = 0
        if comm == "Suricata-Main":
            score += 100
        if argv0 == "suricata":
            score += 50
        if interfaces:
            score += 20
        candidates.append((score, pid, interfaces, source, log_dir, raw, comm))

    if not candidates:
        return {
            "running": False,
            "pid": None,
            "interface": None,
            "interfaces": [],
            "interface_source": None,
            "log_dir": None,
            "args": None,
            "comm": None,
        }

    _, pid, interfaces, source, log_dir, raw, comm = max(candidates, key=lambda item: (item[0], item[1]))
    return {
        "running": True,
        "pid": pid,
        "interface": interfaces[0] if len(interfaces) == 1 else None,
        "interfaces": interfaces,
        "interface_source": source,
        "log_dir": log_dir,
        "args": raw or None,
        "comm": comm,
    }


def session_started_at():
    try:
        return float(SESSION_FILE.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def newest_file(pattern):
    paths = [Path(p) for p in glob.glob(pattern)]
    paths = [p for p in paths if p.is_file()]
    return max(paths, key=lambda p: p.stat().st_mtime, default=None)


def run_eve_path(run_name):
    if run_name not in {"lab", "nat"}:
        return None
    return newest_file(f"/home/*/lab03-{run_name}-run/eve.json")


def read_run(run_name, limit=20):
    path = run_eve_path(run_name)
    started = session_started_at()
    if path and started is not None and path.stat().st_mtime < started:
        return {
            "run": run_name,
            "path": None,
            "stale_path": str(path),
            "mtime": path.stat().st_mtime,
            "http_alerts": [],
            "icmp_alerts": [],
            "http_events": [],
            "raw_lines": [],
        }
    if not path:
        return {
            "run": run_name,
            "path": None,
            "stale_path": None,
            "mtime": None,
            "http_alerts": [],
            "icmp_alerts": [],
            "http_events": [],
            "raw_lines": [],
        }

    http_alerts = []
    icmp_alerts = []
    http_events = []
    raw_lines = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            et = ev.get("event_type")
            alert = ev.get("alert") or {}
            http = ev.get("http") or {}
            relevant = False
            if et == "alert" and alert.get("signature_id") == HTTP_SID:
                http_alerts.append(ev)
                relevant = True
            elif et == "alert" and alert.get("signature_id") == ICMP_SID:
                icmp_alerts.append(ev)
                relevant = True
            elif et == "http" and ev.get("src_ip") == CLIENT_IP and ev.get("dest_ip") == LAB_IP and ev.get("dest_port") == TARGET_PORT:
                if "LAB3-PLACEMENT" in (http.get("url") or ""):
                    http_events.append(ev)
                    relevant = True
            if relevant:
                raw_lines.append(line)
    except OSError:
        pass

    def compact(ev):
        alert = ev.get("alert") or {}
        http = ev.get("http") or {}
        return {
            "timestamp": ev.get("timestamp"),
            "event_type": ev.get("event_type"),
            "src_ip": ev.get("src_ip"),
            "src_port": ev.get("src_port"),
            "dest_ip": ev.get("dest_ip"),
            "dest_port": ev.get("dest_port"),
            "url": http.get("url"),
            "sid": alert.get("signature_id"),
            "signature": alert.get("signature"),
            "action": alert.get("action"),
        }

    return {
        "run": run_name,
        "path": str(path),
        "stale_path": None,
        "mtime": path.stat().st_mtime,
        "http_alerts": [compact(x) for x in http_alerts[-limit:]],
        "icmp_alerts": [compact(x) for x in icmp_alerts[-limit:]],
        "http_events": [compact(x) for x in http_events[-limit:]],
        "raw_lines": raw_lines[-limit:],
    }


def read_access_log(limit=30):
    if not ACCESS_LOG.is_file():
        return {"path": str(ACCESS_LOG), "lines": []}
    try:
        lines = ACCESS_LOG.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        lines = []
    lines = [line for line in lines if "LAB3-PLACEMENT" in line]
    return {"path": str(ACCESS_LOG), "lines": lines[-limit:]}


class TargetHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        src_ip, src_port = self.client_address
        dst_ip, dst_port = self.server.server_address[:2]
        line = (
            f"timestamp={datetime.now(timezone.utc).isoformat()} "
            f"src={src_ip}:{src_port} dst={dst_ip}:{dst_port} "
            f"method=GET uri={self.path}\n"
        )
        with ACCESS_LOG.open("a", encoding="utf-8") as fh:
            fh.write(line)

        if urlparse(self.path).path == "/health":
            body = b"ok\n"
        else:
            body = (
                "IDPS Lab 3 request received\n"
                f"dst={dst_ip}:{dst_port}\n"
                f"path={self.path}\n"
            ).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


class DashboardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/status":
            json_response(self, {
                "server_time": datetime.now(timezone.utc).isoformat(),
                "session_started_at": session_started_at(),
                "sensor": sensor_process(),
                "observation": observation_points(),
                "lab": read_run("lab"),
                "nat": read_run("nat"),
                "application": read_access_log(),
            })
            return
        if path == "/api/evidence":
            json_response(self, {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "session_started_at": session_started_at(),
                "lab": read_run("lab"),
                "nat": read_run("nat"),
                "application": read_access_log(),
            })
            return
        self.serve_static(path)

    def serve_static(self, path):
        rel = "index.html" if path == "/" else path.lstrip("/")
        candidate = (WEBROOT / rel).resolve()
        root = WEBROOT.resolve()
        if root not in candidate.parents and candidate != root:
            self.send_error(403)
            return
        if not candidate.is_file():
            self.send_error(404)
            return
        ctype = "text/plain; charset=utf-8"
        if candidate.suffix == ".html":
            ctype = "text/html; charset=utf-8"
        elif candidate.suffix == ".css":
            ctype = "text/css; charset=utf-8"
        elif candidate.suffix == ".js":
            ctype = "application/javascript; charset=utf-8"
        body = candidate.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


def serve_dashboard():
    ThreadingHTTPServer((LAB_IP, DASHBOARD_PORT), DashboardHandler).serve_forever()


def main():
    threading.Thread(target=serve_dashboard, daemon=True).start()
    ThreadingHTTPServer((LAB_IP, TARGET_PORT), TargetHandler).serve_forever()


if __name__ == "__main__":
    main()
