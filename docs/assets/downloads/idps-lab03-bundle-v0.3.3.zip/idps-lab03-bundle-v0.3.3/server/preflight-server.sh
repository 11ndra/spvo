#!/usr/bin/env bash
set -u

if [[ $EUID -ne 0 ]]; then
  echo '[FAIL] Запустите через sudo: sudo bash server/preflight-server.sh' >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0
warn=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
wrn(){ echo "[WARN] $*"; warn=$((warn+1)); }

for cmd in ip ss curl jq tcpdump timeout suricata ethtool ping; do
  command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"
done

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
NAT_GW="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}')"

[[ -n "$LAB_IFACE" ]] && ok "LAB_IFACE=$LAB_IFACE" || bad 'не найден LAB_IFACE для 10.13.37.20'
[[ -n "$NAT_IFACE" ]] && ok "NAT_IFACE=$NAT_IFACE" || bad 'не найден интерфейс default route'
[[ -n "$NAT_GW" ]] && ok "NAT_GW=$NAT_GW" || bad 'не найден шлюз default route'
if [[ -n "$LAB_IFACE" && -n "$NAT_IFACE" ]]; then
  [[ "$LAB_IFACE" != "$NAT_IFACE" ]] && ok 'LAB и NAT — разные интерфейсы' || bad 'LAB_IFACE и NAT_IFACE совпадают'
fi

systemctl is-active --quiet idps-lab-web.service && ok 'idps-lab-web.service запущен' || bad 'idps-lab-web.service не запущен'
curl -fsS http://10.13.37.20:8080/health >/dev/null 2>&1 && ok 'HTTP target отвечает на 10.13.37.20:8080' || bad 'HTTP target не отвечает'
curl -fsS http://10.13.37.20:9090/api/status >/dev/null 2>&1 && ok 'Live Console API отвечает на 10.13.37.20:9090' || bad 'Live Console API не отвечает'

[[ -f /var/tmp/idps-lab/lab3-access.log ]] && ok 'lab3-access.log существует' || bad 'нет lab3-access.log'
[[ -f /var/tmp/idps-lab/lab3-session-start ]] && ok 'marker текущей сессии Lab03 существует' || bad 'нет marker текущей сессии Lab03'

if ss -ltn 2>/dev/null | grep -Eq '10\.13\.37\.20:8080[[:space:]]'; then
  ok 'TCP/8080 привязан к 10.13.37.20'
else
  bad 'TCP/8080 не привязан строго к 10.13.37.20'
fi
if ss -ltn 2>/dev/null | grep -Eq '10\.13\.37\.20:9090[[:space:]]'; then
  ok 'TCP/9090 привязан к 10.13.37.20'
else
  bad 'TCP/9090 не привязан строго к 10.13.37.20'
fi

[[ -f /etc/suricata/suricata.yaml ]] && ok 'конфигурация Suricata существует' || bad 'нет /etc/suricata/suricata.yaml'
if command -v suricata >/dev/null 2>&1 && [[ -f /etc/suricata/suricata.yaml ]]; then
  if suricata -T -c /etc/suricata/suricata.yaml -S "$SCRIPT_DIR/lab03.rules" >/tmp/lab03-suricata-test.log 2>&1; then
    ok 'Suricata принимает lab03.rules'
  else
    bad 'suricata -T не пройден; см. /tmp/lab03-suricata-test.log'
  fi
fi

if systemctl is-active --quiet suricata 2>/dev/null; then
  bad 'system Suricata service активен; для лаборатории нужен только manual foreground instance'
else
  ok 'system Suricata service не активен'
fi

if pgrep -x Suricata-Main >/dev/null 2>&1; then
  wrn 'уже запущен manual Suricata-Main; для чистого старта лаборатории остановите предыдущий foreground run'
else
  ok 'manual Suricata-Main до эксперимента не запущен'
fi

for iface in "$LAB_IFACE" "$NAT_IFACE"; do
  [[ -z "$iface" ]] && continue
  if ethtool -k "$iface" >/tmp/lab03-ethtool-$iface.txt 2>/dev/null; then
    if grep -Eq '^(generic-receive-offload|large-receive-offload): on' /tmp/lab03-ethtool-$iface.txt; then
      wrn "$iface: GRO/LRO всё ещё включены; перед capture запустите sudo bash server/prepare-capture.sh"
    else
      ok "$iface: GRO/LRO не включены"
    fi
  fi
done

if [[ $fail -eq 0 ]]; then
  echo 'SERVER PRE-FLIGHT PASSED.'
  ((warn>0)) && echo "Предупреждений: $warn"
else
  echo 'SERVER PRE-FLIGHT FAILED.'
fi
exit $fail
