const $=(s,r=document)=>r.querySelector(s); const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const PKEY='idps-lab03-v033-predictions';
const predictions=Object.assign({lab:null,nat:null},safeParse(localStorage.getItem(PKEY))||{});
let lastData=null;

function safeParse(v){try{return JSON.parse(v)}catch{return null}}
function pill(el,state,text){const x=$(el);x.classList.toggle('ok',state===true);x.classList.toggle('bad',state===false);x.querySelector('span:last-child').textContent=text}
function pointFor(iface,o){if(!iface)return '—';if(iface===o.lab_iface)return 'LAB';if(iface===o.nat_iface)return 'NAT';return 'другая точка'}
function sourceLabel(src){if(src==='cmdline')return 'аргумент -i процесса';if(src==='af_packet')return 'AF_PACKET socket процесса';return 'не подтверждено'}
function predLabel(v){return({http:'только 1000003',icmp:'только 1000004',both:'оба',none:'ни одного'})[v]||'не задан'}
function classify(run){const h=(run.http_alerts||[]).length>0,i=(run.icmp_alerts||[]).length>0;return h&&i?'both':h?'http':i?'icmp':'none'}
function evidenceLabel(found,run){if(!run?.path)return 'run не создан';return found?'найдено':'matching evidence не найдено'}
function hasStage(lines,stage){return (lines||[]).some(x=>x.includes(`stage=${stage}`))}
async function copyText(text,btn){
  const old=btn.textContent;
  let copied=false;
  if(navigator.clipboard&&window.isSecureContext){
    try{await navigator.clipboard.writeText(text);copied=true}catch(_){copied=false}
  }
  if(!copied){
    const ta=document.createElement('textarea');
    ta.value=text;
    ta.setAttribute('readonly','');
    ta.style.position='fixed';ta.style.left='-9999px';ta.style.top='0';
    document.body.appendChild(ta);ta.focus();ta.select();
    try{copied=document.execCommand('copy')}catch(_){copied=false}
    ta.remove();
  }
  btn.textContent=copied?'Скопировано':'Скопируйте вручную';
  btn.classList.toggle('copy-failed',!copied);
  setTimeout(()=>{btn.textContent=old;btn.classList.remove('copy-failed')},1600);
}
function cmdBlock(where,label,command){const a=document.createElement('article');a.className='command-action';const head=document.createElement('div');head.className='command-head';head.innerHTML=`<div><span class="where">${where}</span><strong>${label}</strong></div>`;const b=document.createElement('button');b.className='copy-btn';b.textContent='Копировать';b.addEventListener('click',()=>copyText(command,b));head.appendChild(b);const pre=document.createElement('pre');pre.textContent=command;a.append(head,pre);return a}
function setGuide(title,text,commands=[]){$('#nextTitle').textContent=title;$('#nextText').textContent=text;const box=$('#nextCommands');box.innerHTML='';commands.forEach(c=>box.appendChild(cmdBlock(c.where,c.label,c.command)))}

function savePredictions(){localStorage.setItem(PKEY,JSON.stringify(predictions));renderPredictionButtons()}
function renderPredictionButtons(){
  $$('.prediction').forEach(card=>$$('button[data-v]',card).forEach(btn=>btn.classList.toggle('selected',predictions[card.dataset.run]===btn.dataset.v)));
  $('#predictionHint').textContent=predictions.lab&&predictions.nat?'Оба прогноза сохранены. Теперь подтвердите пути через tcpdump по странице курса и переходите к LAB run.':'Сохраните прогноз для обеих точек до Suricata-runs.';
}
$$('.prediction').forEach(card=>$$('button[data-v]',card).forEach(btn=>btn.addEventListener('click',()=>{predictions[card.dataset.run]=btn.dataset.v;savePredictions();if(lastData)renderGuide(lastData)})));
$('#resetPredictionBtn').addEventListener('click',()=>{predictions.lab=null;predictions.nat=null;localStorage.removeItem(PKEY);renderPredictionButtons();if(lastData)renderGuide(lastData)});
renderPredictionButtons();

function fillRun(name,run){
  const hasPath=!!run.path;
  $(`#${name}RunState`).textContent=hasPath?'EVE создан':'не запускался';
  $(`#${name}HttpEvent`).textContent=evidenceLabel((run.http_events||[]).length>0,run);
  $(`#${name}HttpAlert`).textContent=evidenceLabel((run.http_alerts||[]).length>0,run);
  $(`#${name}IcmpAlert`).textContent=evidenceLabel((run.icmp_alerts||[]).length>0,run);
  if(run.path)$(`#${name}Artifact`).textContent=`EVE: ${run.path}`;
  else if(run.stale_path)$(`#${name}Artifact`).textContent=`Предыдущий EVE не относится к текущей сессии: ${run.stale_path}`;
  else $(`#${name}Artifact`).textContent='EVE текущего запуска пока не найден';
  const raw=run.raw_lines||[];$(`#${name}Raw`).textContent=raw.length?raw.join('\n'):'Соответствующих строк текущего EVE пока нет.';
}

function renderGuide(d){
  const s=d.sensor||{},o=d.observation||{},lines=d.application?.lines||[];
  const ifaces=(s.interfaces||[]).filter(Boolean),iface=s.interface||(ifaces.length===1?ifaces[0]:null),point=pointFor(iface,o);
  const labPath=!!d.lab?.path,natPath=!!d.nat?.path;
  const labSent=hasStage(lines,'suricata-lab'),natSent=hasStage(lines,'suricata-nat');
  const gw=o.nat_gw||'NAT_GW',labIf=o.lab_iface||'LAB_IFACE',natIf=o.nat_iface||'NAT_IFACE';
  const labStart=`rm -rf "$HOME/lab03-lab-run" && mkdir -p "$HOME/lab03-lab-run"\nsudo suricata -k none -c /etc/suricata/suricata.yaml \\\n  -S "$HOME/idps-lab03-bundle-v0.3.3/server/lab03.rules" \\\n  -i ${labIf} -l "$HOME/lab03-lab-run"`;
  const natStart=`rm -rf "$HOME/lab03-nat-run" && mkdir -p "$HOME/lab03-nat-run"\nsudo suricata -k none -c /etc/suricata/suricata.yaml \\\n  -S "$HOME/idps-lab03-bundle-v0.3.3/server/lab03.rules" \\\n  -i ${natIf} -l "$HOME/lab03-nat-run"`;

  if(!predictions.lab||!predictions.nat){setGuide('Сначала сохраните два прогноза','Выберите ожидаемый alert-набор для LAB и NAT выше. Правильный ответ заранее не показывается. После прогноза выполните tcpdump-проверку путей со страницы курса.');return}
  if(s.running&&point==='LAB'){
    const labText=labSent
      ?'HTTP marker уже подтверждён приложением и EVE может обновляться. Команды остаются на экране намеренно: выполните ICMP во втором терминале, затем обновите evidence. Только после выполнения ОБЕИХ команд остановите foreground Suricata одним Ctrl+C.'
      :'Suricata уже захватывает LAB interface. Выполните ОБЕ команды ниже: HTTP на IDPS-client и ICMP во втором терминале IDPS-server. Не останавливайте Suricata после первой команды.';
    setGuide(labSent?'LAB run активен — HTTP уже отправлен, выполните ICMP':'LAB run активен — выполните оба потока',labText,[
      {where:'IDPS-client · терминал',label:labSent?'Поток A — HTTP · уже подтверждён приложением':'Поток A — HTTP',command:"curl -sS 'http://10.13.37.20:8080/LAB3-PLACEMENT?stage=suricata-lab'"},
      {where:'IDPS-server · второй терминал',label:'Поток B — ICMP',command:`ping -c 1 -W 1 ${gw}`}
    ]);
    return
  }
  if(s.running&&point==='NAT'){
    const natText=natSent
      ?'HTTP marker уже подтверждён приложением. Команды остаются на экране намеренно: выполните ICMP во втором терминале, обновите evidence и только после выполнения ОБЕИХ команд остановите foreground Suricata одним Ctrl+C.'
      :'Меняется только capture interface. Выполните ОБЕ команды ниже — тот же HTTP и тот же ICMP, что в LAB run. Не останавливайте Suricata после первой команды.';
    setGuide(natSent?'NAT run активен — HTTP уже отправлен, выполните ICMP':'NAT run активен — повторите оба потока',natText,[
      {where:'IDPS-client · терминал',label:natSent?'Поток A — HTTP · уже подтверждён приложением':'Поток A — HTTP',command:"curl -sS 'http://10.13.37.20:8080/LAB3-PLACEMENT?stage=suricata-nat'"},
      {where:'IDPS-server · второй терминал',label:'Поток B — ICMP',command:`ping -c 1 -W 1 ${gw}`}
    ]);
    return
  }
  if(s.running){setGuide('Suricata запущена в другой точке','Live Console не может связать текущий capture interface с LAB или NAT. Проверьте команду запуска и observation points; не продолжайте эксперимент, пока точка не идентифицирована.');return}
  if(!labPath){setGuide('После tcpdump-проверки начните LAB run','Положительный HTTP capture на LAB и контрастные tcpdump-наблюдения выполняются по странице курса. Затем запустите Suricata на LAB interface и вернитесь сюда.',[
    {where:'IDPS-server · терминал Suricata',label:`Запустить capture на ${labIf}`,command:labStart}
  ]);return}
  if(labPath&&!natPath){setGuide('LAB run сохранён — теперь NAT run','LAB EVE остаётся на диске. Запустите тот же ruleset на NAT interface, затем снова создайте оба контролируемых потока.',[
    {where:'IDPS-server · терминал Suricata',label:`Запустить capture на ${natIf}`,command:natStart}
  ]);return}
  if(labPath&&natPath){setGuide('Оба EVE-артефакта есть — сравните и проверьте raw evidence','Сопоставьте prediction с фактической матрицей ниже. Затем подтвердите alerts через jq в обоих EVE. Отсутствие matching evidence интерпретируйте только вместе с выполненными tcpdump/route/application checks.',[
    {where:'IDPS-server · терминал',label:'Alerts LAB run',command:`jq -c 'select(.event_type=="alert" and (.alert.signature_id==1000003 or .alert.signature_id==1000004)) | {timestamp,src_ip,dest_ip,sid:.alert.signature_id,signature:.alert.signature,action:.alert.action}' "$HOME/lab03-lab-run/eve.json"`},
    {where:'IDPS-server · терминал',label:'Alerts NAT run',command:`jq -c 'select(.event_type=="alert" and (.alert.signature_id==1000003 or .alert.signature_id==1000004)) | {timestamp,src_ip,dest_ip,sid:.alert.signature_id,signature:.alert.signature,action:.alert.action}' "$HOME/lab03-nat-run/eve.json"`}
  ])}
}

function maybeConclusion(data){
  const lines=data.application?.lines||[],labSent=hasStage(lines,'suricata-lab'),natSent=hasStage(lines,'suricata-nat');
  const labReady=!!data.lab?.path,natReady=!!data.nat?.path;const box=$('#conclusion'),cmp=$('#predictionCompare');cmp.innerHTML='';
  if(data.sensor?.running||!labReady||!natReady||!labSent||!natSent){box.classList.add('locked');$('#conclusionText').textContent=data.sensor?.running?'Сначала завершите текущий Suricata-run одним Ctrl+C. Итоговую матрицу сравниваем после остановки сенсора.':'Для сравнения нужны EVE обоих запусков и HTTP-marker каждого run. До этого отсутствие matching evidence не считаем завершённым результатом эксперимента.';return}
  box.classList.remove('locked');
  const labActual=classify(data.lab),natActual=classify(data.nat);
  [['LAB',predictions.lab,labActual],['NAT',predictions.nat,natActual]].forEach(([name,pred,actual])=>{const d=document.createElement('div');d.className='compare-item';const match=pred&&pred===actual;d.innerHTML=`<span>${name}</span><strong>прогноз: ${predLabel(pred)}</strong><strong>факт: ${predLabel(actual)}</strong><em class="${match?'match':'mismatch'}">${pred?(match?'совпал':'не совпал'):'прогноз не задан'}</em>`;cmp.appendChild(d)});
  $('#conclusionText').textContent='Факт здесь означает alert-набор, найденный в EVE конкретного run. Теперь свяжите его с tcpdump, route decision и application log. Даже «matching evidence не найдено» не превращается в утверждение «трафика не было».';
}

async function refresh(){
  try{
    const r=await fetch('/api/status',{cache:'no-store'});if(!r.ok)throw new Error(`HTTP ${r.status}`);const d=await r.json();lastData=d;const s=d.sensor||{},o=d.observation||{};
    const ifaces=(s.interfaces||[]).filter(Boolean);const iface=s.interface||(ifaces.length===1?ifaces[0]:null);
    pill('#sensorPill',s.running?true:null,`Suricata: ${s.running?`PID ${s.pid}`:'не запущена'}`);
    if(!s.running)pill('#ifacePill',null,'Capture interface: —');
    else if(iface)pill('#ifacePill',true,`Capture interface: ${iface} · ${pointFor(iface,o)}`);
    else if(ifaces.length>1)pill('#ifacePill',true,`Capture interfaces: ${ifaces.join(', ')}`);
    else pill('#ifacePill',false,'Capture interface: не подтверждён');
    $('#sensorPid').textContent=s.running?s.pid:'—';$('#sensorIface').textContent=iface||(ifaces.length?ifaces.join(', '):'—');$('#sensorPoint').textContent=iface?pointFor(iface,o):'—';$('#sensorIfaceSource').textContent=s.running?sourceLabel(s.interface_source):'—';$('#sensorLogDir').textContent=s.log_dir||'—';
    $('#pointsText').textContent=`LAB=${o.lab_iface||'—'} · NAT=${o.nat_iface||'—'} · GW=${o.nat_gw||'—'}`;
    fillRun('lab',d.lab||{});fillRun('nat',d.nat||{});
    const lines=d.application?.lines||[];$('#appLog').textContent=lines.length?lines.join('\n'):'Строки LAB3-PLACEMENT пока не найдены.';$('#labDelivery').textContent=hasStage(lines,'suricata-lab')?'обработан приложением':'не отправлен';$('#natDelivery').textContent=hasStage(lines,'suricata-nat')?'обработан приложением':'не отправлен';
    renderGuide(d);maybeConclusion(d);
  }catch(e){lastData=null;pill('#sensorPill',false,'Suricata: status недоступен');pill('#ifacePill',false,'Capture interface: —');$('#sensorPid').textContent='—';$('#sensorIface').textContent='—';$('#sensorPoint').textContent='—';$('#sensorIfaceSource').textContent='—';$('#sensorLogDir').textContent='—';setGuide('Live Console API недоступен',`Не удалось получить /api/status: ${e.message}. Сначала проверьте idps-lab-web.service.`)}
}
$('#refreshBtn').addEventListener('click',refresh);refresh();setInterval(refresh,2500);
