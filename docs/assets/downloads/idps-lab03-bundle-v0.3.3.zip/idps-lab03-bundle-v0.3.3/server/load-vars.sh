#!/usr/bin/env bash
# Source in each new IDPS-server terminal used for Lab03:
# source server/load-vars.sh

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
NAT_GW="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="via"){print $(i+1); exit}}')"

if [[ -z "$LAB_IFACE" || -z "$NAT_IFACE" || -z "$NAT_GW" || "$LAB_IFACE" == "$NAT_IFACE" ]]; then
  echo '[FAIL] Не удалось определить LAB_IFACE/NAT_IFACE/NAT_GW.' >&2
  return 1 2>/dev/null || exit 1
fi

export LAB_IFACE NAT_IFACE NAT_GW
printf 'LAB_IFACE=%s\nNAT_IFACE=%s\nNAT_GW=%s\n' "$LAB_IFACE" "$NAT_IFACE" "$NAT_GW"
