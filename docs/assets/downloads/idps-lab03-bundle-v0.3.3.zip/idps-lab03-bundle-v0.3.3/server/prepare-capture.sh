#!/usr/bin/env bash
set -u

if [[ $EUID -ne 0 ]]; then
  echo '[FAIL] Запустите через sudo: sudo bash server/prepare-capture.sh' >&2
  exit 2
fi

LAB_IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
NAT_IFACE="$(ip -4 route show default | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"

if [[ -z "$LAB_IFACE" || -z "$NAT_IFACE" || "$LAB_IFACE" == "$NAT_IFACE" ]]; then
  echo '[FAIL] Не удалось однозначно определить LAB_IFACE и NAT_IFACE.' >&2
  exit 1
fi

if ! command -v ethtool >/dev/null 2>&1; then
  echo '[FAIL] Не найден ethtool. Запустите подготовку лабораторной среды.' >&2
  exit 1
fi

for iface in "$LAB_IFACE" "$NAT_IFACE"; do
  echo "Настройка захвата на $iface"
  for feature in gro lro gso tso rx tx; do
    if ethtool -K "$iface" "$feature" off >/dev/null 2>&1; then
      printf '  [ OK ] %s off\n' "$feature"
    else
      printf '  [WARN] %s: драйвер не разрешил изменить параметр\n' "$feature"
    fi
  done
  echo '  Текущее состояние ключевых offload-параметров:'
  ethtool -k "$iface" 2>/dev/null \
    | grep -E '^(rx-checksumming|tx-checksumming|tcp-segmentation-offload|generic-segmentation-offload|generic-receive-offload|large-receive-offload):' \
    | sed 's/^/    /' || true
  echo
done

cat <<'MSG'
[ OK ] Best-effort настройка offloading завершена.
Лабораторные live-запуски Suricata дополнительно используют -k none,
поэтому checksum validation отключается только для учебного процесса Suricata.
MSG
