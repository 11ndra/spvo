#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo '[FAIL] Запустите через sudo: sudo bash server/setup-server.sh' >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ip -o -4 addr show | grep -q '10\.13\.37\.20/' || {
  echo '[FAIL] На сервере нет адреса 10.13.37.20/24.' >&2
  ip -br addr
  exit 1
}

for cmd in python3 curl; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "[FAIL] Не найдена команда: $cmd" >&2
    exit 1
  }
done

install -d /opt/idps-lab/webroot /var/tmp/idps-lab
install -m 0755 "$SCRIPT_DIR/server.py" /opt/idps-lab/lab3-server.py
install -m 0644 "$SCRIPT_DIR/lab03.rules" /opt/idps-lab/lab03.rules
rm -rf /opt/idps-lab/webroot/*
cp -a "$SCRIPT_DIR/webroot/." /opt/idps-lab/webroot/

: > /var/tmp/idps-lab/lab3-access.log
chmod 0644 /var/tmp/idps-lab/lab3-access.log
# Marker for the current Lab03 session. Live Console ignores EVE files older than it,
# so evidence left from a previous run cannot silently populate a fresh experiment.
date +%s > /var/tmp/idps-lab/lab3-session-start
chmod 0644 /var/tmp/idps-lab/lab3-session-start

cat >/etc/systemd/system/idps-lab-web.service <<'UNIT'
[Unit]
Description=IDPS course Lab 3 target and visual console
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/idps-lab/lab3-server.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable idps-lab-web.service >/dev/null 2>&1 || true
systemctl restart idps-lab-web.service
sleep 1

curl -fsS http://10.13.37.20:8080/health >/dev/null || {
  echo '[FAIL] Учебный HTTP-сервис не запустился.' >&2
  systemctl status idps-lab-web.service --no-pager
  exit 1
}

curl -fsS http://10.13.37.20:9090/api/status >/dev/null || {
  echo '[FAIL] Live Console не запустилась.' >&2
  systemctl status idps-lab-web.service --no-pager
  exit 1
}

echo '[ OK ] HTTP target: 10.13.37.20:8080'
echo '[ OK ] Live Console: 10.13.37.20:9090'
echo '[ OK ] Новая сессия Lab03 создана; старые EVE-файлы не будут выданы за текущий evidence.'
