#!/usr/bin/env bash
set -u

fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }

for cmd in ip curl; do
  command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"
done

ip -o -4 addr show | grep -q '10\.13\.37\.10/' && ok 'адрес 10.13.37.10 присутствует' || bad 'нет 10.13.37.10/24'

if curl -fsS --max-time 3 http://10.13.37.20:8080/client-check >/dev/null 2>&1; then
  ok 'HTTP target 10.13.37.20:8080 доступен'
else
  bad 'нет доступа к HTTP target 10.13.37.20:8080'
fi

if curl -fsS --max-time 3 http://10.13.37.20:9090/api/status >/dev/null 2>&1; then
  ok 'Live Console 10.13.37.20:9090 доступна'
else
  bad 'нет доступа к Live Console 10.13.37.20:9090'
fi

[[ $fail -eq 0 ]] && echo 'CLIENT CHECK PASSED.' || echo 'CLIENT CHECK FAILED.'
exit $fail
