# IDPS Lab 04 bundle v0.1

ЛР №4 закрепляет методы обнаружения из Главы 5 без написания собственных Suricata rules.

Один контролируемый набор событий сохраняется в:

```text
/var/tmp/idps-lab/lab4-events.jsonl
```

Затем один и тот же файл анализируется четырьмя режимами:

```text
signature  — заранее известный признак;
protocol   — состояние синтетического учебного протокола;
behavior   — фиксированный порог по серии событий;
anomaly    — отклонение burst от измеренного baseline.
```

На сервере:

```bash
sudo bash server/setup-server.sh
sudo bash server/preflight-server.sh
sudo bash server/reset-evidence.sh
```

На клиенте сначала выполните проверку связи:

```bash
bash client/check-client.sh
```

`check-client.sh` создаёт один технический HTTP-запрос, поэтому после него снова очистите журнал на сервере:

```bash
sudo bash server/reset-evidence.sh
```

Только затем запустите чистый сценарий на клиенте:

```bash
bash client/run-scenario.sh
```

Перед burst сценарий выдерживает техническую паузу `2.2 s`, чтобы фиксированное поведенческое окно `2 s` не захватывало события baseline. Внутри самого burst искусственной задержки нет.

После сценария на сервере:

```bash
python3 server/analyze-methods.py --method signature
python3 server/analyze-methods.py --method protocol
python3 server/analyze-methods.py --method behavior
python3 server/analyze-methods.py --method anomaly
python3 server/analyze-methods.py --method all
```

Лаборатория использует синтетический учебный сценарий. Результаты показывают выполнение условий детектора, а не факт реальной атаки или компрометации.
