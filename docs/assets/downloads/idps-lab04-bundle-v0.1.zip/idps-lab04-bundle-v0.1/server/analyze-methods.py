#!/usr/bin/env python3
import argparse
import json
import statistics
from collections import defaultdict, deque
from pathlib import Path
from urllib.parse import parse_qs

DEFAULT_LOG = Path('/var/tmp/idps-lab/lab4-events.jsonl')


def load_events(path: Path):
    events = []
    with path.open(encoding='utf-8') as fh:
        for lineno, line in enumerate(fh, 1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
                event['_line'] = lineno
                event['ts'] = float(event['ts'])
                events.append(event)
            except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
                raise SystemExit(f'[FAIL] Некорректная строка {lineno}: {exc}')
    events.sort(key=lambda e: e['ts'])
    return events


def signature(events):
    hits = [e for e in events if e.get('path') == '/download/LAB4-KNOWN-BAD']
    print('METHOD=signature')
    print('CONDITION=path == /download/LAB4-KNOWN-BAD')
    print(f'MATCHES={len(hits)}')
    for e in hits:
        print(f"SIGNATURE MATCH line={e['_line']} src={e.get('src_ip')} path={e.get('path')}")
    print('INTERPRETATION=Совпало заранее определённое условие; компрометация не доказана.')
    return bool(hits)


def protocol(events):
    state = defaultdict(lambda: 'IDLE')
    violations = []
    for e in events:
        path = e.get('path', '')
        if not path.startswith('/session/'):
            continue
        sid = parse_qs(e.get('query', '')).get('sid', ['missing'])[0]
        key = (e.get('src_ip', 'unknown'), sid)
        action = path.rsplit('/', 1)[-1]
        current = state[key]
        valid = True
        if action == 'start':
            if current == 'IDLE': state[key] = 'OPEN'
            else: valid = False
        elif action == 'data':
            if current != 'OPEN': valid = False
        elif action == 'end':
            if current == 'OPEN': state[key] = 'IDLE'
            else: valid = False
        else:
            continue
        if not valid:
            violations.append((e, sid, current, action))
    print('METHOD=protocol')
    print('MODEL=IDLE --START--> OPEN --DATA*--> OPEN --END--> IDLE')
    print(f'VIOLATIONS={len(violations)}')
    for e, sid, current, action in violations:
        print(f"STATE VIOLATION line={e['_line']} sid={sid} state={current} action={action.upper()}")
    print('INTERPRETATION=Последовательность нарушила синтетическую state-machine; HTTP-атака не доказана.')
    return bool(violations)


def behavior(events, count=5, seconds=2.0):
    by_src = defaultdict(deque)
    hits = []
    active = defaultdict(bool)
    for e in events:
        if e.get('path') != '/catalog':
            continue
        src = e.get('src_ip', 'unknown')
        q = by_src[src]
        q.append(e)
        while q and e['ts'] - q[0]['ts'] > seconds:
            q.popleft()
        if len(q) >= count and not active[src]:
            hits.append((e, src, len(q), e['ts'] - q[0]['ts']))
            active[src] = True
        if len(q) < count:
            active[src] = False
    print('METHOD=behavior')
    print(f'CONDITION=>={count} /catalog requests from one source within {seconds:.1f}s')
    print(f'MATCHES={len(hits)}')
    for e, src, n, width in hits:
        print(f"BEHAVIOR MATCH line={e['_line']} src={src} count={n} window={width:.3f}s")
    print('INTERPRETATION=Выполнен фиксированный временной порог; сравнение с baseline не требовалось.')
    return bool(hits)


def median_interval(events):
    if len(events) < 2:
        return None
    stamps = [e['ts'] for e in events]
    return statistics.median(b - a for a, b in zip(stamps, stamps[1:]))


def anomaly(events, factor=3.0):
    baseline = [e for e in events if e.get('path') == '/catalog' and e.get('phase') == 'baseline']
    burst = [e for e in events if e.get('path') == '/catalog' and e.get('phase') == 'burst']
    base_i = median_interval(baseline)
    burst_i = median_interval(burst)
    print('METHOD=anomaly')
    print(f'BASELINE_EVENTS={len(baseline)} BURST_EVENTS={len(burst)}')
    if base_i is None or burst_i is None or burst_i <= 0:
        print('ANOMALY=INDETERMINATE')
        print('INTERPRETATION=Недостаточно данных для сравнения интервалов.')
        return False
    ratio = base_i / burst_i
    is_anomaly = ratio >= factor
    print(f'BASELINE_MEDIAN_INTERVAL={base_i:.3f}s')
    print(f'BURST_MEDIAN_INTERVAL={burst_i:.3f}s')
    print(f'SPEED_RATIO={ratio:.2f}x THRESHOLD={factor:.2f}x')
    print(f"ANOMALY={'YES' if is_anomaly else 'NO'}")
    print('INTERPRETATION=Оценено отклонение от baseline данного контролируемого прогона; вредоносность не доказана.')
    return is_anomaly


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', default=str(DEFAULT_LOG))
    ap.add_argument('--method', choices=['signature', 'protocol', 'behavior', 'anomaly', 'all'], default='all')
    args = ap.parse_args()
    path = Path(args.input)
    if not path.is_file():
        raise SystemExit(f'[FAIL] Файл не найден: {path}')
    events = load_events(path)
    print(f'INPUT={path}')
    print(f'EVENTS={len(events)}')
    if not events:
        raise SystemExit('[FAIL] Журнал пуст. Сначала выполните сценарий на клиенте.')
    methods = {
        'signature': signature,
        'protocol': protocol,
        'behavior': behavior,
        'anomaly': anomaly,
    }
    if args.method == 'all':
        results = {}
        for name, fn in methods.items():
            print('\n---')
            results[name] = fn(events)
        print('\n=== SUMMARY ===')
        for name in methods:
            print(f"{name.upper()}={'DETECTED' if results[name] else 'NO_DETECTION'}")
    else:
        methods[args.method](events)

if __name__ == '__main__':
    main()
