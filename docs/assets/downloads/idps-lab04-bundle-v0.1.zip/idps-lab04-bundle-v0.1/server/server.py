#!/usr/bin/env python3
import json
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

BIND_IP = "10.13.37.20"
PORT = 8080
LOG_DIR = Path("/var/tmp/idps-lab")
EVENT_LOG = LOG_DIR / "lab4-events.jsonl"

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        parsed = urlsplit(self.path)
        src_ip, src_port = self.client_address
        dst_ip, dst_port = self.server.server_address[:2]
        event = {
            "ts": time.time(),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "src_ip": src_ip,
            "src_port": src_port,
            "dst_ip": dst_ip,
            "dst_port": dst_port,
            "method": "GET",
            "path": parsed.path,
            "query": parsed.query,
            "phase": self.headers.get("X-Lab-Phase", "unlabeled"),
        }
        with EVENT_LOG.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")

        body = (
            "IDPS Lab 4 event recorded\n"
            f"path={parsed.path}\n"
            f"phase={event['phase']}\n"
        ).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return

ThreadingHTTPServer((BIND_IP, PORT), Handler).serve_forever()
