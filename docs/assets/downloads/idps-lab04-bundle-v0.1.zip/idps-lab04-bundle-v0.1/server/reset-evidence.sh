#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo '[FAIL] Запустите через sudo.' >&2; exit 1; fi
LOG=/var/tmp/idps-lab/lab4-events.jsonl
[[ -f "$LOG" ]] || touch "$LOG"
: > "$LOG"
chmod 0644 "$LOG"
echo '[ OK ] lab4-events.jsonl очищен. Следующий сценарий будет отдельным экспериментом.'
