#!/usr/bin/env bash
set -u
if [[ $EUID -ne 0 ]]; then echo '[FAIL] Запустите через sudo.' >&2; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
for cmd in ip curl python3; do command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"; done
ip -o -4 addr show | grep -q '10\.13\.37\.20/' && ok 'адрес 10.13.37.20 присутствует' || bad 'нет 10.13.37.20/24'
systemctl is-active --quiet idps-lab-web.service && ok 'web-сервис запущен' || bad 'web-сервис не запущен'
if curl -fsS -H 'X-Lab-Phase: preflight' http://10.13.37.20:8080/health >/dev/null 2>&1; then ok 'web-сервис отвечает'; else bad 'web-сервис не отвечает'; fi
[[ -f /var/tmp/idps-lab/lab4-events.jsonl ]] && ok 'журнал событий существует' || bad 'нет lab4-events.jsonl'
python3 -m py_compile "$SCRIPT_DIR/analyze-methods.py" >/dev/null 2>&1 && ok 'analyze-methods.py компилируется' || bad 'ошибка Python в analyze-methods.py'
if [[ $fail -eq 0 ]]; then echo 'SERVER PRE-FLIGHT PASSED.'; else echo 'SERVER PRE-FLIGHT FAILED.'; fi
exit $fail
