#!/usr/bin/env bash
set -euo pipefail
BASE='http://10.13.37.20:8080'
req(){
  local phase="$1"; shift
  local path="$1"; shift
  curl -fsS --max-time 3 -H "X-Lab-Phase: $phase" "$BASE$path" >/dev/null
}

echo '[1/4] Baseline: 6 запросов /catalog с интервалом 0.8 с'
for i in 1 2 3 4 5 6; do
  req baseline "/catalog?item=$i"
  [[ "$i" != 6 ]] && sleep 0.8
done

echo '[2/4] Известный маркер для сигнатурного детектора'
req probe '/download/LAB4-KNOWN-BAD'

echo '[3/4] State-machine: сначала намеренное нарушение, затем корректная последовательность'
req probe '/session/data?sid=demo'
req probe '/session/start?sid=demo'
req probe '/session/data?sid=demo'
req probe '/session/end?sid=demo'

echo '[4/4] Burst: отделяем окно от baseline и отправляем 8 /catalog без искусственной задержки'
sleep 2.2
for i in 1 2 3 4 5 6 7 8; do
  req burst "/catalog?item=$i"
done

echo 'SCENARIO COMPLETE. Ожидается 19 событий в чистом журнале.'
