#!/usr/bin/env python3
import argparse
import json
import statistics
from collections import defaultdict, deque
from pathlib import Path
from urllib.parse import parse_qs

DEFAULT_LOG = Path('/var/tmp/idps-lab/lab4-events.jsonl')


def load_events(path: Path):
    events = []
    with path.open(encoding='utf-8') as fh:
        for lineno, line in enumerate(fh, 1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
                event['_line'] = lineno
                event['ts'] = float(event['ts'])
                events.append(event)
            except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
                raise ValueError(f'Некорректная строка {lineno}: {exc}') from exc
    events.sort(key=lambda e: e['ts'])
    return events


def signature_result(events):
    hits = [e for e in events if e.get('path') == '/download/LAB4-KNOWN-BAD']
    return {
        'name': 'signature',
        'detected': bool(hits),
        'condition': 'path == /download/LAB4-KNOWN-BAD',
        'matches': len(hits),
        'hits': [
            {'line': e['_line'], 'src_ip': e.get('src_ip'), 'path': e.get('path')}
            for e in hits
        ],
        'uses_history': False,
        'uses_baseline': False,
        'interpretation': 'Совпало заранее определённое условие; компрометация не доказана.',
    }


def protocol_result(events):
    state = defaultdict(lambda: 'IDLE')
    violations = []
    for e in events:
        path = e.get('path', '')
        if not path.startswith('/session/'):
            continue
        sid = parse_qs(e.get('query', '')).get('sid', ['missing'])[0]
        key = (e.get('src_ip', 'unknown'), sid)
        action = path.rsplit('/', 1)[-1]
        current = state[key]
        valid = True
        if action == 'start':
            if current == 'IDLE':
                state[key] = 'OPEN'
            else:
                valid = False
        elif action == 'data':
            if current != 'OPEN':
                valid = False
        elif action == 'end':
            if current == 'OPEN':
                state[key] = 'IDLE'
            else:
                valid = False
        else:
            continue
        if not valid:
            violations.append({
                'line': e['_line'],
                'sid': sid,
                'state': current,
                'action': action.upper(),
            })
    return {
        'name': 'protocol',
        'detected': bool(violations),
        'model': 'IDLE --START--> OPEN --DATA*--> OPEN --END--> IDLE',
        'violations': violations,
        'uses_history': True,
        'uses_baseline': False,
        'interpretation': 'Последовательность нарушила синтетическую модель состояний; HTTP-атака не доказана.',
    }


def threshold_result(events, count=5, seconds=2.0):
    by_src = defaultdict(deque)
    hits = []
    active = defaultdict(bool)
    for e in events:
        if e.get('path') != '/catalog':
            continue
        src = e.get('src_ip', 'unknown')
        q = by_src[src]
        q.append(e)
        while q and e['ts'] - q[0]['ts'] > seconds:
            q.popleft()
        if len(q) >= count and not active[src]:
            hits.append({
                'line': e['_line'],
                'src_ip': src,
                'count': len(q),
                'window_seconds': e['ts'] - q[0]['ts'],
            })
            active[src] = True
        if len(q) < count:
            active[src] = False
    return {
        'name': 'threshold',
        'detected': bool(hits),
        'count_threshold': count,
        'window_threshold_seconds': seconds,
        'condition': f'>={count} /catalog requests from one source within {seconds:.1f}s',
        'matches': len(hits),
        'hits': hits,
        'uses_history': True,
        'uses_baseline': False,
        'interpretation': 'Выполнен заранее заданный временной порог; сравнение с базовой моделью не требовалось.',
    }


def median_interval(events):
    if len(events) < 2:
        return None
    stamps = [e['ts'] for e in events]
    return statistics.median(b - a for a, b in zip(stamps, stamps[1:]))


def anomaly_result(events, factor=3.0):
    # phase is controlled-experiment ground truth used only to split the known
    # baseline and test burst. It is not a feature a production sensor would
    # normally receive as evidence of maliciousness.
    baseline = [e for e in events if e.get('path') == '/catalog' and e.get('phase') == 'baseline']
    burst = [e for e in events if e.get('path') == '/catalog' and e.get('phase') == 'burst']
    base_i = median_interval(baseline)
    burst_i = median_interval(burst)
    result = {
        'name': 'anomaly',
        'detected': False,
        'status': 'INDETERMINATE',
        'baseline_events': len(baseline),
        'burst_events': len(burst),
        'baseline_median_interval': base_i,
        'burst_median_interval': burst_i,
        'speed_ratio': None,
        'factor_threshold': factor,
        'uses_history': True,
        'uses_baseline': True,
        'interpretation': 'Недостаточно данных для сравнения интервалов.',
    }
    if base_i is None or burst_i is None or burst_i <= 0:
        return result
    ratio = base_i / burst_i
    detected = ratio >= factor
    result.update({
        'detected': detected,
        'status': 'YES' if detected else 'NO',
        'speed_ratio': ratio,
        'interpretation': 'Оценено отклонение от базового профиля данного контролируемого прогона; вредоносность не доказана.',
    })
    return result


def analyze_all(events):
    return {
        'event_count': len(events),
        'signature': signature_result(events),
        'protocol': protocol_result(events),
        'threshold': threshold_result(events),
        'anomaly': anomaly_result(events),
    }


def print_signature(r):
    print('METHOD=signature')
    print(f"CONDITION={r['condition']}")
    print(f"MATCHES={r['matches']}")
    for h in r['hits']:
        print(f"SIGNATURE MATCH line={h['line']} src={h['src_ip']} path={h['path']}")
    print(f"INTERPRETATION={r['interpretation']}")


def print_protocol(r):
    print('METHOD=protocol')
    print(f"MODEL={r['model']}")
    print(f"VIOLATIONS={len(r['violations'])}")
    for h in r['violations']:
        print(f"STATE VIOLATION line={h['line']} sid={h['sid']} state={h['state']} action={h['action']}")
    print(f"INTERPRETATION={r['interpretation']}")


def print_threshold(r):
    print('METHOD=threshold')
    print(f"CONDITION={r['condition']}")
    print(f"MATCHES={r['matches']}")
    for h in r['hits']:
        print(f"THRESHOLD MATCH line={h['line']} src={h['src_ip']} count={h['count']} window={h['window_seconds']:.3f}s")
    print(f"INTERPRETATION={r['interpretation']}")


def print_anomaly(r):
    print('METHOD=anomaly')
    print(f"BASELINE_EVENTS={r['baseline_events']} BURST_EVENTS={r['burst_events']}")
    if r['status'] == 'INDETERMINATE':
        print('ANOMALY=INDETERMINATE')
        print(f"INTERPRETATION={r['interpretation']}")
        return
    print(f"BASELINE_MEDIAN_INTERVAL={r['baseline_median_interval']:.3f}s")
    print(f"BURST_MEDIAN_INTERVAL={r['burst_median_interval']:.3f}s")
    print(f"SPEED_RATIO={r['speed_ratio']:.2f}x THRESHOLD={r['factor_threshold']:.2f}x")
    print(f"ANOMALY={r['status']}")
    print(f"INTERPRETATION={r['interpretation']}")


PRINTERS = {
    'signature': print_signature,
    'protocol': print_protocol,
    'threshold': print_threshold,
    'anomaly': print_anomaly,
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', default=str(DEFAULT_LOG))
    ap.add_argument('--method', choices=['signature', 'protocol', 'threshold', 'anomaly', 'all'], default='all')
    ap.add_argument('--json', action='store_true', help='Вывести структурированный JSON для Live Console.')
    args = ap.parse_args()
    path = Path(args.input)
    if not path.is_file():
        if args.json:
            print(json.dumps({'ok': False, 'error': f'Файл не найден: {path}'}, ensure_ascii=False))
            return 2
        raise SystemExit(f'[FAIL] Файл не найден: {path}')
    try:
        events = load_events(path)
    except ValueError as exc:
        if args.json:
            print(json.dumps({'ok': False, 'error': str(exc)}, ensure_ascii=False))
            return 2
        raise SystemExit(f'[FAIL] {exc}') from exc
    if not events:
        if args.json:
            print(json.dumps({'ok': True, 'input': str(path), 'event_count': 0, 'analysis': None}, ensure_ascii=False))
            return 0
        raise SystemExit('[FAIL] Журнал пуст. Сначала выполните сценарий на клиенте.')

    results = analyze_all(events)
    if args.json:
        payload = {'ok': True, 'input': str(path), 'event_count': len(events), 'analysis': results}
        print(json.dumps(payload, ensure_ascii=False))
        return 0

    print(f'INPUT={path}')
    print(f'EVENTS={len(events)}')
    if args.method == 'all':
        for name in ('signature', 'protocol', 'threshold', 'anomaly'):
            print('\n---')
            PRINTERS[name](results[name])
        print('\n=== SUMMARY ===')
        for name in ('signature', 'protocol', 'threshold', 'anomaly'):
            print(f"{name.upper()}={'DETECTED' if results[name]['detected'] else 'NO_DETECTION'}")
    else:
        PRINTERS[args.method](results[args.method])
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
