#!/usr/bin/env bash
set -euo pipefail
LAB_IP='10.13.37.20'
LAB_IFACE="$(ip -o -4 addr show | awk -v ip="$LAB_IP" '$4 ~ ("^" ip "/") {print $2; exit}')"
if [[ -z "${LAB_IFACE:-}" ]]; then
  echo "[FAIL] Не найден интерфейс с адресом ${LAB_IP}." >&2
  return 1 2>/dev/null || exit 1
fi
export LAB_IP LAB_IFACE
