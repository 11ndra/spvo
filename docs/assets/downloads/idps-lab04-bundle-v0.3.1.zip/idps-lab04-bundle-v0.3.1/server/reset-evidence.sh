#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then
  echo '[FAIL] Запустите через sudo.' >&2
  exit 1
fi
LOG=/var/tmp/idps-lab/lab4-events.jsonl
SESSION=/var/tmp/idps-lab/lab4-session-start
mkdir -p /var/tmp/idps-lab
: > "$LOG"
date +%s > "$SESSION"
chmod 0644 "$LOG" "$SESSION"
echo '[ OK ] lab4-events.jsonl очищен.'
echo '[ OK ] Создан новый marker сессии Lab04; Live Console не будет считать старый EVE текущим evidence.'
