const METHODS = ['signature','protocol','threshold','anomaly'];
const OPTIONS = [
  ['marker','marker — известный признак'],
  ['state','state — нарушение последовательности'],
  ['burst','burst — всплеск частоты'],
  ['none','ничего']
];
const KEY='lab04-prediction-v031';
let prediction={};
try{ prediction=JSON.parse(localStorage.getItem(KEY)||'{}')||{}; }catch{ prediction={}; }

const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));

function renderPrediction(){
  document.querySelectorAll('.prediction').forEach(card=>{
    const method=card.dataset.method;
    const box=card.querySelector('.choices');
    box.innerHTML='';
    OPTIONS.forEach(([v,label])=>{
      const b=document.createElement('button');
      b.textContent=label;
      if(prediction[method]===v) b.classList.add('selected');
      b.onclick=()=>{prediction[method]=v;localStorage.setItem(KEY,JSON.stringify(prediction));renderPrediction();};
      box.appendChild(b);
    });
  });
  const n=METHODS.filter(m=>prediction[m]).length;
  $('predictionHint').textContent=n===4?'Прогноз сохранён. Теперь выполняйте эксперимент.':`Сохранено ${n}/4 прогнозов.`;
}
$('resetPredictionBtn').onclick=()=>{prediction={};localStorage.removeItem(KEY);renderPrediction();};
$('refreshBtn').onclick=()=>refresh();
renderPrediction();

function boolText(v){return v?'DETECTED':'NO DETECTION';}
function phaseCount(phases,key){return phases&&Object.prototype.hasOwnProperty.call(phases,key)?phases[key]:0;}

function actualFragment(method,result){
  if(!result||!result.detected) return 'none';
  if(method==='signature') return 'marker';
  if(method==='protocol') return 'state';
  return 'burst';
}

function renderCompare(analysis,eventCount){
  const box=$('predictionCompare');
  const card=$('compareCard');
  if(eventCount!==19 || !analysis){
    card.classList.add('locked'); box.innerHTML=''; $('compareText').textContent='Сравнение откроется после полного dataset из 19 событий.'; return;
  }
  card.classList.remove('locked');
  box.innerHTML='';
  METHODS.forEach(m=>{
    const actual=actualFragment(m,analysis[m]);
    const expected=prediction[m];
    const div=document.createElement('div');
    const same=expected&&expected===actual;
    div.className='compare-item '+(same?'ok':expected?'bad':'');
    div.innerHTML=`<strong>${esc(m)}</strong><br>prediction: ${esc(expected||'не задан')}<br>evidence: ${esc(actual)}`;
    box.appendChild(div);
  });
  $('compareText').textContent='Совпадение прогноза с фактическим результатом — это проверка вашей модели. Raw JSONL и CLI-вывод остаются первичным evidence.';
}

function render(data){
  const events=data.events||{};
  const count=events.count||0;
  $('eventCount').textContent=count;
  $('labIface').textContent=data.lab_iface||'—';
  $('eventsPill').className='pill '+(count===19?'ok':count>0?'warn':'');
  $('eventsPill').querySelector('span:last-child').textContent=`Events: ${count}/19`;

  const sensor=data.sensor||{};
  $('sensorPid').textContent=sensor.running?(sensor.pid||'running'):'не запущена';
  $('sensorIface').textContent=sensor.interface||(sensor.interfaces||[]).join(', ')||'—';
  $('sensorPill').className='pill '+(sensor.running?'ok':'warn');
  $('sensorPill').querySelector('span:last-child').textContent='Suricata: '+(sensor.running?'running':'stopped');

  const eve=data.suricata||{};
  $('eveState').textContent=eve.path?'найден':'нет текущего EVE';
  $('suricataAlert').textContent=eve.alerts?eve.alerts.length:'0';
  $('suricataHttp').textContent=(eve.http_events||[]).length?'есть':'нет';
  $('suricataSid').textContent=(eve.alerts||[]).length?'есть':'нет';
  $('evePath').textContent='EVE: '+(eve.path|| (eve.stale_path?`старый файл игнорируется: ${eve.stale_path}`:'—'));
  $('rawEve').textContent=(eve.raw_lines||[]).join('\n')||'EVE текущей сессии пока не найден.';

  const phases=events.phase_counts||{};
  $('phaseBaseline').textContent=phaseCount(phases,'baseline');
  $('phaseMarker').textContent=phaseCount(phases,'marker');
  $('phaseState').textContent=phaseCount(phases,'state');
  $('phaseBurst').textContent=phaseCount(phases,'burst');
  $('rawEvents').textContent=(events.raw_lines||[]).join('\n')||'Событий пока нет.';

  const envelope=data.analysis||{};
  const a=envelope.ok && envelope.analysis ? envelope.analysis : null;
  if(a){
    $('signatureResult').textContent=boolText(a.signature.detected);
    $('signatureDetail').textContent=`matches=${a.signature.matches}; условие: ${a.signature.condition}`;
    $('protocolResult').textContent=boolText(a.protocol.detected);
    $('protocolDetail').textContent=`violations=${a.protocol.violations.length}; model=${a.protocol.model}`;
    $('thresholdResult').textContent=boolText(a.threshold.detected);
    $('thresholdDetail').textContent=`matches=${a.threshold.matches}; ${a.threshold.condition}`;
    $('anomalyResult').textContent=a.anomaly.status==='INDETERMINATE'?'INDETERMINATE':`ANOMALY=${a.anomaly.status}`;
    $('anomalyDetail').textContent=a.anomaly.speed_ratio==null?`baseline=${a.anomaly.baseline_events}, burst=${a.anomaly.burst_events}`:`ratio=${a.anomaly.speed_ratio.toFixed(2)}x; threshold=${a.anomaly.factor_threshold.toFixed(2)}x`;
  }else{
    ['signatureResult','protocolResult','thresholdResult','anomalyResult'].forEach(id=>$(id).textContent='—');
    ['signatureDetail','protocolDetail','thresholdDetail','anomalyDetail'].forEach(id=>$(id).textContent='Ожидается dataset.');
  }
  renderCompare(a,count);
}

async function refresh(){
  try{
    const r=await fetch('/api/status',{cache:'no-store'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    render(await r.json());
  }catch(err){
    $('runtimeBoundary').textContent='Live Console API недоступна: '+err;
  }
}
refresh();
setInterval(refresh,2000);
