#!/usr/bin/env python3
import glob
import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
from collections import Counter
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, urlsplit

LAB_IP = '10.13.37.20'
TARGET_PORT = 8080
DASHBOARD_PORT = 9090
LOG_DIR = Path('/var/tmp/idps-lab')
EVENT_LOG = LOG_DIR / 'lab4-events.jsonl'
SESSION_FILE = LOG_DIR / 'lab4-session-start'
WEBROOT = Path('/opt/idps-lab/lab04-webroot')
ANALYZER = Path('/opt/idps-lab/lab04-analyze.py')
SURICATA_SID = 1000005


def json_response(handler, payload, status=200):
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('Content-Length', str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def run_text(cmd, timeout=4):
    try:
        cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return cp.returncode, cp.stdout or '', cp.stderr or ''
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 127, '', str(exc)


def session_started_at():
    try:
        return float(SESSION_FILE.read_text(encoding='utf-8').strip())
    except (OSError, ValueError):
        return None


def read_events(limit=80):
    if not EVENT_LOG.is_file():
        return {'path': str(EVENT_LOG), 'count': 0, 'phase_counts': {}, 'events': [], 'raw_lines': []}
    events = []
    raw_lines = []
    try:
        for lineno, line in enumerate(EVENT_LOG.read_text(encoding='utf-8', errors='replace').splitlines(), 1):
            if not line.strip():
                continue
            raw_lines.append(line)
            try:
                ev = json.loads(line)
                ev['_line'] = lineno
                events.append(ev)
            except json.JSONDecodeError:
                events.append({'_line': lineno, '_parse_error': True, 'raw': line})
    except OSError:
        pass
    phases = Counter(ev.get('phase', 'unknown') for ev in events if isinstance(ev, dict))
    return {
        'path': str(EVENT_LOG),
        'count': len(events),
        'phase_counts': dict(phases),
        'events': events[-limit:],
        'raw_lines': raw_lines[-limit:],
    }


def analyzer_result():
    rc, out, err = run_text([sys.executable, str(ANALYZER), '--input', str(EVENT_LOG), '--method', 'all', '--json'])
    if rc != 0:
        return {'ok': False, 'error': (err or out).strip() or f'analyzer rc={rc}'}
    try:
        return json.loads(out)
    except json.JSONDecodeError as exc:
        return {'ok': False, 'error': f'Некорректный JSON analyzer: {exc}'}


def _option(parts, flag):
    try:
        return parts[parts.index(flag) + 1]
    except (ValueError, IndexError):
        return None


def _socket_inodes(pid, proc_root='/proc'):
    out = set()
    fd_dir = Path(proc_root) / str(pid) / 'fd'
    try:
        entries = list(fd_dir.iterdir())
    except (OSError, PermissionError):
        return out
    for entry in entries:
        try:
            target = os.readlink(entry)
        except (OSError, PermissionError):
            continue
        match = re.fullmatch(r'socket:\[(\d+)\]', target)
        if match:
            out.add(match.group(1))
    return out


def _packet_socket_ifaces(pid, proc_root='/proc', packet_table='/proc/net/packet'):
    inodes = _socket_inodes(pid, proc_root=proc_root)
    if not inodes:
        return []
    try:
        lines = Path(packet_table).read_text(encoding='utf-8', errors='replace').splitlines()
    except (OSError, PermissionError):
        return []
    if not lines:
        return []
    header = lines[0].split()
    try:
        iface_col = header.index('Iface')
        inode_col = header.index('Inode')
    except ValueError:
        return []
    found = []
    for line in lines[1:]:
        parts = line.split()
        if len(parts) <= max(iface_col, inode_col) or parts[inode_col] not in inodes:
            continue
        try:
            ifindex = int(parts[iface_col])
            name = socket.if_indextoname(ifindex)
        except (ValueError, OSError):
            continue
        if name not in found:
            found.append(name)
    return found


def sensor_process(proc_root='/proc', packet_table='/proc/net/packet'):
    candidates = []
    for proc_dir in Path(proc_root).glob('[0-9]*'):
        try:
            raw = (proc_dir / 'cmdline').read_bytes().replace(b'\x00', b' ').decode('utf-8', 'replace').strip()
            comm = (proc_dir / 'comm').read_text(encoding='utf-8', errors='replace').strip()
        except (OSError, PermissionError):
            continue
        parts = raw.split() if raw else []
        argv0 = Path(parts[0]).name if parts else ''
        if comm == 'sudo' or argv0 == 'sudo':
            continue
        if not (comm == 'Suricata-Main' or argv0 == 'suricata' or 'suricata' in raw.lower()):
            continue
        pid = int(proc_dir.name)
        cmd_iface = _option(parts, '-i')
        log_dir = _option(parts, '-l')
        packet_ifaces = _packet_socket_ifaces(pid, proc_root=proc_root, packet_table=packet_table)
        if cmd_iface:
            interfaces = [cmd_iface]
            source = 'cmdline'
        elif packet_ifaces:
            interfaces = packet_ifaces
            source = 'af_packet'
        else:
            interfaces = []
            source = None
        score = (100 if comm == 'Suricata-Main' else 0) + (50 if argv0 == 'suricata' else 0) + (20 if interfaces else 0)
        candidates.append((score, pid, interfaces, source, log_dir, raw, comm))
    if not candidates:
        return {'running': False, 'pid': None, 'interfaces': [], 'interface': None, 'interface_source': None, 'log_dir': None}
    _, pid, interfaces, source, log_dir, raw, comm = max(candidates, key=lambda x: (x[0], x[1]))
    return {
        'running': True,
        'pid': pid,
        'interfaces': interfaces,
        'interface': interfaces[0] if len(interfaces) == 1 else None,
        'interface_source': source,
        'log_dir': log_dir,
        'args': raw or None,
        'comm': comm,
    }


def lab_iface():
    rc, out, _ = run_text(['ip', '-o', '-4', 'addr', 'show'])
    if rc == 0:
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 4 and parts[3].startswith(f'{LAB_IP}/'):
                return parts[1]
    return None


def newest_file(pattern):
    paths = [Path(p) for p in glob.glob(pattern)]
    paths = [p for p in paths if p.is_file()]
    return max(paths, key=lambda p: p.stat().st_mtime, default=None)


def read_eve(limit=30):
    path = newest_file('/home/*/lab04-suricata-run/eve.json')
    started = session_started_at()
    if path and started is not None and path.stat().st_mtime < started:
        return {
            'path': None,
            'stale_path': str(path),
            'alerts': [],
            'http_events': [],
            'raw_lines': [],
        }
    if not path:
        return {'path': None, 'stale_path': None, 'alerts': [], 'http_events': [], 'raw_lines': []}
    alerts = []
    http_events = []
    raw_lines = []
    try:
        for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            if started is not None:
                ts = ev.get('timestamp')
                try:
                    event_epoch = datetime.fromisoformat(ts.replace('Z', '+00:00')).timestamp() if ts else None
                except (TypeError, ValueError):
                    event_epoch = None
                if event_epoch is not None and event_epoch < started:
                    continue
            relevant = False
            alert = ev.get('alert') or {}
            http = ev.get('http') or {}
            if ev.get('event_type') == 'alert' and alert.get('signature_id') == SURICATA_SID:
                alerts.append(ev)
                relevant = True
            if ev.get('event_type') == 'http' and '/download/LAB4-KNOWN-BAD' in (http.get('url') or ''):
                http_events.append(ev)
                relevant = True
            if relevant:
                raw_lines.append(line)
    except OSError:
        pass

    def compact(ev):
        alert = ev.get('alert') or {}
        http = ev.get('http') or {}
        return {
            'timestamp': ev.get('timestamp'),
            'event_type': ev.get('event_type'),
            'src_ip': ev.get('src_ip'),
            'src_port': ev.get('src_port'),
            'dest_ip': ev.get('dest_ip'),
            'dest_port': ev.get('dest_port'),
            'url': http.get('url'),
            'sid': alert.get('signature_id'),
            'signature': alert.get('signature'),
            'action': alert.get('action'),
        }
    return {
        'path': str(path),
        'stale_path': None,
        'alerts': [compact(e) for e in alerts[-limit:]],
        'http_events': [compact(e) for e in http_events[-limit:]],
        'raw_lines': raw_lines[-limit:],
    }


class TargetHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        parsed = urlsplit(self.path)
        src_ip, src_port = self.client_address
        dst_ip, dst_port = self.server.server_address[:2]
        event = {
            'ts': time.time(),
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'src_ip': src_ip,
            'src_port': src_port,
            'dst_ip': dst_ip,
            'dst_port': dst_port,
            'method': 'GET',
            'path': parsed.path,
            'query': parsed.query,
            # phase is controlled-experiment ground truth. It is used to split
            # baseline/test data; it is not itself evidence of maliciousness.
            'phase': self.headers.get('X-Lab-Phase', 'unlabeled'),
        }
        with EVENT_LOG.open('a', encoding='utf-8') as fh:
            fh.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + '\n')
        body = ('IDPS Lab 4 event recorded\n' f"path={parsed.path}\n" f"phase={event['phase']}\n").encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


class DashboardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/status':
            events = read_events()
            json_response(self, {
                'server_time': datetime.now(timezone.utc).isoformat(),
                'session_started_at': session_started_at(),
                'lab_iface': lab_iface(),
                'sensor': sensor_process(),
                'events': events,
                'analysis': analyzer_result(),
                'suricata': read_eve(),
            })
            return
        if path == '/':
            self._send_file(WEBROOT / 'index.html', 'text/html; charset=utf-8')
            return
        if path == '/assets/app.css':
            self._send_file(WEBROOT / 'app.css', 'text/css; charset=utf-8')
            return
        if path == '/assets/app.js':
            self._send_file(WEBROOT / 'app.js', 'application/javascript; charset=utf-8')
            return
        self.send_error(404)

    def _send_file(self, path, content_type):
        try:
            body = path.read_bytes()
        except OSError:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


def main():
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    EVENT_LOG.touch(exist_ok=True)
    target = ThreadingHTTPServer((LAB_IP, TARGET_PORT), TargetHandler)
    dashboard = ThreadingHTTPServer((LAB_IP, DASHBOARD_PORT), DashboardHandler)
    thread = threading.Thread(target=target.serve_forever, name='lab04-target', daemon=True)
    thread.start()
    try:
        dashboard.serve_forever()
    finally:
        target.shutdown()
        dashboard.server_close()
        target.server_close()


if __name__ == '__main__':
    main()
