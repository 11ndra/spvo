#!/usr/bin/env bash
set -u
if [[ $EUID -ne 0 ]]; then echo '[FAIL] Запустите через sudo.' >&2; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
warn(){ echo "[WARN] $*"; }
for cmd in ip curl python3 suricata ss jq; do
  command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"
done
ip -o -4 addr show | grep -q '10\.13\.37\.20/' && ok 'адрес 10.13.37.20 присутствует' || bad 'нет 10.13.37.20/24'
systemctl is-active --quiet idps-lab-web.service && ok 'web/console service запущен' || bad 'idps-lab-web.service не запущен'
if curl -fsS -H 'X-Lab-Phase: preflight' http://10.13.37.20:8080/health >/dev/null 2>&1; then ok 'HTTP target отвечает'; else bad 'HTTP target не отвечает'; fi
curl -fsS http://10.13.37.20:9090/api/status >/dev/null 2>&1 && ok 'Live Console API отвечает' || bad 'Live Console API не отвечает'
ss -ltn 2>/dev/null | grep -Eq '10\.13\.37\.20:8080[[:space:]]' && ok 'TCP/8080 привязан к 10.13.37.20' || bad 'TCP/8080 не привязан строго к 10.13.37.20'
ss -ltn 2>/dev/null | grep -Eq '10\.13\.37\.20:9090[[:space:]]' && ok 'TCP/9090 привязан к 10.13.37.20' || bad 'TCP/9090 не привязан строго к 10.13.37.20'
[[ -f /var/tmp/idps-lab/lab4-events.jsonl ]] && ok 'lab4-events.jsonl существует' || bad 'нет lab4-events.jsonl'
python3 -m py_compile "$SCRIPT_DIR/analyze-methods.py" >/dev/null 2>&1 && ok 'analyze-methods.py компилируется' || bad 'ошибка Python в analyze-methods.py'
python3 -m py_compile "$SCRIPT_DIR/server.py" >/dev/null 2>&1 && ok 'server.py компилируется' || bad 'ошибка Python в server.py'
if command -v suricata >/dev/null 2>&1; then
  suricata -T -c /etc/suricata/suricata.yaml -S "$SCRIPT_DIR/lab04.rules" >/tmp/lab04-suricata-test.out 2>&1 \
    && ok 'Suricata принимает lab04.rules' \
    || { bad 'Suricata не принимает lab04.rules'; tail -n 20 /tmp/lab04-suricata-test.out; }
fi
if systemctl is-active --quiet suricata.service 2>/dev/null; then
  bad 'системный suricata.service активен; лаборатория использует ручной foreground run'
else
  ok 'системный suricata.service не активен'
fi
# preflight itself created one infrastructure request; reset is mandatory before the experiment.
if [[ $fail -eq 0 ]]; then
  echo 'SERVER PRE-FLIGHT PASSED.'
  echo '[NOTE] Теперь выполните: sudo bash server/reset-evidence.sh'
else
  echo 'SERVER PRE-FLIGHT FAILED.'
fi
exit $fail
