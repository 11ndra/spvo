# IDPS Lab 04 bundle v0.3.1

ЛР №4 показывает, что один и тот же контролируемый набор событий может анализироваться по разным основаниям решения. Это **не классификация «четырёх типов IDS»**.

Главный вопрос работы:

```text
если исходные данные одинаковы,
почему разные detector logic выделяют разные части набора?
```

После ЛР студент должен уметь:

- объяснить разницу между известным признаком, состоянием, фиксированным порогом и отклонением от baseline;
- определить, какие входные данные и контекст нужны каждому решению;
- объяснить, почему разные detector logic могут давать разные результаты на одном dataset;
- отделять срабатывание detector от вывода «атака доказана».

Основной application evidence:

```text
/var/tmp/idps-lab/lab4-events.jsonl
```

Live Console:

```text
http://10.13.37.20:9090
```

Console не создаёт трафик и не запускает Suricata. Она визуализирует тот же JSONL, результат `analyze-methods.py` и EVE текущего Suricata-run. CLI и raw JSONL остаются исходным evidence.

## Контракт эксперимента до prediction

Перед прогнозом студенту известны условия сценария и условия анализаторов.

Один dataset содержит:

```text
baseline   — 6 /catalog с интервалом около 0.8 с;
marker     — один /download/LAB4-KNOWN-BAD;
state      — DATA до START, затем START → DATA → END;
burst      — 8 быстрых /catalog после паузы.
```

Аналитические условия:

```text
signature  — path == /download/LAB4-KNOWN-BAD;
protocol   — DATA/END недопустимы в состоянии IDLE;
threshold  — >= 5 /catalog от одного источника за 2 секунды;
anomaly    — burst должен быть не менее чем в 3 раза быстрее baseline по медианному интервалу.
```

Поле `phase` — разметка контролируемого эксперимента. Оно используется для отделения baseline от test burst и не является признаком вредоносности.

Только после изучения этих условий студент фиксирует prediction. Идея prediction — проверить собственную модель, а не угадать скрытые параметры эксперимента.

## Реальный IDPS bridge

Параллельно с созданием dataset Suricata захватывает трафик на LAB-интерфейсе и применяет готовое правило `SID 1000005` к тому же URI `LAB4-KNOWN-BAD`. Студент не пишет правило в этой работе: цель — связать прозрачную учебную модель с реальным EVE evidence. Написание и изменение правил остаётся задачей ЛР №5.

## Быстрый порядок

На `IDPS-server`:

```bash
cd ~/idps-lab04-bundle-v0.3.1
sudo bash server/setup-server.sh
sudo bash server/preflight-server.sh
sudo bash server/reset-evidence.sh
```

На `IDPS-client`:

```bash
cd ~/idps-lab04-bundle-v0.3.1
bash client/check-client.sh
```

После client check снова на сервере:

```bash
sudo bash server/reset-evidence.sh
```

До запуска сценария изучите contract эксперимента в инструкции/Live Console и зафиксируйте prediction.

Затем на `IDPS-server`, отдельный терминал:

```bash
cd ~/idps-lab04-bundle-v0.3.1
source server/load-vars.sh
rm -rf "$HOME/lab04-suricata-run"
mkdir -p "$HOME/lab04-suricata-run"
sudo suricata -k none -c /etc/suricata/suricata.yaml \
  -S "$PWD/server/lab04.rules" \
  -i "$LAB_IFACE" \
  -l "$HOME/lab04-suricata-run"
```

На `IDPS-client`:

```bash
bash client/run-scenario.sh
```

После сообщения `SCENARIO COMPLETE` остановите foreground Suricata одним `Ctrl+C`.

На `IDPS-server`:

```bash
wc -l /var/tmp/idps-lab/lab4-events.jsonl
python3 server/analyze-methods.py --method all
jq 'select(.event_type=="alert" and .alert.signature_id==1000005)' \
  "$HOME/lab04-suricata-run/eve.json"
```

Ожидается 19 application events, по одному детектированию во всех четырёх учебных режимах и Suricata alert SID `1000005` для известного URI marker.
