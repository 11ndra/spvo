#!/usr/bin/env python3
"""Сопоставление Suricata EVE HTTP/alert на шести отдельных HTTP-соединениях ЛР6.

Выводит исходные события, ничего не интерпретирует как атаку.
"""
import json
import re
import sys
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

CASES = "ABCDEF"

def run(path):
    http = {}
    alerts = set()
    with Path(path).open(encoding='utf-8') as file:
        for number, line in enumerate(file, start=1):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"EVE line {number}: invalid JSON: {exc}") from exc
            flow = event.get('flow_id')
            if flow is None:
                continue
            flow = str(flow)
            if event.get('event_type') == 'http':
                uri = (event.get('http') or {}).get('url', '')
                if not isinstance(uri, str):
                    continue
                case = parse_qs(urlsplit(uri).query).get('lab6_case', [''])[0]
                if case not in CASES:
                    continue
                if case in http:
                    raise ValueError(f"CASE {case} found more than once; rerun clean capture")
                http[case] = (flow, uri)
            elif event.get('event_type') == 'alert':
                if (event.get('alert') or {}).get('signature_id') == 1000006:
                    alerts.add(flow)
    print('CASE  HTTP_EVIDENCE  SID1000006  URI')
    for case in CASES:
        data = http.get(case)
        if data is None:
            print(f'{case:<5} NO             ?           (not seen)')
            continue
        flow, uri = data
        hit = 'YES' if flow in alerts else 'NO'
        print(f'{case:<5} YES            {hit:<10}  {uri}')
    missing = [c for c in CASES if c not in http]
    if missing:
        raise ValueError(f"No Suricata HTTP event for cases: {', '.join(missing)}. Check PCAP and EVE configuration; no-result is not TN.")
    print('Все шесть HTTP-событий найдены. Сверьте каждую строку с исходным EVE.')

if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python3 tools/eve-table.py evidence/LABEL/eve.json')
    try:
        run(sys.argv[1])
    except (OSError, ValueError) as exc:
        sys.exit(f'[FAIL] {exc}')
