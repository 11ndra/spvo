#!/usr/bin/env bash
set -euo pipefail
# Только уже известный учебный сервис ЛР 1–5. Не используйте другие IP и порты.
BASE="http://10.13.37.20:8080"
mkdir -p evidence
cases=(
  'A|/LAB6-REVIEW/A?lab6_case=A'
  'B|/LAB6-HEALTH/B?lab6_case=B'
  'C|/lab6-review/C?lab6_case=C'
  'D|/LAB6-REVIEW/D?lab6_case=D'
  'E|/LAB6-STATUS/E?lab6_case=E'
  'F|/normal?lab6_case=F'
)
for row in "${cases[@]}"; do
  IFS='|' read -r id uri <<< "$row"
  code="$(curl --noproxy '*' --silent --show-error --max-time 5 \
    --output "evidence/response-$id.txt" --write-out '%{http_code}' "$BASE$uri")" || {
      printf '[FAIL] CASE=%s URL=%s\n' "$id" "$uri" >&2
      exit 1
    }
  printf 'CASE=%s HTTP=%s URI=%s\n' "$id" "$code" "$uri"
  if [[ "$code" != 200 ]]; then
    echo "[FAIL] Ожидался HTTP 200 от учебного HTTP-сервиса ЛР №5; сценарий следует остановить." >&2
    exit 1
  fi
  if ! grep -Fq "path=$uri" "evidence/response-$id.txt"; then
    echo "[FAIL] CASE=$id: HTTP 200 есть, но ответ не подтвердил путь. Проверьте учебный сервис." >&2
    exit 1
  fi
done
printf 'Six responses confirmed by the application (A-F).\n'
