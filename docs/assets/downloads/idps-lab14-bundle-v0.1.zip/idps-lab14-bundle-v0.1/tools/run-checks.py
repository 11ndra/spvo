#!/usr/bin/env python3
"""Run fixed contracts and retain actual diagnostic output, not just exit codes."""
import json,runpy,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
P=runpy.run_path(str(ROOT/'tools/prepare-cases.py'))
def main():
 P['verify']()
 cases=ROOT/'evidence/cases'
 for name,expected,change in P['SPECS']:
  case=cases/name;m=json.loads((case/'derivation.json').read_text())
  if (m['case'],m['expected_exit'],m['transformation'])!=(name,expected,change):raise ValueError('changed scenario specification: '+name)
  actual={str(f.relative_to(case)):P['digest'](P['checked'](f)) for f in case.rglob('*') if f.is_file() and f.name!='derivation.json'}
  if actual!=m['sha256']:raise ValueError('derived input changed: '+name)
 out=ROOT/'evidence/results';out.mkdir(exist_ok=False)
 rows=[]
 for name,expected,change in P['SPECS']:
  case=cases/name
  r=subprocess.run([sys.executable,str(ROOT/'tools/correlate.py'),str(case/'client'),str(case/'eve.json')],capture_output=True,text=True)
  (out/(name+'.stdout.txt')).write_text(r.stdout);(out/(name+'.stderr.txt')).write_text(r.stderr)
  marker='[INCOMPLETE_OR_INVALID]' if expected==1 else ('OBSERVED_DIFFERENCE' if expected==2 else 'LINKED_RECORDS')
  diagnostic=marker in (r.stderr if expected==1 else r.stdout)
  ok=r.returncode==expected and diagnostic and 'Traceback (most recent call last)' not in r.stderr
  rows.append({'case':name,'expected_exit':expected,'actual_exit':r.returncode,'status':'PASS' if ok else 'FAIL'})
  print(f'{name}: expected={expected} actual={r.returncode} '+rows[-1]['status'])
 (out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
 P['verify']()
 print('PASS means expected validator behavior, not proof of incident absence or trustworthy clocks')
 return 0 if all(r['status']=='PASS' for r in rows) else 1
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,KeyError,TypeError) as exc:sys.exit('[CHECK_FAILED] '+str(exc))
