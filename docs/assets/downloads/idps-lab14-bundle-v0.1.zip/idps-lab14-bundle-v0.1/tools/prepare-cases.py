#!/usr/bin/env python3
"""Create explicitly derived test inputs. Never modify lab13 sources."""
import hashlib,json,subprocess,sys
from datetime import datetime,timedelta,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'
SPECS=[('00-reference',0,'Byte-for-byte reference copy'),('01-missing-http',1,'Remove HTTP record B; preserve its alert'),('02-duplicate-alert',1,'Append duplicate alert B'),('03-wrong-client-port',1,'Change client B local port'),('04-missing-response',1,'Remove client B response'),('05-shuffled',0,'Reverse EVE line order; retain record values'),('06-clock-shift',0,'Shift every EVE timestamp by +300 seconds'),('07-no-alert',2,'Remove all SID 10000130 alerts'),('08-broken-json',1,'Append malformed JSON line')]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def checked(p):
 if any(q.is_symlink() for q in [p,*p.parents]):raise ValueError(f'symlink not allowed: {p}')
 if not p.is_file():raise ValueError(f'missing regular file: {p}')
 return p

def verify():
 m=json.loads((OUT/'sources.json').read_text())
 for name,want in m['sha256'].items():
  if digest(checked(Path(m['source_root'])/name))!=want:raise ValueError('source changed: '+name)
 print('SOURCES_UNCHANGED: all recorded source hashes match')

def main():
 if sys.argv[1:]==['--verify']:verify();return
 if len(sys.argv)!=2:raise ValueError('Usage: python3 tools/prepare-cases.py LAB13_DIRECTORY | --verify')
 source=Path(sys.argv[1]).expanduser().absolute()
 if any(p.is_symlink() for p in [source,*source.parents]):raise ValueError('source path contains symlink')
 source=source.resolve()
 if OUT==source or source in OUT.parents:raise ValueError('output must not be inside lab13 directory')
 if OUT.exists():raise ValueError('evidence already exists; use a new extraction directory')
 names=[f'evidence/client-copy/{c}-{suffix}' for c in 'ABC' for suffix in ('request.bin','response.bin','meta.json')]
 names+=['evidence/analysis/eve.json','evidence/analysis/active.rules','evidence/analysis/completed.txt','evidence/capture/requests.pcap']
 hashes={n:digest(checked(source/n)) for n in names}
 run=subprocess.run([sys.executable,str(ROOT/'tools/correlate.py'),str(source/'evidence/client-copy'),str(source/'evidence/analysis/eve.json')],capture_output=True,text=True)
 if run.returncode!=0:raise ValueError('lab13 baseline must return 0; resolve original evidence first:\n'+run.stdout+run.stderr)
 OUT.mkdir()
 (OUT/'baseline-check.txt').write_text(run.stdout+run.stderr)
 (OUT/'sources.json').write_text(json.dumps({'source_root':str(source),'recorded_at':datetime.now(timezone.utc).isoformat(),'sha256':hashes},indent=2)+'\n')
 # Keep small original inputs byte-for-byte, PCAP remains at its recorded source path.
 snap=OUT/'source-copy';snap.mkdir()
 for n in names:
  if n.endswith('requests.pcap'):continue
  dest=snap/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((source/n).read_bytes())
  if digest(dest)!=hashes[n]:raise ValueError('source changed during copying: '+n)
 verify()
 raw=(snap/'evidence/analysis/eve.json').read_text()
 lines=raw.splitlines();records=[json.loads(x) if x.strip() else {} for x in lines]
 b=json.loads((snap/'evidence/client-copy/B-meta.json').read_text())
 http_b=[i for i,e in enumerate(records) if e.get('event_type')=='http' and e.get('http',{}).get('url')==b['uri']]
 if len(http_b)!=1:raise ValueError('expected one B HTTP record')
 h=records[http_b[0]]
 alert_b=[i for i,e in enumerate(records) if e.get('event_type')=='alert' and e.get('alert',{}).get('signature_id')==10000130 and (e.get('flow_id'),e.get('tx_id'),e.get('src_port'))==(h['flow_id'],h['tx_id'],h['src_port'])]
 if len(alert_b)!=1:raise ValueError('expected one B alert')
 for name,expected,change in SPECS:
  case=OUT/'cases'/name;client=case/'client';client.mkdir(parents=True)
  for c in 'ABC':
   for suffix in ('request.bin','response.bin','meta.json'):
    f=f'{c}-{suffix}';(client/f).write_bytes((snap/'evidence/client-copy'/f).read_bytes())
  eve=case/'eve.json';eve.write_bytes((snap/'evidence/analysis/eve.json').read_bytes())
  altered=list(lines)
  if name=='01-missing-http':del altered[http_b[0]]
  elif name=='02-duplicate-alert':altered.append(lines[alert_b[0]])
  elif name=='03-wrong-client-port':
   meta=dict(b);meta['local']=list(b['local']);meta['local'][1]=1 if b['local'][1]!=1 else 2
   (client/'B-meta.json').write_text(json.dumps(meta,indent=2)+'\n')
  elif name=='04-missing-response':(client/'B-response.bin').unlink()
  elif name=='05-shuffled':altered.reverse()
  elif name=='06-clock-shift':
   altered=[]
   for line in lines:
    if not line.strip():altered.append(line);continue
    e=json.loads(line)
    if 'timestamp' in e:
     t=datetime.fromisoformat(e['timestamp'].replace('Z','+00:00'))
     if t.tzinfo is None:raise ValueError('timestamp lacks timezone')
     e['timestamp']=(t+timedelta(seconds=300)).isoformat()
    altered.append(json.dumps(e))
  elif name=='07-no-alert':altered=[line for line,e in zip(lines,records) if not(e.get('event_type')=='alert' and e.get('alert',{}).get('signature_id')==10000130)]
  elif name=='08-broken-json':altered.append('{"LAB14_BROKEN":')
  if altered!=lines:eve.write_text('\n'.join(altered)+'\n')
  manifest={'kind':'DERIVED_TEST_INPUT_NOT_SENSOR_ORIGINAL','case':name,'transformation':change,'expected_exit':expected,'sha256':{str(p.relative_to(case)):digest(p) for p in sorted(case.rglob('*')) if p.is_file()}}
  (case/'derivation.json').write_text(json.dumps(manifest,indent=2)+'\n')
 verify()
 print('PREPARED: nine derived cases; originals preserved; do not represent copies as sensor originals')
if __name__=='__main__':
 try:main()
 except (OSError,ValueError,KeyError,TypeError) as exc:sys.exit('[PREPARATION_FAILED] '+str(exc)+'; preserve partial output and use a NEW extraction directory')
