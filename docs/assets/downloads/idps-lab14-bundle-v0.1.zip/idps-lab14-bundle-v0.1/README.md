# ЛР №14 — Можно ли доверять результату анализа?

Полная инструкция: https://11ndra.github.io/spvo/labs/lab14/

Работайте на прежнем idps-server. Нужны реальные завершённые артефакты №13: evidence/client-copy (A/B/C request.bin, response.bin, meta.json), evidence/analysis/eve.json, active.rules, completed.txt, evidence/capture/requests.pcap. Новые VM, службы и трафик не нужны. Не создавайте замену отсутствующим оригиналам вручную.

Из этого каталога:

```bash
sudo python3 tools/prepare-cases.py ~/idps-lab13-bundle-v0.1
# Заполните прогнозы в report/lab14-report.md, затем:
sudo python3 tools/run-checks.py
sudo python3 tools/prepare-cases.py --verify
sudo find evidence -type f -print0 | sort -z | sudo xargs -0 sha256sum > lab14-evidence.sha256
```

Передайте фактический путь к №13, если он отличается. Предварительно проверьте её сохранённые манифесты по инструкции. Повтор — только в новой распаковке. Скрипты не перезаписывают evidence/results или evidence.

Сценарии: эталон; пропуск HTTP B; дубликат alert B; противоречащий порт клиента B; отсутствующий ответ B; обратный порядок строк; сдвиг EVE +300 секунд; отсутствие целевых alerts; повреждённый JSON.

Все варианты в evidence/cases — DERIVED_TEST_INPUT_NOT_SENSOR_ORIGINAL. Это производные учебные входы, не новые события сенсора. Оригиналы не меняются. PCAP остаётся в №13 и учитывается по пути и SHA-256. История происхождения и точность часов не удостоверяются одним хешем или успешным сопоставлением.

correlate.py использует проверки опубликованной №13 и локальный HTTP-контракт без сетевых операций. Коды: 0 — связи и ожидаемая картина alerts; 1 + INCOMPLETE_OR_INVALID — непригодные входы; 2 + OBSERVED_DIFFERENCE — связи есть, картина alerts другая. PASS набора тестов означает ожидаемое поведение проверки. Подробные stdout/stderr и фактические коды сохраняются в evidence/results.

Сдайте отчёт, evidence, итоговый манифест и исходные материалы №13. Не редактируйте производные входы после подготовки; прогнозы и аналитические заметки записывайте в отчёт.
