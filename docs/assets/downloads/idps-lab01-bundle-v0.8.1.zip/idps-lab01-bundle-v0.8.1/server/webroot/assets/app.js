const state={completed:new Set(),events:[]};
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const experimentNames=['normal','marker','nested','case'];

function setProgress(){
  const n=state.completed.size;
  $('#progressText').textContent=`${n} / 6`;
  $('#progressBar').style.width=`${Math.min(100,n/6*100)}%`;
}
function markStage(card,stage,kind='ok'){
  const el=card.querySelector(`[data-stage="${stage}"]`);
  if(el){el.classList.remove('ok','warn');el.classList.add(kind)}
}
function pulse(){const f=$('#flow');f.classList.add('pulse');setTimeout(()=>f.classList.remove('pulse'),700)}
async function getJSON(url){const r=await fetch(url,{cache:'no-store'});if(!r.ok)throw new Error(`${r.status} ${r.statusText}`);return r.json()}
function fmtTime(ts){if(!ts)return'—';try{return new Date(ts).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}catch{return ts}}

async function refreshStatus(){
  try{
    const s=await getJSON('/api/status');
    const p=$('#sensorPill');
    if(s.sensor.running){
      p.className='status-pill ok';p.innerHTML='<span class="dot"></span><span>Suricata работает</span>';
      $('#ifaceText').textContent=`интерфейс: ${s.sensor.interface||'—'}`;
      state.completed.add('sensor');
    }else{
      p.className='status-pill bad';p.innerHTML='<span class="dot"></span><span>Suricata не запущена</span>';
      $('#ifaceText').textContent='интерфейс: —';state.completed.delete('sensor');
    }
    $('#evePath').textContent=`EVE: ${s.eve.path||'ещё не найден'}`;
    setProgress();
  }catch(e){
    const p=$('#sensorPill');p.className='status-pill bad';p.innerHTML='<span class="dot"></span><span>Панель не получила status</span>';
  }
}

async function refreshEvents(){
  try{
    const data=await getJSON('/api/events');state.events=data.events||[];
    const box=$('#eventStream');
    if(!state.events.length){box.innerHTML='<p class="muted">Пока нет событий эксперимента.</p>';return}
    box.innerHTML=state.events.slice(-12).reverse().map(ev=>{
      if(ev.event_type==='http')return `<div class="event http"><span>${fmtTime(ev.timestamp)}</span><span class="type">HTTP</span><code>${ev.http?.method||'GET'} ${ev.http?.url||'—'}</code><span class="meta">status ${ev.http?.status??'—'}</span></div>`;
      return `<div class="event alert"><span>${fmtTime(ev.timestamp)}</span><span class="type">ALERT</span><code>SID ${ev.alert?.signature_id}: ${ev.http?.url||'—'}</code><span class="meta">${ev.alert?.action||'—'}</span></div>`;
    }).join('');
  }catch(e){}
}

async function waitForExperiment(path,baseline,expectAlert){
  const deadline=Date.now()+5500;let httpEv=null,alertEv=null;
  while(Date.now()<deadline){
    const data=await getJSON('/api/events');
    const fresh=(data.events||[]).filter(e=>e.seq>baseline);
    httpEv=fresh.find(e=>e.event_type==='http'&&e.http?.url===path)||httpEv;
    alertEv=fresh.find(e=>e.event_type==='alert'&&e.alert?.signature_id===1000001&&e.http?.url===path)||alertEv;
    if(httpEv&&alertEv)break;
    if(httpEv&&!expectAlert&&Date.now()>deadline-2700)break;
    await new Promise(r=>setTimeout(r,350));
  }
  return{httpEv,alertEv};
}

function updateMatrix(name,httpEv,alertEv){
  const row=$(`[data-row="${name}"]`);
  row.querySelector('.cell-http').textContent=httpEv?'✓':'не найден';
  row.querySelector('.cell-alert').textContent=alertEv?'✓':'—';
  row.querySelector('.cell-action').textContent=alertEv?(alertEv.alert?.action||'—'):'—';
  row.classList.add('filled');
}

function maybeUnlockRule(){
  if(experimentNames.every(n=>state.completed.has(n))){
    const panel=$('#rulePanel');panel.classList.remove('locked');
    $('#ruleLock').textContent='Сравните условие с результатами выше';
  }
}

async function runExperiment(card){
  const name=card.dataset.exp;
  const path=card.dataset.path;
  const expectAlert=card.dataset.expect==='alert';
  const result=card.querySelector('.result');
  const evidence=card.querySelector('.experiment-evidence');
  const selected=card.querySelector('.prediction button.selected');
  if(!selected)return;
  const predicted=selected.dataset.predict;
  const baseline=(await getJSON('/api/events')).count||0;
  pulse();
  let responseText='';
  try{
    const r=await fetch(`http://10.13.37.20:8080${path}`,{cache:'no-store'});
    responseText=await r.text();
    if(!r.ok)throw new Error(`HTTP ${r.status}`);
    markStage(card,'request','ok');
  }catch(e){result.className='result error';result.textContent=`Запрос не выполнен: ${e.message}`;return}

  const found=await waitForExperiment(path,baseline,expectAlert);
  markStage(card,'observed',found.httpEv?'ok':'warn');
  markStage(card,'decision',found.alertEv?'warn':'ok');
  const actual=found.alertEv?'alert':'no-alert';
  const correct=predicted===actual;

  if(!found.httpEv){
    result.className='result error';
    result.textContent='HTTP-сервис ответил, но соответствующее HTTP-событие в EVE пока не найдено.';
  }else{
    const outcome=found.alertEv
      ? `В EVE найдено HTTP-событие для ${path}, и учебное правило сформировало alert SID 1000001. action=${found.alertEv.alert?.action||'—'}.`
      : `В EVE найдено HTTP-событие для ${path}, но alert SID 1000001 для этого запроса не сформирован. Это означает, что запрос был доступен сенсору как HTTP-транзакция, однако условие данного учебного правила не выполнилось.`;
    result.className=`result ${found.alertEv?'alert':'neutral'}`;
    result.textContent=`${correct?'Прогноз подтвердился.':'Прогноз не подтвердился.'} ${outcome}`;
    state.completed.add(name);
  }
  evidence.textContent=JSON.stringify({request_response:responseText.trim(),http_event:found.httpEv,alert_event:found.alertEv},null,2);
  updateMatrix(name,found.httpEv,found.alertEv);
  maybeUnlockRule();setProgress();await refreshEvents();
}

$$('.experiment').forEach(card=>{
  const buttons=$$('.prediction button',card);
  const run=$('.run',card);
  buttons.forEach(button=>button.addEventListener('click',()=>{
    buttons.forEach(x=>x.classList.toggle('selected',x===button));
    run.disabled=false;
    const result=$('.result',card);result.className='result';result.textContent='Прогноз сохранён. Теперь проведите эксперимент.';
  }));
  run.addEventListener('click',()=>runExperiment(card));
});

$('#downloadEvidence').addEventListener('click',async()=>{
  const data=await getJSON('/api/evidence');
  const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='lab01-evidence.json';a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);state.completed.add('evidence');setProgress();
});

refreshStatus();refreshEvents();setInterval(refreshStatus,2500);setInterval(refreshEvents,1800);
