#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run with sudo.' >&2; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! ip -o -4 addr show | grep -q '10\.13\.37\.20/'; then
  echo '[FAIL] This VM does not have expected lab address 10.13.37.20/24.' >&2
  ip -br addr
  exit 1
fi
for cmd in python3 curl; do command -v "$cmd" >/dev/null || { echo "[FAIL] missing $cmd"; exit 1; }; done
install -d /opt/idps-lab/webroot /var/tmp/idps-lab
install -m 0755 "$SCRIPT_DIR/server.py" /opt/idps-lab/server.py
install -m 0644 "$SCRIPT_DIR/lab01.rules" /opt/idps-lab/lab01.rules
rm -rf /opt/idps-lab/webroot/*
cp -a "$SCRIPT_DIR/webroot/." /opt/idps-lab/webroot/
cat >/etc/systemd/system/idps-lab-web.service <<'UNIT'
[Unit]
Description=IDPS course laboratory web service and visual console
After=network.target
[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/idps-lab/server.py
Restart=on-failure
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable idps-lab-web.service >/dev/null 2>&1 || true
systemctl restart idps-lab-web.service
sleep 1
curl -fsS http://10.13.37.20:8080/ >/dev/null || { echo '[FAIL] target web service did not start'; systemctl status idps-lab-web.service --no-pager; exit 1; }
curl -fsS http://10.13.37.20:9090/api/status >/dev/null || { echo '[FAIL] visual console did not start'; systemctl status idps-lab-web.service --no-pager; exit 1; }
echo '[ OK ] lab target is available on 10.13.37.20:8080'
echo '[ OK ] visual console is available on 10.13.37.20:9090'
