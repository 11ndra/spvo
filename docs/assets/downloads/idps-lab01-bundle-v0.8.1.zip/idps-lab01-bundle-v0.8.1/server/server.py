#!/usr/bin/env python3
import glob
import json
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

LAB_IP = "10.13.37.20"
CLIENT_IP = "10.13.37.10"
TARGET_PORT = 8080
DASHBOARD_PORT = 9090
WEBROOT = Path("/opt/idps-lab/webroot")
RULE_PATH = Path("/opt/idps-lab/lab01.rules")
SID = 1000001
EXPERIMENT_PATHS = (
    "/normal",
    "/ATTACK-LAB",
    "/test/ATTACK-LAB",
    "/attack-lab",
)


def json_response(handler, payload, status=200):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def newest_file(pattern):
    paths = [Path(p) for p in glob.glob(pattern)]
    paths = [p for p in paths if p.is_file()]
    return max(paths, key=lambda p: p.stat().st_mtime, default=None)


def eve_path():
    candidates = []
    for pattern in (
        "/home/*/lab01-output/eve.json",
        "/var/tmp/idps-lab/lab01-output/eve.json",
    ):
        p = newest_file(pattern)
        if p:
            candidates.append(p)
    return max(candidates, key=lambda p: p.stat().st_mtime, default=None)


def suricata_log_path():
    return newest_file("/home/*/lab01-output/suricata.log")


def sensor_process():
    for proc in glob.glob("/proc/[0-9]*/cmdline"):
        try:
            raw = Path(proc).read_bytes().replace(b"\x00", b" ").decode("utf-8", "replace").strip()
        except (OSError, PermissionError):
            continue
        if not raw or "suricata" not in raw.lower():
            continue
        if " -i " not in f" {raw} ":
            continue
        parts = raw.split()
        iface = None
        try:
            iface = parts[parts.index("-i") + 1]
        except (ValueError, IndexError):
            pass
        return {
            "running": True,
            "pid": int(Path(proc).parent.name),
            "interface": iface,
            "args": raw,
        }
    return {"running": False, "pid": None, "interface": None, "args": None}


def rule_info():
    if not RULE_PATH.is_file():
        return {
            "present": False,
            "sid": SID,
            "buffer": "http.uri",
            "marker": "ATTACK-LAB",
            "case_sensitive": True,
        }
    try:
        text = RULE_PATH.read_text(encoding="utf-8", errors="replace")
    except OSError:
        text = ""
    return {
        "present": True,
        "sid": SID,
        "buffer": "http.uri",
        "marker": "ATTACK-LAB",
        "case_sensitive": "nocase" not in text,
        "contains_sid": f"sid:{SID}" in text,
        "contains_marker": 'content:"ATTACK-LAB"' in text,
        "relevant_condition": 'http.uri; content:"ATTACK-LAB";',
    }


def read_relevant_events(limit=120):
    path = eve_path()
    if not path:
        return {"path": None, "count": 0, "events": []}
    relevant = []
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    ev = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if ev.get("src_ip") != CLIENT_IP or ev.get("dest_ip") != LAB_IP:
                    continue
                if ev.get("dest_port") != TARGET_PORT:
                    continue
                et = ev.get("event_type")
                http = ev.get("http") or {}
                url = http.get("url")
                if et == "http" and url in EXPERIMENT_PATHS:
                    relevant.append(ev)
                elif et == "alert" and (ev.get("alert") or {}).get("signature_id") == SID:
                    relevant.append(ev)
    except OSError:
        return {"path": str(path), "count": 0, "events": []}

    total = len(relevant)
    start_seq = max(1, total - limit + 1)
    result = []
    for idx, ev in enumerate(relevant[-limit:], start=start_seq):
        et = ev.get("event_type")
        http = ev.get("http") or {}
        compact = {
            "seq": idx,
            "timestamp": ev.get("timestamp"),
            "event_type": et,
            "src_ip": ev.get("src_ip"),
            "src_port": ev.get("src_port"),
            "dest_ip": ev.get("dest_ip"),
            "dest_port": ev.get("dest_port"),
            "proto": ev.get("proto"),
            "app_proto": ev.get("app_proto"),
            "flow_id": ev.get("flow_id"),
            "http": {
                "url": http.get("url"),
                "method": http.get("http_method"),
                "status": http.get("status"),
                "user_agent": http.get("http_user_agent"),
            },
        }
        if et == "alert":
            alert = ev.get("alert") or {}
            compact["alert"] = {
                "signature_id": alert.get("signature_id"),
                "signature": alert.get("signature"),
                "action": alert.get("action"),
                "severity": alert.get("severity"),
            }
        result.append(compact)
    return {"path": str(path), "count": total, "events": result}


def recent_engine_info():
    path = suricata_log_path()
    info = {"path": str(path) if path else None, "engine_started": False, "rule_loaded": False, "drops": None}
    if not path:
        return info
    try:
        text = path.read_text(encoding="utf-8", errors="replace")[-12000:]
    except OSError:
        return info
    info["engine_started"] = "Engine started" in text
    info["rule_loaded"] = "1 rules successfully loaded" in text
    for line in reversed(text.splitlines()):
        if "drops:" in line and "device:" in line:
            info["drops"] = line.strip()
            break
    return info


class TargetHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path != "/" and path not in EXPERIMENT_PATHS:
            self.send_error(404)
            return
        display_path = path
        body = f"IDPS Lab 1 request received\npath={display_path}\n".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


class DashboardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/status":
            ev = read_relevant_events(limit=8)
            json_response(self, {
                "server_time": datetime.now(timezone.utc).isoformat(),
                "lab": {
                    "client_ip": CLIENT_IP,
                    "server_ip": LAB_IP,
                    "target_port": TARGET_PORT,
                    "experiment_paths": EXPERIMENT_PATHS,
                },
                "sensor": sensor_process(),
                "rule": rule_info(),
                "engine": recent_engine_info(),
                "eve": {"path": ev["path"], "event_count": ev["count"]},
            })
            return
        if path == "/api/events":
            json_response(self, read_relevant_events(limit=120))
            return
        if path == "/api/evidence":
            json_response(self, {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "status": {
                    "sensor": sensor_process(),
                    "rule": rule_info(),
                    "engine": recent_engine_info(),
                },
                "relevant_events": read_relevant_events(limit=120),
                "interpretation_boundary": [
                    "HTTP-событие подтверждает, что в этом запуске Suricata зарегистрировала соответствующую HTTP-транзакцию.",
                    "Alert SID 1000001 подтверждает срабатывание конкретного учебного правила на наблюдаемом запросе.",
                    "Отсутствие alert не означает отсутствие трафика, если HTTP-событие присутствует.",
                    "Alert сам по себе не доказывает эксплуатацию, компрометацию или предотвращение.",
                ],
            })
            return
        self.serve_static(path)

    def serve_static(self, path):
        rel = "index.html" if path == "/" else path.lstrip("/")
        candidate = (WEBROOT / rel).resolve()
        root = WEBROOT.resolve()
        if root not in candidate.parents and candidate != root:
            self.send_error(403)
            return
        if not candidate.is_file():
            self.send_error(404)
            return
        ctype = "text/plain; charset=utf-8"
        if candidate.suffix == ".html":
            ctype = "text/html; charset=utf-8"
        elif candidate.suffix == ".css":
            ctype = "text/css; charset=utf-8"
        elif candidate.suffix == ".js":
            ctype = "application/javascript; charset=utf-8"
        body = candidate.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


def serve_dashboard():
    ThreadingHTTPServer((LAB_IP, DASHBOARD_PORT), DashboardHandler).serve_forever()


def main():
    threading.Thread(target=serve_dashboard, daemon=True).start()
    ThreadingHTTPServer((LAB_IP, TARGET_PORT), TargetHandler).serve_forever()


if __name__ == "__main__":
    main()
