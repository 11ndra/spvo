# ЛР №2 — пакет v0.5

Каноническая среда: две VM.

- idps-client: Ubuntu Desktop 24.04, 10.13.37.10
- idps-server: Ubuntu Server 24.04, 10.13.37.20

На сервере выполните `sudo bash server/setup-server.sh`, затем `sudo bash server/preflight-server.sh`.
На клиенте выполните `bash client/check-client.sh`.
После успешных проверок следуйте странице ЛР №2 на портале курса.

Изменение v0.5: учебный HTTP-сервис привязан только к адресу IDPS-LAB 10.13.37.20:8080.
