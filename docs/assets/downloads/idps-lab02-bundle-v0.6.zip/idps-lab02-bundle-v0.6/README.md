# ЛР №2 — v0.6

Тема: один контролируемый эпизод и два источника данных — Suricata и Linux Audit.

Используется та же базовая среда, что и в ЛР №1. VM заново не разворачиваются.

Логика работы:

```text
HTTP GET /lab2-trigger/LAB2-NET
        ↓
приложение на idps-server
        ↓
изменение /var/tmp/idps-lab/lab2-evidence.txt
        ↓
два независимых артефакта
├─ Suricata EVE alert SID 1000002
└─ Linux Audit event key=idps_lab_host
```

## 1. Подготовка сервера

На `idps-server`:

```bash
sudo bash server/setup-server.sh
sudo bash server/preflight-server.sh
```

Preflight подтверждает базовые компоненты, но намеренно **не устанавливает правило Linux Audit за студента**.

## 2. Подготовка Linux Audit

На `idps-server`:

```bash
sudo mkdir -p /var/tmp/idps-lab
sudo rm -f /var/tmp/idps-lab/lab2-evidence.txt
sudo auditctl -D -k idps_lab_host 2>/dev/null || true

sudo auditctl \
  -a always,exit \
  -F arch=b64 \
  -F dir=/var/tmp/idps-lab/ \
  -F perm=wa \
  -F key=idps_lab_host

sudo auditctl -l -k idps_lab_host
```

Это правило просит Linux Audit фиксировать операции записи/изменения атрибутов внутри `/var/tmp/idps-lab/` и помечать соответствующие события ключом `idps_lab_host`.

## 3. Проверка и запуск Suricata

На `idps-server`:

```bash
LAB_IFACE=$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\/24$/ {print $2; exit}')
echo "$LAB_IFACE"

sudo suricata -T \
  -c /etc/suricata/suricata.yaml \
  -S server/lab02.rules

rm -rf "$HOME/lab02-output"
mkdir -p "$HOME/lab02-output"

sudo suricata \
  -k none \
  -c /etc/suricata/suricata.yaml \
  -S "$PWD/server/lab02.rules" \
  -i "$LAB_IFACE" \
  -l "$HOME/lab02-output"
```

Оставьте эту SSH-сессию с Suricata работающей.

## 4. Проверка клиента

На `idps-client`:

```bash
bash client/check-client.sh
```

После `CLIENT CHECK PASSED.` откройте в браузере клиента:

```text
http://10.13.37.20:9090
```

Live Console не заменяет raw evidence. Она помогает сначала визуально сравнить два источника, а затем те же факты проверяются через `jq` и `ausearch`.

## 5. После визуального эксперимента

На `idps-server` во второй SSH-сессии проверьте сетевой артефакт:

```bash
jq -c '
  select(.event_type=="alert" and .alert.signature_id==1000002) |
  {
    timestamp,
    src_ip,
    dest_ip,
    url:.http.url,
    sid:.alert.signature_id,
    action:.alert.action
  }
' "$HOME/lab02-output/eve.json"
```

Затем хостовый артефакт:

```bash
sudo ausearch -k idps_lab_host -ts recent -i
```

`ausearch` группирует связанные Linux Audit records. Один логический audit event может включать несколько записей, например `SYSCALL`, `PATH`, `CWD` и `PROCTITLE`, объединённых одним serial.

## 6. Завершение

Suricata остановите `Ctrl+C` один раз и дождитесь возврата приглашения оболочки.

После сохранения evidence правило Lab02 можно удалить:

```bash
sudo auditctl -D -k idps_lab_host
```

Цель работы — не запомнить две команды, а научиться отвечать на вопрос: **какой конкретный факт поддерживается каким конкретным источником данных и где заканчиваются границы этого вывода**.
