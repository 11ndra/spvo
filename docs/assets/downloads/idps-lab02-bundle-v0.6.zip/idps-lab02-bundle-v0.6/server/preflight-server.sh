#!/usr/bin/env bash
set -u
[[ $EUID -eq 0 ]] || { echo '[FAIL] Запустите через sudo: sudo bash server/preflight-server.sh'; exit 1; }
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
warn(){ echo "[WARN] $*"; }

for c in ip curl jq tcpdump suricata auditctl ausearch; do
  command -v "$c" >/dev/null 2>&1 && ok "command: $c" || bad "missing command: $c"
done

ip -o -4 addr show | grep -q '10\.13\.37\.20/24' && ok 'lab address 10.13.37.20/24 is present' || bad 'expected address 10.13.37.20/24 is missing'
IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\/24$/ {print $2; exit}')"
[[ -n "$IFACE" ]] && ok "lab interface: $IFACE" || bad 'cannot identify lab interface'

systemctl is-active --quiet idps-lab-web.service && ok 'lab web service is running' || bad 'idps-lab-web.service is not running'
curl -fsS http://10.13.37.20:8080/ >/dev/null 2>&1 && ok 'target HTTP service answers on 10.13.37.20:8080' || bad 'target HTTP service does not answer on 10.13.37.20:8080'
curl -fsS http://10.13.37.20:9090/api/status >/dev/null 2>&1 && ok 'visual console answers on 10.13.37.20:9090' || bad 'visual console does not answer on 10.13.37.20:9090'

[[ -f /etc/suricata/suricata.yaml ]] && ok 'Suricata config exists' || bad 'missing /etc/suricata/suricata.yaml'
if command -v suricata >/dev/null 2>&1; then
  suricata -T -c /etc/suricata/suricata.yaml -S "$SCRIPT_DIR/lab02.rules" >/tmp/lab02-test.log 2>&1 && ok 'Suricata + lab02.rules' || bad 'Suricata rule/config check failed; see /tmp/lab02-test.log'
fi

if systemctl is-active --quiet suricata 2>/dev/null; then
  bad 'system Suricata service is active; expected manual lab instance only'
else
  ok 'system Suricata service is not active'
fi

if command -v auditctl >/dev/null 2>&1; then
  st="$(auditctl -s 2>/dev/null || true)"
  en="$(awk '$1=="enabled" {print $2; exit}' <<<"$st")"
  [[ "$en" == 1 ]] && ok 'Linux Audit is enabled and mutable' || bad "Linux Audit enabled state is ${en:-unknown}; expected 1"
  auditctl -l 2>/dev/null | grep -Eq '(^|[[:space:]])never,task([[:space:]]|$)' && bad 'never,task audit rule is active' || ok 'no never,task rule detected'
fi
(systemctl is-active --quiet auditd 2>/dev/null || pgrep -x auditd >/dev/null 2>&1) && ok 'auditd is running' || bad 'auditd is not running'

if auditctl -l 2>/dev/null | grep -q 'idps_lab_host'; then
  warn 'Lab02 audit rule already exists. For a clean run, remove it with: sudo auditctl -D -k idps_lab_host'
else
  ok 'Lab02 audit rule is not installed yet; student will add it manually'
fi

[[ $fail -eq 0 ]] && echo 'SERVER PRE-FLIGHT PASSED.' || echo 'SERVER PRE-FLIGHT FAILED.'
exit $fail
