#!/usr/bin/env python3
import glob
import json
import re
import subprocess
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

LAB_IP = "10.13.37.20"
CLIENT_IP = "10.13.37.10"
TARGET_PORT = 8080
DASHBOARD_PORT = 9090
WEBROOT = Path("/opt/idps-lab/webroot")
EVIDENCE_DIR = Path("/var/tmp/idps-lab")
EVIDENCE_FILE = EVIDENCE_DIR / "lab2-evidence.txt"
SID = 1000002
AUDIT_KEY = "idps_lab_host"
TRIGGER_PATH = "/lab2-trigger/LAB2-NET"


def json_response(handler, payload, status=200):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def newest_file(pattern):
    paths = [Path(p) for p in glob.glob(pattern)]
    paths = [p for p in paths if p.is_file()]
    return max(paths, key=lambda p: p.stat().st_mtime, default=None)


def eve_path():
    return newest_file("/home/*/lab02-output/eve.json")


def sensor_process():
    for proc in glob.glob("/proc/[0-9]*/cmdline"):
        try:
            raw = Path(proc).read_bytes().replace(b"\x00", b" ").decode("utf-8", "replace").strip()
        except (OSError, PermissionError):
            continue
        if not raw or "suricata" not in raw.lower() or " -i " not in f" {raw} ":
            continue
        parts = raw.split()
        iface = None
        try:
            iface = parts[parts.index("-i") + 1]
        except (ValueError, IndexError):
            pass
        return {"running": True, "pid": int(Path(proc).parent.name), "interface": iface, "args": raw}
    return {"running": False, "pid": None, "interface": None, "args": None}


def run_text(cmd, timeout=3):
    try:
        cp = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return cp.returncode, (cp.stdout or ""), (cp.stderr or "")
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 127, "", str(exc)


def audit_state():
    rc_status, status_out, status_err = run_text(["auditctl", "-s"])
    enabled = None
    if rc_status == 0:
        match = re.search(r"^enabled\s+(\d+)\s*$", status_out, re.M)
        if match:
            enabled = int(match.group(1))

    rc_rules, rules_out, rules_err = run_text(["auditctl", "-l"])
    rule_lines = [line for line in rules_out.splitlines() if AUDIT_KEY in line]
    never_task = any(re.search(r"(^|\s)never,task(\s|$)", line) for line in rules_out.splitlines())
    ready = enabled == 1 and bool(rule_lines) and not never_task
    return {
        "ready": ready,
        "enabled": enabled,
        "rule_present": bool(rule_lines),
        "rule_lines": rule_lines,
        "never_task": never_task,
        "status_error": status_err.strip() if rc_status != 0 else None,
        "rules_error": rules_err.strip() if rc_rules != 0 else None,
    }


def read_network_events(limit=40):
    path = eve_path()
    if not path:
        return {"path": None, "count": 0, "events": []}
    relevant = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                ev = json.loads(line)
            except json.JSONDecodeError:
                continue
            if ev.get("src_ip") != CLIENT_IP or ev.get("dest_ip") != LAB_IP or ev.get("dest_port") != TARGET_PORT:
                continue
            http = ev.get("http") or {}
            url = http.get("url") or ""
            if not url.startswith(TRIGGER_PATH):
                continue
            et = ev.get("event_type")
            if et == "http" or (et == "alert" and (ev.get("alert") or {}).get("signature_id") == SID):
                relevant.append(ev)
    except OSError:
        return {"path": str(path), "count": 0, "events": []}

    total = len(relevant)
    start = max(1, total - limit + 1)
    out = []
    for seq, ev in enumerate(relevant[-limit:], start=start):
        http = ev.get("http") or {}
        alert = ev.get("alert") or {}
        item = {
            "seq": seq,
            "timestamp": ev.get("timestamp"),
            "event_type": ev.get("event_type"),
            "src_ip": ev.get("src_ip"),
            "src_port": ev.get("src_port"),
            "dest_ip": ev.get("dest_ip"),
            "dest_port": ev.get("dest_port"),
            "http": {"url": http.get("url"), "method": http.get("http_method"), "status": http.get("status")},
        }
        if ev.get("event_type") == "alert":
            item["alert"] = {
                "signature_id": alert.get("signature_id"),
                "signature": alert.get("signature"),
                "action": alert.get("action"),
            }
        out.append(item)
    return {"path": str(path), "count": total, "events": out}


def _field(text, name):
    match = re.search(rf'(?:^|\s){re.escape(name)}=("[^"]*"|\S+)', text)
    if not match:
        return None
    value = match.group(1)
    return value[1:-1] if value.startswith('"') and value.endswith('"') else value


def read_audit_latest():
    rc, stdout, _ = run_text(["ausearch", "-k", AUDIT_KEY, "-ts", "recent", "-i"])
    text = stdout.strip()
    if rc not in (0, 1) or not text or "<no matches>" in text:
        return {"found": False, "serial": None, "raw": None}

    blocks = [block.strip() for block in re.split(r"^----\s*$", text, flags=re.M) if block.strip()]
    chosen = None
    for block in reversed(blocks):
        if str(EVIDENCE_FILE) in block or AUDIT_KEY in block:
            chosen = block
            break
    if not chosen:
        return {"found": False, "serial": None, "raw": None}

    serials = re.findall(r"msg=audit\([^)]*:(\d+)\)", chosen)
    path_match = re.search(r'(?:name|path)="([^"]*lab2-evidence\.txt)"', chosen)
    return {
        "found": True,
        "serial": int(serials[-1]) if serials else None,
        "path": path_match.group(1) if path_match else str(EVIDENCE_FILE) if str(EVIDENCE_FILE) in chosen else None,
        "pid": _field(chosen, "pid"),
        "ppid": _field(chosen, "ppid"),
        "exe": _field(chosen, "exe"),
        "comm": _field(chosen, "comm"),
        "syscall": _field(chosen, "syscall"),
        "success": _field(chosen, "success"),
        "key": AUDIT_KEY,
        "raw": chosen,
    }


def evidence_file_info():
    if not EVIDENCE_FILE.is_file():
        return {"present": False, "path": str(EVIDENCE_FILE), "content": None, "mtime": None}
    try:
        return {
            "present": True,
            "path": str(EVIDENCE_FILE),
            "content": EVIDENCE_FILE.read_text(encoding="utf-8", errors="replace"),
            "mtime": EVIDENCE_FILE.stat().st_mtime,
        }
    except OSError:
        return {"present": True, "path": str(EVIDENCE_FILE), "content": None, "mtime": None}


class TargetHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == TRIGGER_PATH:
            EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).isoformat()
            EVIDENCE_FILE.write_text(f"LAB2-HOST\ntimestamp={stamp}\n", encoding="utf-8")
            body = f"LAB2 event created\nfile={EVIDENCE_FILE}\ntimestamp={stamp}\n".encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if parsed.path == "/":
            body = b"IDPS Lab 2 target ready\n"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_error(404)

    def log_message(self, fmt, *args):
        return


class DashboardHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/status":
            network = read_network_events(limit=12)
            audit = read_audit_latest()
            json_response(self, {
                "server_time": datetime.now(timezone.utc).isoformat(),
                "sensor": sensor_process(),
                "audit_state": audit_state(),
                "network": {"path": network["path"], "count": network["count"]},
                "audit": audit,
                "file": evidence_file_info(),
                "lab": {"client_ip": CLIENT_IP, "server_ip": LAB_IP, "trigger": TRIGGER_PATH, "sid": SID, "audit_key": AUDIT_KEY},
            })
            return
        if path == "/api/evidence":
            json_response(self, {
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "sensor": sensor_process(),
                "audit_state": audit_state(),
                "network": read_network_events(limit=40),
                "audit": read_audit_latest(),
                "file": evidence_file_info(),
                "boundaries": [
                    "Suricata подтверждает наблюдаемые сетевые факты, присутствующие в её EVE-событиях.",
                    "Linux Audit подтверждает локальную хостовую операцию, попавшую под установленное правило аудита.",
                    "Ни один из этих источников сам по себе не обязан содержать все факты эпизода.",
                    "В этой лаборатории причинная связь известна потому, что эпизод создаётся нами контролируемо; в реальной среде одной временной близости записей недостаточно.",
                ],
            })
            return
        self.serve_static(path)

    def serve_static(self, path):
        rel = "index.html" if path == "/" else path.lstrip("/")
        candidate = (WEBROOT / rel).resolve()
        root = WEBROOT.resolve()
        if root not in candidate.parents and candidate != root:
            self.send_error(403)
            return
        if not candidate.is_file():
            self.send_error(404)
            return
        ctype = "text/plain; charset=utf-8"
        if candidate.suffix == ".html":
            ctype = "text/html; charset=utf-8"
        elif candidate.suffix == ".css":
            ctype = "text/css; charset=utf-8"
        elif candidate.suffix == ".js":
            ctype = "application/javascript; charset=utf-8"
        body = candidate.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        return


def serve_dashboard():
    ThreadingHTTPServer((LAB_IP, DASHBOARD_PORT), DashboardHandler).serve_forever()


def main():
    threading.Thread(target=serve_dashboard, daemon=True).start()
    ThreadingHTTPServer((LAB_IP, TARGET_PORT), TargetHandler).serve_forever()


if __name__ == "__main__":
    main()
