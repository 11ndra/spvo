#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "[FAIL] $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || fail 'Run with sudo bash server/replay.sh baseline|candidate|rollback'
[[ $# -eq 1 ]] || fail 'Specify baseline, candidate or rollback'
case "$1" in
 baseline|rollback) rule=server/baseline.rules ;;
 candidate) rule=server/candidate.rules ;;
 *) fail 'Unknown stage' ;;
esac
for tool in suricata sha256sum tee cp date; do command -v "$tool" >/dev/null || fail "missing: $tool"; done
[[ -s evidence/inputs/requests.pcap ]] || fail 'Prepare authentic lab13 inputs first'
sha256sum -c evidence/inputs.sha256 || fail 'copied input changed'
[[ ! -e "evidence/$1" ]] || fail 'stage exists; preserve results and use new extraction'
mkdir "evidence/$1"
out="$PWD/evidence/$1"
cp "$rule" "$out/active.rules"
sha256sum evidence/inputs/requests.pcap "$out/active.rules" /etc/suricata/suricata.yaml > "$out/inputs.sha256"
suricata -V > "$out/version.txt"
cp /etc/suricata/suricata.yaml "$out/config.yaml"
date -u +%FT%TZ > "$out/started.txt"
mkdir "$out/validation"
suricata -T -c /etc/suricata/suricata.yaml -S "$out/active.rules" -l "$out/validation" > "$out/validation.log" 2>&1 || { cat "$out/validation.log"; fail 'validation failed; no replay'; }
printf 'suricata -k none -c /etc/suricata/suricata.yaml -S %q -r %q -l %q\n' "$out/active.rules" "$PWD/evidence/inputs/requests.pcap" "$out" > "$out/command.txt"
suricata -k none -c /etc/suricata/suricata.yaml -S "$out/active.rules" -r "$PWD/evidence/inputs/requests.pcap" -l "$out" 2>&1 | tee "$out/replay.log"
sha256sum -c "$out/inputs.sha256" > "$out/inputs-check.txt" || fail 'input changed during replay'
sha256sum -c evidence/inputs.sha256 >> "$out/inputs-check.txt" || fail 'copied inputs changed'
cmp /etc/suricata/suricata.yaml "$out/config.yaml" || fail 'configuration copy differs'
date -u +%FT%TZ > "$out/completed.txt"
echo "REPLAY_COMPLETED: $1; compare evidence before making a decision"
