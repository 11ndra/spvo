# ЛР №15 — Изменение правила: доказательство и откат

Полная инструкция: https://11ndra.github.io/spvo/labs/lab15/

Прежний idps-server, Suricata 8, Python 3. Новых VM, сервисов и трафика нет. Используются реальные оригинальные артефакты №13, а не изменённые варианты №14.

Проверьте прежние манифесты №13. Из каталога этого пакета, последовательно с проверкой результата:

```bash
sudo python3 tools/prepare.py ~/idps-lab13-bundle-v0.1
sudo bash server/replay.sh baseline
sudo bash server/replay.sh candidate
sudo bash server/replay.sh rollback
sudo python3 tools/compare.py
sudo sha256sum -c evidence/inputs.sha256
sudo find evidence -type f -print0 | sort -z | sudo xargs -0 sha256sum > lab15-evidence.sha256
```

При другом расположении №13 передайте фактический путь. Требуются evidence/client-copy (девять A/B/C файлов), capture/requests.pcap, analysis/eve.json, active.rules, completed.txt. Каталог evidence создаётся один раз. Повторяйте в новой распаковке; не перезаписывайте артефакты.

Новая цель: путь /lab13/export с необязательной query string. Baseline SID 10000130 rev 1 выделяет B и C. Candidate rev 2 должен выделить только B. Rollback повторно запускает baseline на том же PCAP. Это offline-проверка возврата поведения, не развёртывание или откат live-сервиса.

Заполните report/lab15-report.md: прогноз до запуска, факты, решение, ограничения и план дополнительных проверок. Текущие примеры известны при выборе правила, поэтому не являются holdout. Успешный тест не доказывает отсутствие инцидента или готовность к промышленному внедрению.

Сравнение использует проверку связей №13 с параметром ожидаемой rev. Код 0 — ожидаемая картина; 2 — наблюдаемое отличие; 1 — непригодность данных/условий. Подробности: evidence/comparison. Исходные файлы не меняются, их хеши проверяются; полный образ окружения не снимается. Внешние зависимости YAML фиксируйте отдельно.

Сдайте отчёт, evidence, итоговый манифест и оба правила. Сохраните оригиналы №13. Системные службы и firewall не изменяются.
