"""Lab13 byte contract; no network operations."""
CASES={'A':'/lab13/health','B':'/lab13/export','C':'/lab13/export-status'}
def request_bytes(uri):
 return (f'GET {uri} HTTP/1.1\r\nHost: 10.13.37.20:8080\r\nUser-Agent: SPVO-LAB13\r\nConnection: close\r\n\r\n').encode('ascii')
def check_response(data,uri):
 head,sep,body=data.partition(b'\r\n\r\n')
 if not sep:raise ValueError('incomplete HTTP response headers')
 status=head.split(b'\r\n')[0].split()
 if len(status)<2 or status[1]!=b'200':raise ValueError('HTTP response is not 200')
 lengths=[line.split(b':',1)[1].strip() for line in head.split(b'\r\n')[1:] if line.lower().startswith(b'content-length:')]
 if len(lengths)!=1 or len(body)!=int(lengths[0]):raise ValueError('missing/ambiguous Content-Length or incomplete body')
 if f'path={uri}'.encode() not in body.splitlines():raise ValueError('unexpected service response; expected LAB05 path echo')
