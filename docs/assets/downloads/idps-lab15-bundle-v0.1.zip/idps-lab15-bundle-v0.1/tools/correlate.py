#!/usr/bin/env python3
"""Link client artifacts and supplied EVE. Does not parse PCAP or declare incidents."""
import json,re,runpy,sys
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CLIENT=runpy.run_path(str(ROOT/'tools/http_contract.py'))
SID=10000130

def stamp(s):
 if not isinstance(s,str):raise ValueError('timestamp must be string')
 t=datetime.fromisoformat(s.replace('Z','+00:00'))
 if t.tzinfo is None:raise ValueError('timestamp timezone required')
 return t

def correlate(directory,records,expected_rev=1):
 metas={};run_ids=set()
 for case,path in CLIENT['CASES'].items():
  meta=json.loads((directory/f'{case}-meta.json').read_text())
  run=meta.get('run','')
  if not isinstance(run,str) or not re.fullmatch('[0-9a-f]{32}',run):raise ValueError('invalid run ID')
  rid=f'{run}-{case}';uri=f'{path}?lab13_request={rid}'
  if meta.get('case')!=case or meta.get('request_id')!=rid or meta.get('uri')!=uri:raise ValueError('client metadata mismatch')
  if meta.get('status')!='HTTP_200_PATH_VERIFIED':raise ValueError('client exchange incomplete')
  times=[stamp(meta.get(k)) for k in ('started_at','sent_at','ended_at')]
  if times!=sorted(times):raise ValueError('client timestamps reversed')
  local=meta.get('local');peer=meta.get('peer')
  if not isinstance(local,list) or len(local)!=2 or local[0]!='10.13.37.10' or type(local[1]) is not int or not 0<local[1]<65536 or peer!=['10.13.37.20',8080]:raise ValueError('invalid client connection endpoints')
  if (directory/f'{case}-request.bin').read_bytes()!=CLIENT['request_bytes'](uri):raise ValueError('client request bytes differ from recorded URI')
  CLIENT['check_response']((directory/f'{case}-response.bin').read_bytes(),uri)
  metas[uri]=meta;run_ids.add(run)
 if len(run_ids)!=1:raise ValueError('client artifacts from different runs')
 http={};alerts=[];flows=set()
 for number,e in enumerate(records,1):
  if not isinstance(e,dict):raise ValueError('EVE record must be object')
  h=e.get('http',{});a=e.get('alert',{})
  if not isinstance(h,dict) or not isinstance(a,dict):raise ValueError('invalid HTTP/alert structure')
  uri=h.get('url','')
  if not isinstance(uri,str):raise ValueError('URL must be string')
  if 'lab13_request=' not in uri and a.get('signature_id')!=SID:continue
  stamp(e.get('timestamp'))
  if (e.get('src_ip'),e.get('dest_ip'),e.get('dest_port'),e.get('proto'))!=('10.13.37.10','10.13.37.20',8080,'TCP'):raise ValueError('wrong EVE tuple')
  for name in ('flow_id','tx_id'):
   if type(e.get(name)) is not int or e[name]<0:raise ValueError('invalid flow_id/tx_id')
  if type(e.get('src_port')) is not int or not 0<e['src_port']<65536:raise ValueError('invalid source port')
  key=(e['flow_id'],e['tx_id'],e['src_port'])
  if e.get('event_type')=='http':
   if uri not in metas:raise ValueError('foreign request ID/URI or mixed runs')
   if e['src_port']!=metas[uri]['local'][1]:raise ValueError('client/EVE source-port mismatch')
   if uri in http or e['flow_id'] in flows:raise ValueError('duplicate HTTP or reused flow')
   if h.get('http_method')!='GET' or h.get('status')!=200:raise ValueError('expected complete HTTP GET/200')
   http[uri]=(key,number,e['timestamp']);flows.add(e['flow_id'])
  elif e.get('event_type')=='alert' and a.get('signature_id')==SID:
   if a.get('rev')!=expected_rev or a.get('action')!='allowed':raise ValueError('unexpected rule revision/action')
   if uri and uri not in metas:raise ValueError('alert URI contradicts client artifacts')
   alerts.append((key,number,e['timestamp'],uri))
 if set(http)!=set(metas):raise ValueError('missing HTTP evidence for one or more client exchanges')
 keys={v[0] for v in http.values()}
 if any(a[0] not in keys for a in alerts):raise ValueError('unmatched alert transaction')
 rows=[]
 for uri,meta in metas.items():
  key,line,time=http[uri];matches=[a for a in alerts if a[0]==key]
  if len(matches)>1:raise ValueError('duplicate alert for one transaction')
  if any(a[3] and a[3]!=uri for a in matches):raise ValueError('alert URI/transaction contradiction')
  rows.append({'case':meta['case'],'request_id':meta['request_id'],'uri':uri,'src_port':key[2],'flow_id':key[0],'tx_id':key[1],'client_started':meta['started_at'],'client_sent':meta['sent_at'],'client_ended':meta['ended_at'],'eve_http_line':line,'eve_http_time':time,'alert_lines':[a[1] for a in matches],'alert_times':[a[2] for a in matches]})
 return rows

def main():
 if len(sys.argv)!=3:raise ValueError('Usage: python3 tools/correlate.py CLIENT_DIRECTORY EVE_FILE')
 p=Path(sys.argv[2]);records=[]
 # Keep blank lines as harmless objects so enumerated references retain actual file line numbers.
 for n,line in enumerate(p.read_text().splitlines(),1):
  if not line.strip():records.append({});continue
  try:records.append(json.loads(line))
  except ValueError as exc:raise ValueError(f'invalid JSON at line {n}') from exc
 rows=correlate(Path(sys.argv[1]),records)
 for r in rows:print(json.dumps(r,ensure_ascii=False))
 print('LINKED_RECORDS: three client exchanges linked to supplied EVE; PCAP verification and incident assessment remain manual')
 if {r['case']:len(r['alert_lines']) for r in rows}!={'A':0,'B':1,'C':1}:
  print('OBSERVED_DIFFERENCE: alert pattern differs from the teaching forecast; preserve evidence and investigate')
  return 2
 return 0
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,TypeError,KeyError,AttributeError) as exc:sys.exit('[INCOMPLETE_OR_INVALID] '+str(exc))
