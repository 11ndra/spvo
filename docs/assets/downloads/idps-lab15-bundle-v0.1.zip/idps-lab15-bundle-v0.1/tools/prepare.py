#!/usr/bin/env python3
"""Copy authentic lab13 inputs; record source and copy hashes. No source writes."""
import hashlib,json,runpy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
C=runpy.run_path(str(ROOT/'tools/correlate.py'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def regular(p):
 if any(x.is_symlink() for x in [p,*p.parents]) or not p.is_file():raise ValueError('regular non-symlink file required: '+str(p))
 return p

def main():
 if len(sys.argv)!=2:raise ValueError('Usage: python3 tools/prepare.py LAB13_DIRECTORY')
 source=Path(sys.argv[1]).expanduser().absolute();out=ROOT/'evidence'
 if any(x.is_symlink() for x in [source,*source.parents]):raise ValueError('source path contains symlink')
 source=source.resolve()
 if source==ROOT or source in ROOT.parents:raise ValueError('new bundle must be outside source directory')
 if out.exists():raise ValueError('evidence exists; use a new extraction directory')
 names={f'evidence/client-copy/{c}-{s}':f'client/{c}-{s}' for c in 'ABC' for s in ('request.bin','response.bin','meta.json')}
 names.update({'evidence/capture/requests.pcap':'requests.pcap','evidence/analysis/eve.json':'lab13-eve.json','evidence/analysis/active.rules':'lab13-active.rules','evidence/analysis/completed.txt':'lab13-completed.txt'})
 hashes={n:sha(regular(source/n)) for n in names}
 rows=C['correlate'](source/'evidence/client-copy',[json.loads(l) if l.strip() else {} for l in (source/'evidence/analysis/eve.json').read_text().splitlines()])
 if {r['case']:len(r['alert_lines']) for r in rows}!={'A':0,'B':1,'C':1}:raise ValueError('lab13 differs from baseline; investigate before proceeding')
 if (source/'evidence/analysis/active.rules').read_bytes()!=(ROOT/'server/baseline.rules').read_bytes():raise ValueError('lab13 active rule differs from published baseline; investigate')
 out.mkdir();inputs=out/'inputs';inputs.mkdir()
 for n,d in names.items():
  p=inputs/d;p.parent.mkdir(parents=True,exist_ok=True)
  # Stream PCAP, avoid holding large captures in memory.
  import shutil
  shutil.copyfile(source/n,p)
  if sha(p)!=hashes[n]:raise ValueError('source changed while copying: '+n)
 if any(sha(regular(source/n))!=h for n,h in hashes.items()):raise ValueError('source changed during preparation')
 (out/'sources.json').write_text(json.dumps({'source_root':str(source),'sha256':hashes},indent=2)+'\n')
 (out/'inputs.sha256').write_text(''.join(f'{hashes[n]}  evidence/inputs/{d}\n' for n,d in names.items()))
 print('PREPARED: authentic inputs copied; source files unchanged')
if __name__=='__main__':
 try:main()
 except (OSError,ValueError,TypeError,KeyError,AttributeError) as exc:sys.exit('[PREPARATION_FAILED] '+str(exc)+'; preserve partial output; retry in a new extraction')
