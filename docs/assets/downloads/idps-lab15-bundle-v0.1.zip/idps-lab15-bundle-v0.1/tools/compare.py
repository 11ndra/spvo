#!/usr/bin/env python3
"""Check three offline runs. A pass is limited to this acceptance dataset."""
import json,runpy,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
C=runpy.run_path(str(ROOT/'tools/correlate.py'))
P=runpy.run_path(str(ROOT/'tools/prepare.py'))
def main():
 out=ROOT/'evidence/comparison'
 if out.exists():raise ValueError('comparison exists; preserve previous output')
 subprocess.run(['sha256sum','-c','evidence/inputs.sha256'],cwd=ROOT,check=True,capture_output=True,text=True)
 sources=json.loads((ROOT/'evidence/sources.json').read_text())
 for n,h in sources['sha256'].items():
  if P['sha'](P['regular'](Path(sources['source_root'])/n))!=h:raise ValueError('original source changed: '+n)
 allrows={};versions=set();configs=set();summary=[]
 for stage,rev,want in [('baseline',1,{'A':0,'B':1,'C':1}),('candidate',2,{'A':0,'B':1,'C':0}),('rollback',1,{'A':0,'B':1,'C':1})]:
  d=ROOT/'evidence'/stage
  if not (d/'completed.txt').is_file():raise ValueError('incomplete replay: '+stage)
  subprocess.run(['sha256sum','-c',str(d/'inputs.sha256')],cwd=ROOT,check=True,capture_output=True,text=True)
  rule=ROOT/'server'/('candidate.rules' if stage=='candidate' else 'baseline.rules')
  if (d/'active.rules').read_bytes()!=rule.read_bytes():raise ValueError('active rule differs: '+stage)
  versions.add((d/'version.txt').read_text());configs.add(P['sha'](d/'config.yaml'))
  records=[json.loads(l) if l.strip() else {} for l in (d/'eve.json').read_text().splitlines()]
  rows=C['correlate'](ROOT/'evidence/inputs/client',records,expected_rev=rev);allrows[stage]=rows
  counts={r['case']:len(r['alert_lines']) for r in rows}
  summary.append({'stage':stage,'revision':rev,'expected':want,'observed':counts,'status':'PASS' if counts==want else 'DIFFERENCE'})
 if len(versions)!=1 or len(configs)!=1:raise ValueError('version/config differs between stages; controlled comparison invalid')
 out.mkdir()
 (out/'linked-records.json').write_text(json.dumps(allrows,indent=2)+'\n')
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 for row in summary:print(json.dumps(row))
 print('Scope: three known requests in one PCAP; not a holdout test, incident verdict, or live deployment')
 return 0 if all(r['status']=='PASS' for r in summary) else 2
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,TypeError,KeyError,AttributeError,subprocess.CalledProcessError) as exc:sys.exit('[INCOMPLETE_OR_INVALID] '+str(exc))
