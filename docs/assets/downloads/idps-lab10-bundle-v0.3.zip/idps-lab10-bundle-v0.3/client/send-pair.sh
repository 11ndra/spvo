#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
stage=${1:-}
case "$stage" in baseline|blind|mismatch|restore) ;; *) echo 'Usage: bash client/send-pair.sh {baseline|blind|mismatch|restore}' >&2; exit 2 ;; esac
command -v curl >/dev/null || { echo '[FAIL] curl missing' >&2; exit 1; }
command -v ip >/dev/null || { echo '[FAIL] ip missing' >&2; exit 1; }
ip -o -4 addr show | grep -Eq 'inet 10[.]13[.]37[.]10/' || { echo '[FAIL] run on idps-client' >&2; exit 1; }
mkdir -p evidence/client
# Check the entire pair before sending anything.
for label in positive negative; do
  for ext in txt headers meta; do
    [[ ! -e "evidence/client/${stage}-${label}.${ext}" ]] || { echo '[FAIL] existing stage evidence; use NEW extraction directory' >&2; exit 1; }
  done
done
for label in positive negative; do
  case "$label" in positive) marker=LAB10-OBSERVE;; negative) marker=LAB10-NORMAL;; esac
  uri="/${marker}?lab10_phase=${stage}&lab10_case=${label}"
  target="evidence/client/${stage}-${label}.txt"
  [[ ! -e "$target" ]] || { echo "[FAIL] existing evidence: $target; use clean extraction" >&2; exit 1; }
  meta="evidence/client/${stage}-${label}.meta"
  printf 'STAGE=%s CASE=%s URI=%s START=%s\n' "$stage" "$label" "$uri" "$(date -u +%FT%TZ)" > "$meta"
  code=$(curl --noproxy '*' --silent --show-error --max-time 8 --dump-header "evidence/client/${stage}-${label}.headers" --output "$target" --write-out '%{http_code}' "http://10.13.37.20:8080${uri}") || { echo "[FAIL] HTTP transport: $stage/$label" >&2; exit 1; }
  printf 'HTTP=%s END=%s\n' "$code" "$(date -u +%FT%TZ)" >> "$meta"
  [[ "$code" == 200 ]] || { echo "[FAIL] unexpected HTTP=$code for $stage/$label" >&2; exit 1; }
  grep -Fq "path=$uri" "$target" || { echo "[FAIL] HTTP body unexpected for $stage/$label" >&2; exit 1; }
  printf 'STAGE=%s CASE=%s HTTP=200 VERIFIED_URI=%s\n' "$stage" "$label" "$uri"
done
