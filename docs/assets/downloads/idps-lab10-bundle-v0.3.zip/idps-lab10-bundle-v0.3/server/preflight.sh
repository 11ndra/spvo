#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail() { printf '[FAIL] %s\n' "$*" >&2; exit 1; }
for tool in ip awk grep pgrep suricata curl sudo find python3; do
  command -v "$tool" >/dev/null 2>&1 || fail "missing command: $tool"
done
[[ -f /etc/suricata/suricata.yaml ]] || fail 'existing Suricata configuration not found'
if pgrep -x suricata >/dev/null 2>&1; then fail 'Suricata from a previous run is still running'; fi
sudo -v || fail 'sudo access unavailable'
if command -v nft >/dev/null 2>&1; then
  tables=$(sudo nft list tables) || fail 'cannot read nft state'
  if grep -Fxq 'table inet spvo_lab08_ips' <<< "$tables"; then fail 'complete LAB08 cleanup first'; fi
fi
lab_iface=$(ip -o -4 addr show | awk '$4 ~ /^10[.]13[.]37[.]20\// {print $2; exit}')
nat_iface=$(ip -4 route show default | awk '$1=="default" {for(i=1;i<NF;i++){if($i=="dev") {print $(i+1); exit}}}')
[[ -n "$lab_iface" ]] || fail 'no interface with 10.13.37.20 address'
[[ -n "$nat_iface" ]] || fail 'no separate default-route interface (NAT)'
[[ "$lab_iface" != "$nat_iface" ]] || fail 'default-route interface equals LAB interface; cannot demonstrate blind capture'
ip link show dev "$lab_iface" >/dev/null || fail 'LAB interface not available'
ip link show dev "$nat_iface" >/dev/null || fail 'NAT interface not available'
route=$(ip -4 route get 10.13.37.10) || fail 'no route to client'
[[ "$(awk '{for(i=1;i<NF;i++) if($i=="dev") {print $(i+1); exit}}' <<< "$route")" == "$lab_iface" ]] || fail "route to client not via LAB interface: $route"
[[ ! -d evidence/server ]] || fail 'existing server evidence detected; use a freshly extracted package for a new run'
for rule in server/rules/observe.rules server/rules/mismatch.rules; do
  sudo suricata -T -c /etc/suricata/suricata.yaml -S "$PWD/$rule" >/dev/null || fail "suricata -T failed for $rule"
done
uri='/LAB10-OBSERVE?lab10_phase=preflight&lab10_case=positive'
body=$(curl --noproxy '*' --silent --show-error --fail --max-time 6 "http://10.13.37.20:8080${uri}") || fail 'existing service :8080 unavailable'
grep -Fq "path=${uri}" <<< "$body" || fail 'unexpected HTTP response'
printf 'PREFLIGHT_OK LAB_IFACE=%s NAT_IFACE=%s http=:8080 rules=2\n' "$lab_iface" "$nat_iface"
printf 'ROUTE_TO_CLIENT=%s\n' "$route"
