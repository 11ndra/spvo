#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
stage=${1:-}
case "$stage" in
  baseline|blind|mismatch|restore) ;;
  *) echo 'Usage: bash server/run-stage.sh {baseline|blind|mismatch|restore}' >&2; exit 2 ;;
esac
fail() { echo "[FAIL] $*" >&2; exit 1; }
for tool in ip awk pgrep sudo suricata; do command -v "$tool" >/dev/null || fail "missing: $tool"; done
if pgrep -x suricata >/dev/null 2>&1; then fail 'another Suricata process is already running'; fi
lab_iface=$(ip -o -4 addr show | awk '$4 ~ /^10[.]13[.]37[.]20\// {print $2; exit}')
nat_iface=$(ip -4 route show default | awk '$1=="default" {for(i=1;i<NF;i++){if($i=="dev"){print $(i+1); exit}}}')
[[ -n "$lab_iface" && -n "$nat_iface" && "$lab_iface" != "$nat_iface" ]] || fail 'expected LAB and distinct NAT interfaces not found'
case "$stage" in
  blind) iface=$nat_iface; rule=server/rules/observe.rules ;;
  mismatch) iface=$lab_iface; rule=server/rules/mismatch.rules ;;
  *) iface=$lab_iface; rule=server/rules/observe.rules ;;
esac
# Privilege validation must not be confused with an absent nft table.
sudo -v || fail 'sudo access unavailable'
if command -v nft >/dev/null 2>&1; then
  tables=$(sudo nft list tables) || fail 'cannot read nft state'
  if grep -Fxq 'table inet spvo_lab08_ips' <<< "$tables"; then fail 'complete LAB08 cleanup'; fi
fi
printf 'Send the client pair after Engine started; finish this stage with Ctrl+C.\n'
sudo python3 tools/record-stage.py "$stage" "$iface" "$rule"
