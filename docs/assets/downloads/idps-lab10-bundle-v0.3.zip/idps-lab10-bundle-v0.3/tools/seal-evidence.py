#!/usr/bin/env python3
"""Hash collected bytes after collection stops; does not certify provenance."""
import hashlib,json,socket
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parents[1]
rows=[]
for name in ('evidence','server'):
 for p in sorted((root/name).rglob('*')):
  if p.is_symlink(): raise SystemExit('Symlink not accepted: '+str(p))
  if p.is_file():
   digest=hashlib.sha256()
   with p.open('rb') as f:
    for chunk in iter(lambda:f.read(1024*1024),b''): digest.update(chunk)
   rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest.hexdigest()})
if not any(r['path'].startswith('evidence/') for r in rows): raise SystemExit('No evidence to seal')
with (root/'evidence-manifest.json').open('x') as f:
 json.dump({'host':socket.gethostname(),'sealed_at':datetime.now(timezone.utc).isoformat(),'files':rows},f,indent=2)
print('evidence-manifest.json created; retain originals and record collection times separately')
