#!/usr/bin/env python3
"""Run one foreground sensor and record its local time window; no service changes."""
import hashlib,json,os,signal,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path

def now(): return datetime.now(timezone.utc).isoformat()
def main():
 if len(sys.argv)!=4: raise ValueError('Usage: record-stage.py STAGE INTERFACE RULE')
 stage,iface,rule=sys.argv[1:]
 if stage not in ('baseline','blind','mismatch','restore'): raise ValueError('Invalid stage')
 root=Path(__file__).resolve().parents[1]; os.chdir(root)
 rule=Path(rule).resolve(); config=Path('/etc/suricata/suricata.yaml')
 out=root/'evidence/server'/stage
 if out.exists(): raise ValueError('Stage already exists; keep evidence and use a NEW extraction directory')
 # Validate before allocating evidence. Never remove previous evidence.
 subprocess.run(['suricata','-T','-c',str(config),'-S',str(rule)],check=True)
 out.mkdir(parents=True,exist_ok=False)
 snapshot=out/'active.rules'; snapshot.write_bytes(rule.read_bytes())
 cmd=['suricata','-k','none','-c',str(config),'-S',str(snapshot),'-i',iface,'-l',str(out)]
 meta={'stage':stage,'interface':iface,'started_at':now(),'rule_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),
       'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'command':cmd,
       'suricata_version':subprocess.check_output(['suricata','-V'],text=True).strip()}
 path=out/'stage.json'
 def save(): path.write_text(json.dumps(meta,indent=2)+'\n')
 save()
 (out/'stage.txt').write_text(f'STAGE={stage} INTERFACE={iface} RULE={snapshot} MODE=passive\n')
 # Terminal Ctrl+C reaches the child as well. Keep the parent alive to record completion.
 previous=signal.signal(signal.SIGINT,lambda *_:None)
 try:
  with (out/'console.log').open('w') as log:
   with subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1) as child:
    meta['pid']=child.pid;save()
    for line in child.stdout:
     log.write(line);log.flush();print(line,end='',flush=True)
    rc=child.wait()
  meta['exit_code']=rc
 finally:
  meta['ended_at']=now();save();signal.signal(signal.SIGINT,previous)
 return 0 if rc==0 else 1
if __name__=='__main__':
 try: sys.exit(main())
 except (ValueError,OSError,subprocess.SubprocessError) as exc: sys.exit('[FAIL] '+str(exc))
