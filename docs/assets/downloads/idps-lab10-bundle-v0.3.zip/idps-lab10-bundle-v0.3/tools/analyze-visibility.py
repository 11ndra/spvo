#!/usr/bin/env python3
"""Read actual Suricata EVE outputs; never fabricate HTTP events or alerts."""
from __future__ import annotations
import json
from datetime import datetime
import hashlib
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
STAGES = ("baseline", "blind", "mismatch", "restore")
SID = 1000010
SRC, DST = "10.13.37.10", "10.13.37.20"
EXPECT = {
    "baseline": (True, True),
    "blind": (False, False),
    "mismatch": (True, False),
    "restore": (True, True),
}

def fail(message: str) -> None:
    raise ValueError(message)

def events(path: Path) -> list[dict]:
    if not path.exists():
        fail(f"missing EVE: {path}")
    output = []
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            fail(f"{path.name} line {n}: invalid JSON: {exc}")
        if not isinstance(record, dict):
            fail(f"{path.name} line {n}: record must be object")
        output.append(record)
    return output

def timestamp(value):
    if not isinstance(value, str): fail("timestamp must be a string")
    try: result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError: fail("invalid timestamp")
    if result.tzinfo is None: fail("timestamp timezone missing")
    return result

def stage_records(stage, directory):
    meta = json.loads((directory/"stage.json").read_text())
    if meta.get("stage") != stage or not meta.get("interface"):
        fail("stage metadata mismatch")
    start, end = timestamp(meta.get("started_at")), timestamp(meta.get("ended_at"))
    if end <= start or meta.get("exit_code") != 0:
        fail("capture did not complete cleanly; inspect console.log and preserve evidence")
    rule = directory/"active.rules"
    if hashlib.sha256(rule.read_bytes()).hexdigest() != meta.get("rule_sha256"):
        fail("captured rule checksum mismatch")
    rows = events(directory/"eve.json")
    for row in rows:
        if not start <= timestamp(row.get("timestamp")) <= end:
            fail("EVE timestamp outside recorded local stage window")
    return rows

def analyze(stage: str, records: list[dict]) -> tuple[list[str], list[str]]:
    if stage not in EXPECT:
        fail(f"unknown stage: {stage}")
    lines, failures = [], []
    if not records:
        return [], [f"{stage}: empty EVE; sensor/logging health unproven"]
    expect_http, expect_positive_alert = EXPECT[stage]
    urls = {
        "positive": f"/LAB10-OBSERVE?lab10_phase={stage}&lab10_case=positive",
        "negative": f"/LAB10-NORMAL?lab10_phase={stage}&lab10_case=negative",
    }
    # A lab marker with contradictory fields is a failed experiment, not background.
    for e in records:
        if not isinstance(e, dict): fail("record must be an object")
        for name in ("http", "alert", "stats"):
            if name in e and not isinstance(e[name], dict): fail(f"{name} must be an object")
        uri = e.get("http", {}).get("url", "")
        if not isinstance(uri, str): fail("HTTP URL must be a string")
        relevant = "lab10_phase=" in uri or e.get("alert", {}).get("signature_id") == SID
        if relevant:
            timestamp(e.get("timestamp"))
            if (e.get("src_ip"),e.get("dest_ip"),e.get("dest_port"),e.get("proto")) != (SRC,DST,8080,"TCP"):
                failures.append(f"{stage}: lab event with wrong network tuple")
            if type(e.get("flow_id")) is not int or type(e.get("tx_id")) is not int or e["flow_id"] < 0 or e["tx_id"] < 0:
                failures.append(f"{stage}: nonnegative integer flow_id/tx_id required")
        if e.get("event_type") == "http" and "lab10_phase=" in uri:
            if uri not in urls.values(): failures.append(f"{stage}: foreign/ambiguous lab URI")
            if e["http"].get("http_method") != "GET" or e["http"].get("status") != 200:
                failures.append(f"{stage}: expected HTTP GET with status 200")
    flows = {}
    for case, url in urls.items():
        matches = [e for e in records if e.get("event_type") == "http" and (e.get("http") or {}).get("url") == url and e.get("src_ip") == SRC and e.get("dest_ip") == DST]
        if expect_http:
            if len(matches) != 1:
                failures.append(f"{stage}/{case}: expected exactly one HTTP EVE event, got {len(matches)}")
            if len(matches) == 1:
                if matches[0].get("flow_id") is None:
                    failures.append(f"{stage}/{case}: HTTP event without flow_id")
                else:
                    if type(matches[0].get("tx_id")) is not int:
                        failures.append(f"{stage}/{case}: HTTP tx_id required")
                    if matches[0].get("dest_port") != 8080 or matches[0].get("proto") != "TCP":
                        failures.append(f"{stage}/{case}: invalid port/protocol")
                    flows[case] = (matches[0]["flow_id"], matches[0].get("tx_id"))
        elif matches:
            failures.append(f"{stage}/{case}: HTTP on deliberately wrong interface; experimental assumption failed")
        lines.append(f"{stage:9} {case:8} HTTP_EVE={len(matches)}")

    alerts = [e for e in records if e.get("event_type") == "alert" and (e.get("alert") or {}).get("signature_id") == SID and e.get("src_ip") == SRC and e.get("dest_ip") == DST]
    for e in alerts:
        expected_rev = 2 if stage == 'mismatch' else 1
        if e.get('dest_port') != 8080 or e.get('proto') != 'TCP' or e['alert'].get('action') != 'allowed' or e['alert'].get('rev') != expected_rev:
            failures.append(f"{stage}: unexpected alert tuple/action/revision")
    if not expect_http:
        if alerts:
            failures.append(f"{stage}: unexpected SID {SID} alert on wrong interface")
        lines.append(f"{stage:9} LAB10_ALERTS={len(alerts)}")
    elif len(flows) == 2:
        if flows['positive'][0] == flows['negative'][0]:
            failures.append(f"{stage}: expected separate curl flows")
        for case in ("positive", "negative"):
            matched = [e for e in alerts if (e.get("flow_id"), e.get("tx_id")) == flows[case]]
            expected = expect_positive_alert if case == "positive" else False
            if len(matched) != int(expected):
                failures.append(f"{stage}/{case}: expected alert={expected}, observed {len(matched)}")
            lines.append(f"{stage:9} {case:8} SID_ALERT={len(matched)}")
        unrelated = [e for e in alerts if (e.get("flow_id"), e.get("tx_id")) not in set(flows.values())]
        if unrelated:
            failures.append(f"{stage}: {len(unrelated)} unmatched LAB10 SID alerts; another experiment may be mixed in")
    stats = [e.get("stats", {}) for e in records if e.get("event_type") == "stats"]
    if stage == "blind":
        from datetime import datetime
        healthy = False
        for e in records:
            if e.get("event_type") != "stats": continue
            try:
                t = datetime.fromisoformat(e.get("timestamp", "").replace("Z", "+00:00"))
                uptime = (e.get("stats") or {}).get("uptime")
                healthy = healthy or (t.tzinfo is not None and type(uptime) in (int, float) and uptime > 0)
            except (ValueError, TypeError): pass
        if not healthy:
            failures.append("blind: timestamped stats with positive uptime required; absence alone cannot establish sensor health")
    if stats:
        cap = stats[-1].get("capture", {})
        lines.append(f"{stage:9} STATS kernel_packets={cap.get('kernel_packets','n/a')} kernel_drops={cap.get('kernel_drops','n/a')} (not a complete loss assessment)")
    else:
        lines.append(f"{stage:9} STATS not present in EVE; inspect stats.log separately")
    return lines, failures

def main() -> int:
    problems=[]
    for stage in STAGES:
        path = ROOT/"evidence"/"server"/stage/"eve.json"
        try:
            lines,errors = analyze(stage,stage_records(stage,path.parent))
        except (ValueError, OSError, TypeError, KeyError) as exc:
            print(f"[FAIL] {stage}: {exc}",file=sys.stderr)
            problems.append(str(exc))
            continue
        print("\n".join(lines))
        problems.extend(errors)
    if problems:
        for item in problems:
            print(f"[FAIL] {item}",file=sys.stderr)
        print(f"CHECK_FAILED issues={len(problems)}",file=sys.stderr)
        return 1
    print("EVE_MATRIX_OK: supplied records match expected matrix; verify stage interface, run times and independent client responses before attributing the cause")
    return 0
if __name__ == "__main__":
    sys.exit(main())
