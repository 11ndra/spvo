#!/usr/bin/env bash
set -u
[[ $EUID -eq 0 ]] || { echo 'Run with sudo.'; exit 1; }
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fail=0; ok(){ echo "[ OK ] $*"; }; bad(){ echo "[FAIL] $*"; fail=1; }
for c in ip curl jq tcpdump suricata; do command -v "$c" >/dev/null 2>&1 && ok "command: $c" || bad "missing command: $c"; done
ip -o -4 addr show | grep -q '10\.13\.37\.20/' && ok 'lab address 10.13.37.20 is present' || bad 'expected address 10.13.37.20/24 is missing'
IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
[[ -n "$IFACE" ]] && ok "lab interface: $IFACE" || bad 'cannot identify lab interface'
systemctl is-active --quiet idps-lab-web.service && ok 'lab web service is running' || bad 'idps-lab-web.service is not running'
curl -fsS http://10.13.37.20:8080/ >/dev/null 2>&1 && ok 'HTTP service answers on 10.13.37.20:8080' || bad 'HTTP service does not answer on 10.13.37.20:8080'
[[ -f /etc/suricata/suricata.yaml ]] && ok 'Suricata config exists' || bad 'missing /etc/suricata/suricata.yaml'
if command -v suricata >/dev/null 2>&1; then suricata -T -c /etc/suricata/suricata.yaml -S "$SCRIPT_DIR/lab01.rules" >/tmp/lab01-test.log 2>&1 && ok 'Suricata + lab01.rules' || bad 'Suricata rule/config check failed; see /tmp/lab01-test.log'; fi
[[ $fail -eq 0 ]] && echo 'SERVER PRE-FLIGHT PASSED.' || echo 'SERVER PRE-FLIGHT FAILED.'
exit $fail
