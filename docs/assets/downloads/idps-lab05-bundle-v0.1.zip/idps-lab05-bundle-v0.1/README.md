# IDPS Lab 05 Bundle v0.1

Лабораторная работа №5: чтение, изменение и самостоятельное создание простых правил Suricata.

## Состав

- `server/` — учебный HTTP-сервис, предварительная проверка и подготовка интерфейса;
- `client/` — проверка клиентской VM;
- `rules/01-base.rules` — готовое правило для разбора;
- `rules/02-modify-starter.rules` — правило, которое студент должен изменить;
- `rules/03-student.rules` — файл для первого собственного правила;
- `report/lab05-report.md` — шаблон отчёта.

## Требования

Сначала должен быть выполнен шаг `00 — Подготовка лабораторной среды` курса.

Основная схема:

- `idps-client` — `10.13.37.10/24`;
- `idps-server` — `10.13.37.20/24`;
- HTTP-сервис — `10.13.37.20:8080`;
- Suricata — ветка 8.x рекомендуется и используется как нормативная продуктовая документация курса.

## Начало

На сервере:

```bash
sudo bash server/setup-server.sh
sudo bash server/preflight-server.sh
sudo bash server/prepare-capture.sh
source server/load-vars.sh
```

На клиенте:

```bash
bash client/check-client.sh
```

Полная последовательность, тестовые запросы и требования к отчёту находятся на странице ЛР №5 в GitHub Pages.

Статус пакета: **RUNTIME QA REQUIRED** до end-to-end прогона на эталонных Ubuntu Desktop/Server 24.04.x.
