#!/usr/bin/env bash
set -u
fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
for c in ip curl; do command -v "$c" >/dev/null 2>&1 && ok "command: $c" || bad "missing command: $c"; done
ip -o -4 addr show | grep -q '10\.13\.37\.10/' && ok 'lab address 10.13.37.10 is present' || bad 'expected address 10.13.37.10/24 is missing'
curl -fsS http://10.13.37.20:8080/LAB5-PREFLIGHT >/tmp/lab05-client-check.txt 2>/dev/null && ok 'HTTP service reachable on 10.13.37.20:8080' || bad 'HTTP service is not reachable'
[[ $fail -eq 0 ]] && echo 'CLIENT CHECK PASSED.' || echo 'CLIENT CHECK FAILED.'
exit $fail
