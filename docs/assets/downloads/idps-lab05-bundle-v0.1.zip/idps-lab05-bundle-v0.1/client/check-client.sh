#!/usr/bin/env bash
set -u
fail=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
for cmd in ip curl; do command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"; done
CLIENT_IFACE="$(ip -o -4 addr show | awk '$4 == "10.13.37.10/24" {print $2; exit}')"
[[ -n "$CLIENT_IFACE" ]] && ok "учебный интерфейс: $CLIENT_IFACE" || bad 'не найден точный адрес 10.13.37.10/24'
if [[ -n "$CLIENT_IFACE" ]]; then
  ROUTE_DEV="$(ip route get 10.13.37.20 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
  [[ "$ROUTE_DEV" == "$CLIENT_IFACE" ]] && ok "маршрут к серверу проходит через $CLIENT_IFACE" || bad "маршрут к 10.13.37.20 проходит не через учебный интерфейс (dev=${ROUTE_DEV:-unknown})"
fi
curl -fsS http://10.13.37.20:8080/health >/dev/null 2>&1 && ok 'сервер 10.13.37.20:8080 доступен' || bad 'сервер 10.13.37.20:8080 недоступен'
if [[ $fail -eq 0 ]]; then echo 'CLIENT CHECK PASSED.'; else echo 'CLIENT CHECK FAILED.'; fi
exit $fail
