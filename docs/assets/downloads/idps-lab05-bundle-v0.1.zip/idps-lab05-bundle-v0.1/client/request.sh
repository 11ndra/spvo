#!/usr/bin/env bash
set -euo pipefail
PATH_PART="${1:-}"
if [[ -z "$PATH_PART" ]]; then
  echo 'Usage: bash client/request.sh /PATH' >&2
  exit 2
fi
[[ "$PATH_PART" == /* ]] || PATH_PART="/$PATH_PART"
echo "REQUEST=$PATH_PART"
curl -fsS "http://10.13.37.20:8080$PATH_PART"
