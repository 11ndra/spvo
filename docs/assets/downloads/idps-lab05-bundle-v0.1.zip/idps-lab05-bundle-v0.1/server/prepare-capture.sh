#!/usr/bin/env bash
set -u
if [[ $EUID -ne 0 ]]; then echo '[FAIL] Запустите через sudo.' >&2; exit 2; fi
LAB_IFACE="$(ip -o -4 addr show | awk '$4 == "10.13.37.20/24" {print $2; exit}')"
[[ -n "$LAB_IFACE" ]] || { echo '[FAIL] Не найден LAB_IFACE.' >&2; exit 1; }
command -v ethtool >/dev/null 2>&1 || { echo '[FAIL] Не найден ethtool.' >&2; exit 1; }

echo "Подготовка интерфейса $LAB_IFACE"
for feature in gro lro gso tso rx tx; do
  if ethtool -K "$LAB_IFACE" "$feature" off >/dev/null 2>&1; then
    printf '  [ OK ] %s off\n' "$feature"
  else
    printf '  [WARN] %s: драйвер не разрешил изменить параметр\n' "$feature"
  fi
done

echo 'Текущее состояние ключевых параметров:'
ethtool -k "$LAB_IFACE" 2>/dev/null \
  | grep -E '^(rx-checksumming|tx-checksumming|tcp-segmentation-offload|generic-segmentation-offload|generic-receive-offload|large-receive-offload):' \
  | sed 's/^/  /' || true

echo '[ OK ] Подготовка завершена. Запуски Suricata в этой лабораторной дополнительно используют -k none.'
