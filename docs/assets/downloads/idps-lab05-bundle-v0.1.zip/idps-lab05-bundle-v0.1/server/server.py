#!/usr/bin/env python3
import json
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

HOST = "10.13.37.20"
PORT = 8080
LOG = Path("/var/tmp/idps-lab/lab5-access.jsonl")


def now_iso():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class Handler(BaseHTTPRequestHandler):
    server_version = "IDPS-Lab5/1.0"

    def _record(self):
        parsed = urlsplit(self.path)
        src_ip, src_port = self.client_address[:2]
        dst_ip, dst_port = self.connection.getsockname()[:2]
        item = {
            "timestamp": now_iso(),
            "src_ip": src_ip,
            "src_port": src_port,
            "dst_ip": dst_ip,
            "dst_port": dst_port,
            "method": self.command,
            "uri": self.path,
            "path": parsed.path,
            "query": parsed.query,
        }
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(item, ensure_ascii=False) + "\n")

    def _reply(self, body=b"LAB5 OK\n"):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if urlsplit(self.path).path == "/health":
            self._reply(b"OK\n")
            return
        self._record()
        self._reply()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length:
            self.rfile.read(length)
        self._record()
        self._reply()

    def log_message(self, fmt, *args):
        return


if __name__ == "__main__":
    LOG.parent.mkdir(parents=True, exist_ok=True)
    LOG.touch(exist_ok=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
