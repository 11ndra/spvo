#!/usr/bin/env bash
set -u
if [[ $EUID -ne 0 ]]; then echo '[FAIL] Запустите через sudo.' >&2; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
fail=0; warn=0
ok(){ echo "[ OK ] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
wrn(){ echo "[WARN] $*"; warn=$((warn+1)); }

for cmd in ip curl jq python3 ss suricata tcpdump ethtool; do
  command -v "$cmd" >/dev/null 2>&1 && ok "команда: $cmd" || bad "не найдена команда: $cmd"
done

LAB_IFACE="$(ip -o -4 addr show | awk '$4 == "10.13.37.20/24" {print $2; exit}')"
[[ -n "$LAB_IFACE" ]] && ok "LAB_IFACE=$LAB_IFACE" || bad 'не найден точный адрес 10.13.37.20/24'
if [[ -n "$LAB_IFACE" ]]; then
  ROUTE_DEV="$(ip route get 10.13.37.10 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}')"
  [[ "$ROUTE_DEV" == "$LAB_IFACE" ]] && ok "маршрут к 10.13.37.10 проходит через $LAB_IFACE" || bad "маршрут к 10.13.37.10 проходит не через LAB_IFACE (dev=${ROUTE_DEV:-unknown})"
fi

systemctl is-active --quiet idps-lab-web.service && ok 'web-сервис запущен' || bad 'web-сервис не запущен'
curl -fsS http://10.13.37.20:8080/health >/dev/null 2>&1 && ok 'web-сервис отвечает' || bad 'web-сервис не отвечает'
if ss -ltn 2>/dev/null | grep -Eq '10\.13\.37\.20:8080[[:space:]]'; then
  ok 'TCP/8080 привязан к 10.13.37.20'
else
  bad 'TCP/8080 не привязан строго к 10.13.37.20'
fi

[[ -f /etc/suricata/suricata.yaml ]] && ok 'конфигурация Suricata существует' || bad 'нет /etc/suricata/suricata.yaml'

if command -v suricata >/dev/null 2>&1; then
  version="$(suricata -V 2>/dev/null | head -1 || true)"
  echo "[INFO] $version"
  if [[ "$version" != *' 8.'* && "$version" != *'version 8.'* ]]; then
    wrn 'курс проверяется по ветке Suricata 8.x; обнаружена другая версия'
  fi
fi

for rule in "$ROOT_DIR/rules/01-base.rules" "$ROOT_DIR/rules/02-modify-starter.rules"; do
  if [[ -f "$rule" ]] && suricata -T -c /etc/suricata/suricata.yaml -S "$rule" >/tmp/lab05-suricata-test.log 2>&1; then
    ok "Suricata принимает $(basename "$rule")"
  else
    bad "Suricata не принимает $(basename "$rule"); см. /tmp/lab05-suricata-test.log"
  fi
done

[[ -f "$ROOT_DIR/rules/03-student.rules" ]] && ok 'шаблон 03-student.rules существует' || bad 'нет 03-student.rules'

if [[ -n "$LAB_IFACE" ]] && ethtool -k "$LAB_IFACE" >/tmp/lab05-ethtool.txt 2>/dev/null; then
  if grep -Eq '^(generic-receive-offload|large-receive-offload): on' /tmp/lab05-ethtool.txt; then
    wrn 'GRO/LRO включён; перед запуском выполните sudo bash server/prepare-capture.sh'
  else
    ok 'GRO/LRO не включены'
  fi
fi

if [[ $fail -eq 0 ]]; then
  echo 'SERVER PRE-FLIGHT PASSED.'
  ((warn>0)) && echo "Предупреждений: $warn"
else
  echo 'SERVER PRE-FLIGHT FAILED.'
fi
exit $fail
