#!/usr/bin/env bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo 'Run with sudo.' >&2; exit 1; }
LABEL="${1:-}"
if [[ "$LABEL" != "before" && "$LABEL" != "after" ]]; then
  echo 'Usage: sudo bash server/run-suricata.sh <before|after>' >&2
  exit 2
fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RULE="$SCRIPT_DIR/lab05.rules"
CONFIG=/etc/suricata/suricata.yaml
IFACE="$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')"
[[ -n "$IFACE" ]] || { echo '[FAIL] cannot identify interface with 10.13.37.20/24' >&2; exit 1; }
OUT="/var/tmp/idps-lab/lab05-$LABEL"
mkdir -p /var/tmp/idps-lab
rm -rf "$OUT"
install -d -m 0755 "$OUT"

echo "[INFO] label=$LABEL"
echo "[INFO] interface=$IFACE"
echo "[INFO] rule=$(grep -v '^[[:space:]]*$' "$RULE" | head -n 1)"

echo '[INFO] validating rule before capture...'
suricata -T -c "$CONFIG" -S "$RULE" >/tmp/lab05-rule-test.log 2>&1 || {
  cat /tmp/lab05-rule-test.log >&2
  echo '[FAIL] Suricata rejected the rule. Capture was not started.' >&2
  exit 1
}
echo '[ OK ] rule/config validation passed'

if systemctl is-active --quiet suricata; then
  echo '[INFO] stopping system Suricata service to avoid competing capture'
  systemctl stop suricata
fi

echo "[INFO] writing EVE output under $OUT"
echo '[INFO] Press Ctrl+C after both test requests have been sent.'
exec suricata -k none -c "$CONFIG" -S "$RULE" -i "$IFACE" -l "$OUT"
