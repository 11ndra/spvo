#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo '[FAIL] Запустите через sudo.' >&2; exit 1; fi
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

ip -o -4 addr show | awk '$4 == "10.13.37.20/24" {found=1} END{exit !found}' || {
  echo '[FAIL] На сервере нет адреса 10.13.37.20/24.' >&2
  ip -br addr
  exit 1
}

for cmd in python3 curl suricata; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "[FAIL] Не найдена команда: $cmd" >&2; exit 1; }
done

# Системный экземпляр Suricata не используется: лаборатория запускает отдельный
# процесс на выбранном учебном интерфейсе и с отдельным каталогом результатов.
systemctl stop suricata >/dev/null 2>&1 || true

install -d -m 0755 /opt/idps-lab5 /var/tmp/idps-lab
install -m 0755 "$SCRIPT_DIR/server.py" /opt/idps-lab5/server.py
: > /var/tmp/idps-lab/lab5-access.jsonl
chmod 0644 /var/tmp/idps-lab/lab5-access.jsonl

cat > /etc/systemd/system/idps-lab-web.service <<'UNIT'
[Unit]
Description=IDPS Lab 5 controlled HTTP service
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /opt/idps-lab5/server.py
Restart=on-failure
RestartSec=1

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable idps-lab-web.service >/dev/null 2>&1 || true
systemctl restart idps-lab-web.service
sleep 1

if ! curl -fsS http://10.13.37.20:8080/health >/dev/null; then
  echo '[FAIL] Учебный HTTP-сервис не отвечает.' >&2
  systemctl --no-pager --full status idps-lab-web.service || true
  exit 1
fi

echo '[ OK ] Учебный HTTP-сервис запущен на 10.13.37.20:8080.'
echo '[ OK ] Системный сервис Suricata остановлен; Suricata будет запускаться вручную.'
