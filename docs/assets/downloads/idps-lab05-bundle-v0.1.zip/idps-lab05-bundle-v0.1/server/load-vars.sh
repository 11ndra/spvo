#!/usr/bin/env bash
# Выполните в каждом новом терминале idps-server:
# source server/load-vars.sh
LAB_IFACE="$(ip -o -4 addr show | awk '$4 == "10.13.37.20/24" {print $2; exit}')"
if [[ -z "$LAB_IFACE" ]]; then
  echo '[FAIL] Не найден интерфейс с адресом 10.13.37.20/24.' >&2
  return 1 2>/dev/null || exit 1
fi
export LAB_IFACE
printf 'LAB_IFACE=%s\n' "$LAB_IFACE"
