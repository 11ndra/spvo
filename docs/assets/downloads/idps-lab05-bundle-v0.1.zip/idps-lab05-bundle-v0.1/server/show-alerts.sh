#!/usr/bin/env bash
set -euo pipefail
LABEL="${1:-}"
if [[ "$LABEL" != "before" && "$LABEL" != "after" ]]; then
  echo 'Usage: bash server/show-alerts.sh <before|after>' >&2
  exit 2
fi
FILE="/var/tmp/idps-lab/lab05-$LABEL/eve.json"
[[ -r "$FILE" ]] || { echo "[FAIL] cannot read $FILE" >&2; exit 1; }
COUNT="$(jq -s '[.[] | select(.event_type=="alert" and .alert.signature_id==1000005)] | length' "$FILE")"
echo "LABEL=$LABEL"
echo "SID1000005_ALERTS=$COUNT"
jq 'select(.event_type=="alert" and .alert.signature_id==1000005) | {timestamp,src_ip,src_port,dest_ip,dest_port,http_url:(.http.url // null),signature:.alert.signature,sid:.alert.signature_id,rev:(.alert.rev // null)}' "$FILE"
