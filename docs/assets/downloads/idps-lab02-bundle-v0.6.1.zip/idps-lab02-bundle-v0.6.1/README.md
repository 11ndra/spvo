# ЛР №2 v0.6.1 — один эпизод, два источника

Пакет используется вместе со страницей ЛР №2 на портале курса. Базовая среда остаётся той же, что и в ЛР №1; VM заново не создаются.

```text
HTTP GET /lab2-trigger/LAB2-NET
        ↓
idps-server:8080
        ↓
изменение /var/tmp/idps-lab/lab2-evidence.txt
        ├───────────────┐
        ↓               ↓
Suricata EVE        Linux Audit
SID 1000002         key=idps_lab_host
```

На сервере сначала разверните учебный сервис:

```bash
sudo bash server/setup-server.sh
sudo bash server/preflight-server.sh
```

Preflight проверяет окружение и сервисы, но намеренно не добавляет Linux Audit rule. Хостовый источник студент создаёт сам:

```bash
sudo mkdir -p /var/tmp/idps-lab
sudo rm -f /var/tmp/idps-lab/lab2-evidence.txt
sudo auditctl -D -k idps_lab_host 2>/dev/null || true
sudo auditctl -a always,exit -F arch=b64 -F dir=/var/tmp/idps-lab/ -F perm=wa -F key=idps_lab_host
sudo auditctl -s
sudo auditctl -l -k idps_lab_host
```

Проверьте `server/lab02.rules` через `suricata -T`, затем запустите Suricata на интерфейсе с адресом `10.13.37.20/24`. В типовой среде это `enp0s8`:

```bash
rm -rf "$HOME/lab02-output"
mkdir -p "$HOME/lab02-output"

sudo suricata \
  -k none \
  -c /etc/suricata/suricata.yaml \
  -S "$PWD/server/lab02.rules" \
  -i enp0s8 \
  -l "$HOME/lab02-output"
```

На клиенте выполните `bash client/check-client.sh`, затем откройте `http://10.13.37.20:9090`. Live Console используется для прогноза и визуального сравнения, но итоговые факты нужно подтвердить напрямую.

Сетевой артефакт:

```bash
jq -c '
  select(.event_type=="alert" and .alert.signature_id==1000002) |
  {timestamp,src_ip,dest_ip,url:.http.url,sid:.alert.signature_id,action:.alert.action}
' "$HOME/lab02-output/eve.json"
```

Хостовый артефакт:

```bash
sudo ausearch -k idps_lab_host -ts recent -i
```

Один Linux Audit event может состоять из нескольких records с одним serial. Рассматривайте связанный блок целиком, а не одну случайную строку.

После сохранения evidence остановите Suricata одним `Ctrl+C`. Учебное audit-правило можно удалить:

```bash
sudo auditctl -D -k idps_lab_host
sudo auditctl -l -k idps_lab_host
```

После удаления команда `auditctl -l -k idps_lab_host` не должна показывать правило. Live Console при обновлении снова должна показать, что Suricata остановлена, а Linux Audit rule не готово.

Смысл работы: Suricata подтверждает сетевую сторону контролируемого эпизода, Linux Audit — локальную файловую операцию. Ни один из этих источников не является автоматически «полной картиной» события.
