# IDPS Environment Setup v1.2

Набор вспомогательных скриптов для подготовки двух постоянных VM курса:

- `bootstrap-client.sh` — устанавливает системные инструменты на Ubuntu Desktop;
- `bootstrap-server.sh` — устанавливает системные инструменты на Ubuntu Server, включает Linux Audit и SSH, а системный сервис Suricata отключает;
- `show-network-candidates.sh` — показывает интерфейсы, IPv4-адреса, драйверы и маршрут по умолчанию; ничего не изменяет;
- `check-client-environment.sh` — проверяет адресацию, маршрутизацию, драйверы `virtio_net`, инструменты и связь с сервером;
- `check-server-environment.sh` — дополнительно проверяет Suricata 8.x, Linux Audit, состояние системного сервиса Suricata и готовность SSH.

Скрипты намеренно не создают VM и не выбирают сетевой интерфейс за студента. Два адаптера и статические адреса на Host-Only остаются частью ручной подготовки среды.

## Базовая сеть курса

На обеих VM:

```text
Adapter 1: NAT       / Paravirtualized Network (virtio-net)
Adapter 2: Host-Only / Paravirtualized Network (virtio-net)
```

Адресный план:

```text
Windows host  10.13.37.1/24
idps-client   10.13.37.10/24
idps-server   10.13.37.20/24
```

На Host-Only-интерфейсе не задаются gateway и DNS. Единственный маршрут `default` должен оставаться через NAT.

## Изменения v1.2

- оба checker-скрипта проверяют фактический драйвер NAT и Host-Only интерфейсов и требуют `virtio_net`;
- исправлена терминология `Internal Network` → `Host-Only`;
- hostname сравнивается без учёта регистра;
- усилена проверка маршрутизации: единственный `default` должен идти не через LAB-интерфейс, а маршрут к соседней VM — через LAB-интерфейс;
- `bootstrap-client.sh` устанавливает `ethtool`, чтобы клиентская VM тоже могла подтвердить тип виртуальной NIC;
- `bootstrap-server.sh` выполняет `systemctl disable --now suricata`, потому что в лабораториях Suricata запускается вручную;
- серверный checker требует `inactive` + `disabled` для системного сервиса Suricata;
- серверный checker проверяет `auditd`, `enabled 1`, отсутствие `never,task`, SSH service и TCP/22 listener;
- `show-network-candidates.sh` показывает драйвер каждого Ethernet-интерфейса, если доступен `ethtool`.
