#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail() { echo "[FAIL] $*" >&2; exit 1; }
for app in suricata suricatasc curl ip python3 sha256sum pgrep cmp grep awk; do command -v "$app" >/dev/null 2>&1 || fail "required command not found: $app"; done
[ -f /etc/suricata/suricata.yaml ] || fail 'existing Suricata YAML not found'
pgrep -x suricata >/dev/null 2>&1 && fail 'another Suricata process is running; stop previous laboratory run first'
if command -v nft >/dev/null 2>&1 && sudo nft list table inet spvo_lab08_ips >/dev/null 2>&1; then
  fail 'LAB08 nft table still exists; complete LAB08 cleanup first'
fi
LAB_IFACE=$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')
[[ -n "$LAB_IFACE" ]] || fail 'server LAB interface with 10.13.37.20/24 not found'
if [[ -d evidence/live && -n "$(find evidence/live -mindepth 1 -print -quit)" ]]; then fail 'evidence/live already contains prior data; use a clean extraction'; fi
cmp -s server/lab09.rules server/revisions/rev1.rules || fail 'start with original rev1.rules'
sudo suricata -T -c /etc/suricata/suricata.yaml -S "$PWD/server/lab09.rules" || fail 'Suricata initial ruleset -T failed'
body=$(curl --noproxy '*' --silent --show-error --fail --max-time 5 'http://10.13.37.20:8080/LAB9-ALPHA?lab9_phase=preflight&lab9_case=A') || fail 'existing HTTP service not reachable'
grep -Fq 'path=/LAB9-ALPHA?lab9_phase=preflight&lab9_case=A' <<< "$body" || fail 'HTTP service returned unexpected content'
printf 'PREFLIGHT_OK interface=%s ruleset=rev1 service=:8080\n' "$LAB_IFACE"
