#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
LAB_IFACE=$(ip -o -4 addr show | awk '$4 ~ /^10\.13\.37\.20\// {print $2; exit}')
[[ -n "$LAB_IFACE" ]] || { echo '[FAIL] LAB interface not found' >&2; exit 1; }
[[ ! -e evidence/live/eve.json ]] || { echo '[FAIL] old eve.json exists; use new unpacked bundle' >&2; exit 1; }
mkdir -p evidence/live
printf 'RUNNING passive Suricata on %s; press Ctrl+C only after rollback check\n' "$LAB_IFACE"
exec sudo suricata -k none -c /etc/suricata/suricata.yaml -S "$PWD/server/lab09.rules" -i "$LAB_IFACE" -l "$PWD/evidence/live" --set unix-command.enabled=yes
