#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
phase=${1:-}
case "$phase" in before|after|rejected|rollback) ;; *) echo 'Usage: bash client/send-pair.sh {before|after|rejected|rollback}' >&2; exit 2;; esac
mkdir -p evidence/client
for label in A B; do
  case "$label" in A) segment='LAB9-ALPHA';; B) segment='LAB9-BETA';; esac
  uri="/${segment}?lab9_phase=${phase}&lab9_case=${label}"
  file="evidence/client/${phase}-${label}.txt"
  code=$(curl --noproxy '*' --silent --show-error --max-time 7 --output "$file" --write-out '%{http_code}' "http://10.13.37.20:8080${uri}") || { echo "[FAIL] HTTP transport for $phase/$label" >&2; exit 1; }
  [[ "$code" == 200 ]] || { echo "[FAIL] $phase/$label HTTP ${code} expected 200" >&2; exit 1; }
  grep -Fq "path=${uri}" "$file" || { echo "[FAIL] unexpected response $phase/$label" >&2; exit 1; }
  printf 'PHASE=%s CASE=%s HTTP=200 URI=%s VERIFIED\n' "$phase" "$label" "$uri"
done
