#!/usr/bin/env python3
"""Summarize real Suricata EVE for the controlled LAB09 change lifecycle.
No EVE/PCAP is generated here. Fail closed on missing or ambiguous HTTP evidence.
"""
import json
import sys
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

PHASES = ("before", "after", "rejected", "rollback")
EXPECTED = {"before": "A", "after": "B", "rejected": "B", "rollback": "A"}
REV = {"before": 1, "after": 2, "rejected": 2, "rollback": 1}

def expected_uri(phase, label):
    segment = "LAB9-ALPHA" if label == "A" else "LAB9-BETA"
    return f"/{segment}?lab9_phase={phase}&lab9_case={label}"

def analyze(path):
    http = {}
    used_flows = {}
    alerts = defaultdict(list)
    with open(path, encoding="utf-8") as fp:
        for number, line in enumerate(fp, 1):
            if not line.strip():
                continue
            try:
                e = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid EVE JSON line {number}: {exc}") from exc
            flow_id = e.get("flow_id")
            if e.get("event_type") == "alert" and e.get("alert", {}).get("signature_id") == 1000009:
                alerts[flow_id].append(e)
                continue
            if e.get("event_type") != "http":
                continue
            uri = (e.get("http") or {}).get("url", "")
            u = urlsplit(uri)
            if "lab9_phase=" not in u.query and "lab9_case=" not in u.query:
                continue
            q = parse_qs(u.query)
            phase, label = q.get("lab9_phase", [None]), q.get("lab9_case", [None])
            if len(phase) != 1 or len(label) != 1:
                raise ValueError(f"line {number}: ambiguous lab9_phase/lab9_case query")
            phase, label = phase[0], label[0]
            if phase not in PHASES or label not in ("A", "B"):
                raise ValueError(f"line {number}: unexpected marker {phase!r}/{label!r}")
            if uri != expected_uri(phase, label):
                raise ValueError(f"line {number}: unexpected URI {uri!r}")
            if (e.get("src_ip"), e.get("dest_ip")) != ("10.13.37.10", "10.13.37.20"):
                raise ValueError(f"line {number}: HTTP from unexpected IPs")
            if flow_id is None:
                raise ValueError(f"line {number}: missing HTTP flow_id")
            key = (phase, label)
            if key in http:
                raise ValueError(f"duplicate HTTP event for {key}")
            if flow_id in used_flows:
                raise ValueError(f"flow_id reused across tests {flow_id}")
            used_flows[flow_id] = key
            http[key] = flow_id
    wanted = {(phase, label) for phase in PHASES for label in "AB"}
    if set(http) != wanted:
        missing = sorted(wanted - set(http))
        raise ValueError(f"expected eight distinct HTTP events; missing {missing}")
    for phase in PHASES:
        for label in "AB":
            flow_id = http[(phase, label)]
            rows = alerts[flow_id]
            observed = bool(rows)
            target = label == EXPECTED[phase]
            if observed != target:
                raise ValueError(f"{phase}/{label} alert={observed}, expected={target}")
            for a in rows:
                alert = a.get("alert", {})
                if alert.get("action") not in ("allowed", "alert"):
                    raise ValueError(f"unexpected IPS action for passive LAB09: {alert.get('action')}")
                if alert.get("rev") is not None and alert["rev"] != REV[phase]:
                    raise ValueError(f"{phase}/{label} wrong revision: {alert['rev']} expected {REV[phase]}")
            print(f"PHASE={phase:<8} CASE={label} HTTP=YES SID1000009={'YES' if observed else 'NO '} ALERT_ROWS={len(rows)}")
    foreign = [fid for fid in alerts if fid not in used_flows]
    if foreign:
        raise ValueError(f"SID 1000009 alerts on unknown HTTP flows: {foreign}")
    print("LAB09_EVE_VERIFIED: eight HTTP requests and correct signature match in four successive active states")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("Usage: python3 tools/eve-phase-table.py evidence/live/eve.json")
    try:
        analyze(Path(sys.argv[1]))
    except (ValueError, OSError) as exc:
        sys.exit(f"[FAIL] {exc}")
