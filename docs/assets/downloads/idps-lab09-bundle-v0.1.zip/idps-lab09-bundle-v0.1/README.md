# ЛР №9 v0.1 — Управляемая смена правила Suricata

Одна пара ранее созданных VM, существующий HTTP :8080, пассивный режим Suricata 8, Unix socket и suricatasc. Стартовая редакция правила: server/lab09.rules (rev:1).

На idps-server: `bash server/preflight.sh`; затем в отдельном терминале `bash server/run-live.sh`. На idps-client: `bash client/send-pair.sh before` (и далее after, rejected, rollback согласно опубликованной лабораторной).

Входные события создаёт настоящий HTTP-клиент. EVE создаёт настоящий движок Suricata. `tools/eve-phase-table.py` только проверяет реальные журналы и отказывается выдавать положительный результат при отсутствии подтверждения.

Файл `server/revisions/rev-broken.rules` намеренно НЕВАЛИДЕН и предназначен только для отрицательного теста `suricata -T`. Не вызывайте reload при нахождении этого файла в `server/lab09.rules`.

После работы остановите Suricata (Ctrl+C) и заполните `report/lab09-report.md`. Правила nftables/iptables и конфигурация приложения не меняются. Весь эксперимент ограничен Host-Only LAB-сетью.
