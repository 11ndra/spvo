# IDPS Lab 04 bundle v0.2

ЛР №4 закрепляет различия между основаниями обнаружения из Главы 5 без написания собственных правил Suricata.

Один контролируемый набор событий сохраняется в:

```text
/var/tmp/idps-lab/lab4-events.jsonl
```

Затем один и тот же файл анализируется по четырём основаниям решения:

```text
signature  — заранее известный признак;
protocol   — состояние синтетического учебного протокола;
threshold  — фиксированный порог по серии событий;
anomaly    — отклонение всплеска от измеренного базового профиля.
```

На сервере:

```bash
sudo bash server/setup-server.sh
sudo bash server/preflight-server.sh
sudo bash server/reset-evidence.sh
```

На клиенте сначала выполните проверку связи:

```bash
bash client/check-client.sh
```

`check-client.sh` создаёт один технический HTTP-запрос, поэтому после него снова очистите журнал на сервере:

```bash
sudo bash server/reset-evidence.sh
```

Только затем запустите чистый сценарий на клиенте:

```bash
bash client/run-scenario.sh
```

Перед всплеском сценарий выдерживает техническую паузу `2.2 s`, чтобы фиксированное окно `2 s` не захватывало события базового профиля. Внутри самого всплеска искусственной задержки нет.

После сценария на сервере:

```bash
python3 server/analyze-methods.py --method signature
python3 server/analyze-methods.py --method protocol
python3 server/analyze-methods.py --method threshold
python3 server/analyze-methods.py --method anomaly
python3 server/analyze-methods.py --method all
```

Лаборатория использует синтетический учебный сценарий. Результаты показывают выполнение условий детектора, а не факт реальной атаки или компрометации.
