#!/usr/bin/env bash
# Fetch only; never starts containers or changes the host firewall.
set -euo pipefail
cd "$(dirname "$0")/.."
PIN=a1978a2fed195acd093010af6395f86a281537ca
command -v git >/dev/null
if [[ -e upstream ]]; then
  echo 'upstream already exists: use the prepared copy; this script will not overwrite it.' >&2
  exit 1
fi
git clone --no-checkout https://github.com/digininja/DVWA.git upstream
git -C upstream checkout --detach "$PIN"
test "$(git -C upstream rev-parse HEAD)" = "$PIN"
printf 'DVWA source ready: %s\n' "$PIN"
echo 'Next: sudo docker compose -f setup/compose.yaml config'
