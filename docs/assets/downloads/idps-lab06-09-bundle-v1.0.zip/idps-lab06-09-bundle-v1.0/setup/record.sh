#!/usr/bin/env bash
# Run as a regular user with working sudo. Does not change containers.
set -euo pipefail
cd "$(dirname "$0")/.."
PIN=a1978a2fed195acd093010af6395f86a281537ca
test "$(git -C upstream rev-parse HEAD)" = "$PIN"
if [[ -n "$(git -C upstream status --porcelain --untracked-files=all)" ]]; then
  echo 'Source has changed; save the diff and rebuild before collecting a baseline.' >&2
  exit 1
fi
command -v python3 >/dev/null
mkdir -p evidence
OUT=$(mktemp -d "$PWD/evidence/environment-XXXXXX")
date -u +%FT%TZ > "$OUT/collected-at.txt"
git -C upstream rev-parse HEAD > "$OUT/dvwa-commit.txt"
sudo docker version > "$OUT/docker-version.txt"
sudo docker compose version > "$OUT/compose-version.txt"
sudo docker compose -f setup/compose.yaml config > "$OUT/compose.yaml"
sudo docker compose -f setup/compose.yaml ps > "$OUT/containers.txt"
for SERVICE in dvwa db; do
  CID=$(sudo docker compose -f setup/compose.yaml ps -q "$SERVICE")
  test -n "$CID" || { echo "$SERVICE is not running" >&2; exit 1; }
  sudo docker inspect --format '{{.Image}} {{json .NetworkSettings.Ports}}' "$CID" > "$OUT/$SERVICE-runtime.txt"
  IMAGE=$(sudo docker inspect --format '{{.Image}}' "$CID")
  sudo docker image inspect --format '{{.Id}} {{json .RepoDigests}}' "$IMAGE" > "$OUT/$SERVICE-image.txt"
done
python3 - "$OUT" <<'PY'
import hashlib, pathlib, sys
out = pathlib.Path(sys.argv[1])
source = pathlib.Path('upstream')
paths = [pathlib.Path('setup/compose.yaml'), source/'Dockerfile']
for module in ['sqli', 'xss_r', 'xss_s', 'exec', 'fi']:
    paths += sorted((source/'vulnerabilities'/module/'source').glob('*.php'))
with (out/'source-sha256.txt').open('w') as f:
    for p in paths:
        f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p)+'\n')
PY
printf 'Saved: %s\n' "$OUT"
