#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "[FAIL] $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || fail 'Run: sudo bash server/analyze-pcap.sh'
for tool in suricata sha256sum tee cp date; do command -v "$tool" >/dev/null || fail "missing: $tool"; done
[[ -s evidence/capture/requests.pcap ]] || fail 'missing/nonempty PCAP required'
[[ ! -e evidence/analysis ]] || fail 'analysis exists; preserve it and use a new extraction for a new experiment'
mkdir evidence/analysis
out="$PWD/evidence/analysis"
cp server/lab11.rules "$out/active.rules"
sha256sum evidence/capture/requests.pcap "$out/active.rules" /etc/suricata/suricata.yaml > "$out/inputs.sha256"
suricata -V > "$out/version.txt"
date -u +%FT%TZ > "$out/started.txt"
mkdir "$out/validation"
suricata -T -c /etc/suricata/suricata.yaml -S "$out/active.rules" -l "$out/validation" > "$out/validation.log" 2>&1 || { cat "$out/validation.log"; fail 'rule/config validation failed; no replay'; }
printf 'suricata -k none -c /etc/suricata/suricata.yaml -S %q -r %q -l %q\n' "$out/active.rules" "$PWD/evidence/capture/requests.pcap" "$out" > "$out/command.txt"
# Offline virtual-lab PCAP only. No inline enforcement or service configuration changes.
suricata -k none -c /etc/suricata/suricata.yaml -S "$out/active.rules" -r "$PWD/evidence/capture/requests.pcap" -l "$out" 2>&1 | tee "$out/replay.log"
sha256sum -c "$out/inputs.sha256" > "$out/inputs-check.txt" || fail 'input changed during replay'
date -u +%FT%TZ > "$out/completed.txt"
echo 'REPLAY_COMPLETED: inspect EVE and compare with independent client evidence'
