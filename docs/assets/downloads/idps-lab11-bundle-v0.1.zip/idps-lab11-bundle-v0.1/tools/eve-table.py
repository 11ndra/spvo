#!/usr/bin/env python3
"""Validate supplied EVE, print observations separately from the teaching forecast."""
import json,sys
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
PATHS={'A':'/lab11-marker','B':'/lab11-%6darker','C':'/lab11-normal','D':'/lab11-marker-extra'}
EXPECTED={'A':(1,1),'B':(0,1),'C':(0,0),'D':(1,1)}
SIDS=(1000011,1000012)
def analyze(records):
 http={};alerts=[];seen=set()
 for e in records:
  if not isinstance(e,dict):raise ValueError('EVE record must be object')
  h=e.get('http',{});a=e.get('alert',{})
  if not isinstance(h,dict) or not isinstance(a,dict):raise ValueError('invalid HTTP/alert structure')
  uri=h.get('url','')
  if not isinstance(uri,str):raise ValueError('HTTP URL must be string')
  relevant='lab11_case=' in uri or a.get('signature_id') in SIDS
  if not relevant:continue
  t=datetime.fromisoformat(e.get('timestamp','').replace('Z','+00:00'))
  if t.tzinfo is None:raise ValueError('timestamp timezone required')
  if (e.get('src_ip'),e.get('dest_ip'),e.get('dest_port'),e.get('proto')) != ('10.13.37.10','10.13.37.20',8080,'TCP'):raise ValueError('lab event from wrong tuple')
  for field in ('flow_id','tx_id'):
   if type(e.get(field)) is not int or e[field]<0:raise ValueError(f'{field} must be nonnegative integer')
  if type(e.get('src_port')) is not int or not 0<e['src_port']<65536:raise ValueError('source port required')
  key=(e['flow_id'],e['tx_id'],e['src_port'])
  if e.get('event_type')=='http':
   q=parse_qs(urlsplit(uri).query,keep_blank_values=True); labels=q.get('lab11_case',[])
   if len(labels)!=1 or labels[0] not in PATHS:raise ValueError('invalid/ambiguous case')
   label=labels[0];allowed={f'{PATHS[label]}?lab11_case={label}'}
   # EVE URL is a logged field, not a dump of both detection buffers.
   if label=='B':allowed.add('/lab11-marker?lab11_case=B')
   if uri not in allowed:raise ValueError('unexpected lab URI')
   if h.get('http_method')!='GET' or h.get('status')!=200:raise ValueError('expected complete GET/200 exchange')
   if label in http or e['flow_id'] in seen:raise ValueError('duplicate case or reused flow; expected four connections')
   http[label]=(key,uri);seen.add(e['flow_id'])
  elif e.get('event_type')=='alert' and a.get('signature_id') in SIDS:
   if a.get('rev')!=1 or a.get('action')!='allowed':raise ValueError('unexpected revision/action')
   alerts.append((key,a['signature_id']))
 if set(http)!=set(PATHS):raise ValueError('missing HTTP cases: '+','.join(sorted(set(PATHS)-set(http))))
 if any(k not in {v[0] for v in http.values()} for k,sid in alerts):raise ValueError('alert not linked to a lab HTTP transaction')
 result=[]
 for case in PATHS:
  key,uri=http[case];counts=tuple(alerts.count((key,sid)) for sid in SIDS)
  if any(n>1 for n in counts):raise ValueError('duplicate lab alert')
  result.append((case,counts,counts==EXPECTED[case],uri))
 return result

def main():
 if len(sys.argv)!=2:raise ValueError('Usage: python3 tools/eve-table.py evidence/analysis/eve.json')
 p=Path(sys.argv[1]);rows=[]
 for n,line in enumerate(p.read_text().splitlines(),1):
  if not line.strip():continue
  try:rows.append(json.loads(line))
  except ValueError as exc:raise ValueError(f'line {n}: invalid JSON') from exc
 result=analyze(rows)
 print('CASE  RAW_SID1000011  NORMALIZED_SID1000012  FORECAST_MATCH  EVE_URL')
 for case,counts,match,uri in result:print(case,*counts,'YES' if match else 'NO',uri,sep='  ')
 print('DATA_COMPLETE: four supplied HTTP transactions linked; verify PCAP, client evidence and input hashes separately')
 if not all(r[2] for r in result):
  print('OBSERVED_DIFFERENCE: preserve the result; inspect configuration and rule buffers. Do not edit EVE to match the forecast.')
  return 2
 print('FORECAST_MATCH: limited to these inputs and this configuration; not a statement about attacks or all HTTP servers')
 return 0
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,TypeError,AttributeError,KeyError) as exc:sys.exit('[INCOMPLETE_OR_INVALID] '+str(exc))
