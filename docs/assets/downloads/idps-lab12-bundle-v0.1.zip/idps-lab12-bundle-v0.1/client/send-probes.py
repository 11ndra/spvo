#!/usr/bin/env python3
"""Four fixed, harmless requests per dataset to the existing lab service. No external targets."""
import json,socket,sys
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def now():return datetime.now(timezone.utc).isoformat()
def request_bytes(uri):
 return (f'GET {uri} HTTP/1.1\r\nHost: 10.13.37.20:8080\r\nUser-Agent: SPVO-LAB12\r\nConnection: close\r\n\r\n').encode('ascii')
def check_response(data,uri):
 head,sep,body=data.partition(b'\r\n\r\n')
 if not sep:raise ValueError('incomplete HTTP response headers')
 status=head.split(b'\r\n')[0].split()
 if len(status)<2 or status[1]!=b'200':raise ValueError('HTTP response is not 200')
 lengths=[line.split(b':',1)[1].strip() for line in head.split(b'\r\n')[1:] if line.lower().startswith(b'content-length:')]
 if len(lengths)!=1 or len(body)!=int(lengths[0]):raise ValueError('missing/ambiguous Content-Length or incomplete body')
 if f'path={uri}'.encode() not in body.splitlines():raise ValueError('unexpected service response; expected LAB05 path echo')
def main():
 if len(sys.argv)!=2 or sys.argv[1] not in ('tune','holdout'):raise ValueError('Usage: python3 client/send-probes.py tune|holdout')
 split=sys.argv[1];cases=json.loads((ROOT/'data'/f'{split}.json').read_text())
 out=ROOT/'evidence/client'/split;out.mkdir(parents=True,exist_ok=False)
 for row in cases:
  case,uri=row['case'],row['uri'];request=request_bytes(uri)
  (out/f'{case}-request.bin').write_bytes(request)
  meta={'case':case,'uri':uri,'started_at':now(),'status':'started'}
  try:
   with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as conn:
    conn.settimeout(8);conn.bind(('10.13.37.10',0));conn.connect(('10.13.37.20',8080))
    meta['local']=conn.getsockname();meta['peer']=conn.getpeername()
    conn.sendall(request);meta['sent_at']=now()
    data=bytearray()
    with (out/f'{case}-response.bin').open('xb') as response:
     while True:
      chunk=conn.recv(8192)
      if not chunk:break
      response.write(chunk);response.flush();data.extend(chunk)
      if len(data)>65536:raise ValueError('unexpectedly large response; stopped')
   check_response(bytes(data),uri);meta['status']='HTTP_200_PATH_VERIFIED'
  except (OSError,ValueError) as exc:
   meta['status']='ERROR';meta['error']=str(exc);raise
  finally:
   meta['ended_at']=now();(out/f'{case}-meta.json').write_text(json.dumps(meta,indent=2)+'\n')
  print(f'CASE={case} HTTP=200 URI={uri}')
if __name__=='__main__':
 try:main()
 except (OSError,ValueError) as exc:sys.exit('[FAIL] '+str(exc)+'; preserve evidence, retry in a NEW extraction directory')
