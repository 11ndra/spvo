#!/usr/bin/env python3
"""Metrics from supplied EVE and scenario labels; missing evidence is not TN/FN."""
import json,re,sys
from datetime import datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SID=10000120

def evaluate(cases,records):
 expected={}
 for c in cases:
  if type(c.get('positive')) is not bool:raise ValueError('label must be boolean')
  if not isinstance(c.get('case'),str) or not isinstance(c.get('uri'),str):raise ValueError('invalid case')
  path,sep,query=c['uri'].partition('?')
  if not sep or query!='lab12_case='+c['case']:raise ValueError('invalid URI marker')
  truth=bool(re.fullmatch(r'/lab12-review/item-[0-9]{2}',path))
  if truth!=c['positive']:raise ValueError('scenario label contradicts stated target definition')
  if c['uri'] in expected:raise ValueError('duplicate scenario URI')
  expected[c['uri']]=c
 if len(expected)!=4 or len({c['case'] for c in cases})!=4:raise ValueError('four distinct cases required')
 observed={};alerts=[];flows=set()
 for e in records:
  if not isinstance(e,dict):raise ValueError('EVE must contain objects')
  h=e.get('http',{});a=e.get('alert',{})
  if not isinstance(h,dict) or not isinstance(a,dict):raise ValueError('invalid HTTP/alert structure')
  uri=h.get('url','')
  if not isinstance(uri,str):raise ValueError('URL must be string')
  if 'lab12_case=' not in uri and a.get('signature_id')!=SID:continue
  t=datetime.fromisoformat(e.get('timestamp','').replace('Z','+00:00'))
  if t.tzinfo is None:raise ValueError('timestamp timezone required')
  if (e.get('src_ip'),e.get('dest_ip'),e.get('dest_port'),e.get('proto'))!=('10.13.37.10','10.13.37.20',8080,'TCP'):raise ValueError('wrong tuple')
  for field in ('flow_id','tx_id'):
   if type(e.get(field)) is not int or e[field]<0:raise ValueError('invalid flow_id/tx_id')
  if type(e.get('src_port')) is not int or not 0<e['src_port']<65536:raise ValueError('invalid source port')
  key=(e['flow_id'],e['tx_id'],e['src_port'])
  if e.get('event_type')=='http':
   if uri not in expected:raise ValueError('unexpected URI or mixed datasets')
   if h.get('http_method')!='GET' or h.get('status')!=200:raise ValueError('complete GET/200 required')
   if uri in observed or e['flow_id'] in flows:raise ValueError('duplicate case/reused flow')
   observed[uri]=key;flows.add(e['flow_id'])
  elif e.get('event_type')=='alert' and a.get('signature_id')==SID:
   if a.get('action')!='allowed' or a.get('rev')!=1:raise ValueError('unexpected alert action/revision')
   alerts.append(key)
 if set(observed)!=set(expected):raise ValueError('missing HTTP evidence; do not count absent requests as negatives')
 if len(set(alerts))!=len(alerts):raise ValueError('duplicate alert')
 if not set(alerts)<=set(observed.values()):raise ValueError('alert not linked to this dataset')
 totals=dict(TP=0,FP=0,FN=0,TN=0);rows=[]
 for c in cases:
  hit=observed[c['uri']] in alerts;truth=c['positive']
  outcome=('TP' if hit else 'FN') if truth else ('FP' if hit else 'TN')
  totals[outcome]+=1;rows.append({'case':c['case'],'positive':truth,'alert':hit,'outcome':outcome,'uri':c['uri']})
 def ratio(n,d):return n/d if d else None
 t=totals
 metrics={'precision':ratio(t['TP'],t['TP']+t['FP']),'recall':ratio(t['TP'],t['TP']+t['FN']),'FPR':ratio(t['FP'],t['FP']+t['TN']),'accuracy':ratio(t['TP']+t['TN'],len(cases))}
 return {'rows':rows,'counts':totals,'metrics':metrics}

def main():
 if len(sys.argv)!=2 or sys.argv[1] not in ('tune','holdout'):raise ValueError('Usage: sudo python3 tools/evaluate.py tune|holdout')
 split=sys.argv[1];folder=ROOT/'evidence'/split
 if not (folder/'completed.txt').is_file():raise ValueError('completed replay marker absent; inspect replay log')
 cases=json.loads((ROOT/'data'/f'{split}.json').read_text());records=[]
 for n,line in enumerate((folder/'eve.json').read_text().splitlines(),1):
  if line.strip():
   try:records.append(json.loads(line))
   except ValueError as exc:raise ValueError(f'invalid JSON line {n}') from exc
 result=evaluate(cases,records)
 print('CASE  TRUTH  ALERT  OUTCOME  URI')
 for r in result['rows']:print(r['case'],'POS' if r['positive'] else 'NEG','YES' if r['alert'] else 'NO',r['outcome'],r['uri'],sep='  ')
 print(' '.join(f'{k}={v}' for k,v in result['counts'].items()))
 print(' '.join(f'{k}={v:.3f}' if v is not None else f'{k}=N/A' for k,v in result['metrics'].items()))
 print('EVALUATION_COMPLETE: metrics describe this dataset only, not a claim of attacks or production performance')
 return 0
if __name__=='__main__':
 try:sys.exit(main())
 except (OSError,ValueError,TypeError,KeyError,AttributeError) as exc:sys.exit('[INCOMPLETE_OR_INVALID] '+str(exc))
