#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
fail(){ echo "[FAIL] $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || fail 'Run with sudo'
split=${1:-}
case "$split" in tune|holdout) ;; *) fail 'Usage: sudo bash server/replay.sh tune|holdout';; esac
for tool in suricata sha256sum tee cp date; do command -v "$tool" >/dev/null || fail "missing $tool"; done
pcap="evidence/capture-$split/requests.pcap"
[[ -s "$pcap" ]] || fail 'missing/nonempty PCAP required'
out="$PWD/evidence/$split"
[[ ! -e "$out" ]] || fail 'output exists: preserve it; use a NEW extraction directory for a new experiment'
if [[ "$split" == holdout ]]; then
  [[ -f evidence/frozen/rule.rules && -f evidence/frozen/inputs.sha256 && -f evidence/tune/completed.txt ]] || fail 'complete tune and freeze first'
  sha256sum -c evidence/frozen/inputs.sha256 || fail 'frozen rule/config/datasets changed'
  cmp -s evidence/frozen/rule.rules evidence/tune/active.rules || fail 'frozen rule differs from evaluated tune rule'
  source=evidence/frozen/rule.rules
else
  source=server/candidate.rules
fi
mkdir -p "$out"
cp "$source" "$out/active.rules"
sha256sum "$pcap" "$out/active.rules" /etc/suricata/suricata.yaml "data/$split.json" > "$out/inputs.sha256"
suricata -V > "$out/version.txt"
date -u +%FT%TZ > "$out/started.txt"
mkdir "$out/validation"
suricata -T -c /etc/suricata/suricata.yaml -S "$out/active.rules" -l "$out/validation" > "$out/validation.log" 2>&1 || { cat "$out/validation.log"; fail 'validation failed'; }
printf 'suricata -k none -c /etc/suricata/suricata.yaml -S %q -r %q -l %q\n' "$out/active.rules" "$PWD/$pcap" "$out" > "$out/command.txt"
suricata -k none -c /etc/suricata/suricata.yaml -S "$out/active.rules" -r "$PWD/$pcap" -l "$out" 2>&1 | tee "$out/replay.log"
sha256sum -c "$out/inputs.sha256" > "$out/inputs-check.txt" || fail 'inputs changed during replay'
date -u +%FT%TZ > "$out/completed.txt"
echo "REPLAY_COMPLETED split=$split; this does not imply good detection quality"
