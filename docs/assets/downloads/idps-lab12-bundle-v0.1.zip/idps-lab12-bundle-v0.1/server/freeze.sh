#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ $EUID -eq 0 ]] || { echo 'Run: sudo bash server/freeze.sh' >&2; exit 1; }
[[ -f evidence/tune/completed.txt ]] || { echo 'Complete tune replay first' >&2; exit 1; }
[[ ! -e evidence/frozen ]] || { echo 'Frozen version already exists; do not overwrite' >&2; exit 1; }
sha256sum -c evidence/tune/inputs.sha256
mkdir evidence/frozen
cp evidence/tune/active.rules evidence/frozen/rule.rules
sha256sum evidence/frozen/rule.rules /etc/suricata/suricata.yaml data/tune.json data/holdout.json > evidence/frozen/inputs.sha256
date -u +%FT%TZ > evidence/frozen/frozen-at.txt
echo 'RULE_FROZEN: retain first holdout result; hashes do not prove the examples were unseen'
