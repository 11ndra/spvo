IDPS Course — Lab 01 Starter Pack v0.1

Files:
- lab01.rules      — готовое учебное правило SID 1000001
- lab01-report.md  — шаблон отчёта

Rule goal:
Detect the synthetic marker ATTACK-LAB in the HTTP URI of the controlled LabBox traffic.
This rule is a teaching detector, not a production signature and not a real exploit detector.
