# Лабораторная работа №1 — отчёт

ФИО:

Группа:

Дата:

## 1. Топология

Client IP:

Web IP/port:

Observation interface:

Кратко объясните путь трафика:

## 2. Visibility evidence

Команда tcpdump:

Какой трафик наблюдался:

Почему этого достаточно, чтобы подтвердить visibility для данного теста:

## 3. Версия и configuration test

Suricata version/build:

Результат `suricata -T`:

## 4. Negative test

URI:

Alert SID 1000001 present: YES / NO

Что этот результат означает:

## 5. Positive test

URI:

SID:

Signature:

src_ip / dest_ip:

Вставьте короткий JSON-фрагмент alert:

## 6. Интерпретация

Что именно подтверждает полученный alert?

Что этот alert НЕ подтверждает?

## 7. Вывод

Почему наличие firewall не устраняет задачу intrusion detection?

Объясните своими словами: `ALERT ≠ COMPROMISE`.
