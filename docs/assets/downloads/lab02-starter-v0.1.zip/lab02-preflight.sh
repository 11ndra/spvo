#!/usr/bin/env bash
set -u

fail=0
for cmd in suricata jq curl auditctl ausearch ip; do
  if command -v "$cmd" >/dev/null 2>&1; then
    printf '[OK]   %s\n' "$cmd"
  else
    printf '[MISS] %s\n' "$cmd"
    fail=1
  fi
done

for ns in idps-client idps-web; do
  if ip netns list | awk '{print $1}' | grep -qx "$ns"; then
    printf '[OK]   namespace %s\n' "$ns"
  else
    printf '[MISS] namespace %s\n' "$ns"
    fail=1
  fi
done

if ip link show lab-client0 >/dev/null 2>&1; then
  printf '[OK]   interface lab-client0\n'
else
  printf '[MISS] interface lab-client0\n'
  fail=1
fi

exit "$fail"
