# Источники курса

!!! info "Политика источников"
    В курсе действует принцип **«сначала первичные источники»**. Технический факт по возможности опирается на стандарт, RFC, официальную документацию проекта, первичный или близкий к первичному отчёт об инциденте либо исследовательскую публикацию. Архитектурные выводы обозначаются как инженерные рекомендации, а созданные для курса топологии, файлы захвата пакетов (`PCAP`) и сценарии — как синтетический учебный материал.

    **Иерархия подтверждения:** нормативное определение — действующая редакция акта/стандарта; протокол — актуальный RFC; поведение конкретного движка — документация *именно применяемой версии* и эксперимент; инцидент — датированный первичный отчёт; учебные платформы/блоги — вторичный материал для методики и кейсов. Присутствие ссылки в общей библиографии не означает, что каждое утверждение курса независимо подтверждено.

    Для проверки знаний студенту доступны [90 опорных развёрнутых ответов](exam-answers.md) с указанием теоретических разделов, а не только краткие варианты теста.

## Фундамент
- Dorothy E. Denning — *An Intrusion-Detection Model*.
- Stefan Axelsson — *The Base-Rate Fallacy and the Difficulty of Intrusion Detection*.
- NIST SP 800-94 — *Guide to Intrusion Detection and Prevention Systems* (**2007, исторический архитектурный источник**; не выдавать классификацию 2007 года за исчерпывающую современную): https://csrc.nist.gov/pubs/sp/800/94/final

## Базовый контекст кибербезопасности

Эти источники поддерживают модуль о защищаемых активах, угрозах, уязвимостях, риске, базовых защитных функциях и границах технической интерпретации. Они задают терминологическую опору, но не превращаются в структуру курса:

- NIST SP 800-30 Rev. 1, *Guide for Conducting Risk Assessments* — риск, угрозы, уязвимости, вероятность/правдоподобие и воздействие: https://csrc.nist.gov/pubs/sp/800/30/r1/final
- NIST Cybersecurity and Privacy Reference Tool / Glossary — контекстные определения `threat`, `vulnerability`, `risk` и связанных терминов: https://csrc.nist.gov/glossary
- NIST Cybersecurity Framework 2.0 — современная рамка `Govern / Identify / Protect / Detect / Respond / Recover`: https://www.nist.gov/cyberframework
- NIST SP 800-61 Rev. 3, *Incident Response Recommendations and Considerations for Cybersecurity Risk Management* — связь обнаружения, реагирования, восстановления и управления риском: https://csrc.nist.gov/pubs/sp/800/61/r3/final
- Council of Europe, *Convention on Cybercrime (Budapest Convention)* — международный правовой контекст киберпреступности; в курсе используется только как контекст, а не как источник технической классификации IDPS: https://www.coe.int/en/web/cybercrime/the-budapest-convention
- INTERPOL, Cybercrime — международный правоохранительный контекст: https://www.interpol.int/en/Crimes/Cybercrime
- Europol, Internet Organised Crime Threat Assessment (IOCTA) — правоохранительный контекст форм интернет-преступности: https://www.europol.europa.eu/publications-events/main-reports/internet-organised-crime-threat-assessment
- European Commission, Data protection / GDPR — пример правового режима защиты персональных данных; не используется как определение киберпреступности: https://commission.europa.eu/law/law-topic/data-protection_en
- ITU-T X.200 / ISO/IEC 7498-1 — базовая эталонная модель OSI и семь уровней: https://www.itu.int/rec/T-REC-X.200

Четырёхчастная схема «предотвращение → обнаружение → реагирование → восстановление» в Главе 2 является **учебной группировкой для разговора об IDPS**, а не сокращённой версией NIST CSF и не претендует на полноту.

Блоки о киберпреступности, комплексных защитных мерах, OSI, криптографии, безопасности приложений/веб-сервисов и антивирусной защите дают фундамент, необходимый для интерпретации IDPS. При этом главный фокус курса сохраняется: наблюдаемость, логика обнаружения и доказательные границы вывода. Юридические понятия приводятся только в объёме, необходимом для понимания контекста; технический alert не используется как автоматическая правовая квалификация.


## Дополнительная литература по эксплуатации и реагированию

- Joshua Wright, *Dynamic Incident Response: A Framework for Security Teams*, SANS Institute, 2026 — дополнительный источник примеров по источникам данных для обнаружения, метаданным зашифрованного трафика, проверке и первичному разбору событий, определению масштаба инцидента и реагированию. Книга не заменяет RFC, стандарты и официальную документацию и не используется как источник универсальной классификации IDPS.

## Реальные угрозы и действия противника
- MITRE ATT&CK Enterprise — https://attack.mitre.org/
- MITRE D3FEND — https://d3fend.mitre.org/
- CISA KEV — https://www.cisa.gov/known-exploited-vulnerabilities-catalog

## Техническая документация
- Suricata User Guide — https://docs.suricata.io/
- Zeek Documentation — https://docs.zeek.org/en/current/
- Wazuh Documentation — https://documentation.wazuh.com/current/
- Wireshark Documentation — https://www.wireshark.org/docs/
- Wireshark User’s Guide: checksum offloading — https://www.wireshark.org/docs/wsug_html_chunked/ChAdvChecksums.html
- OWASP CRS (Core Rule Set) — официальный пример **конкретного** набора правил обнаружения веб-атак для ModSecurity и совместимых WAF: https://owasp.org/projects/crs . Наличие WAF/CRS не гарантирует исправление дефекта приложения или обнаружение всех атак.
- RFC 9846 — TLS 1.3 — https://www.rfc-editor.org/rfc/rfc9846.html

## Архитектура и стандарты
- NIST SP 800-207 — Zero Trust Architecture.
- PCI DSS v4.0.1.
- Закон Республики Казахстан от 24.11.2015 №418-V: **действующее название — «О кибербезопасности»** (переименование в 2026 году; первоначальное название — «Об информатизации»). Статус и применимую редакцию проверять в ИПС «Әділет»: https://old.adilet.zan.kz/rus/docs/Z1500000418/info . Нормативное упоминание в курсе не заменяет юридический анализ применимости конкретных статей.
- Единые требования, ПП РК №832.
- СТ РК ISO/IEC 27001-2023.


## Реальные случаи и исследования

Эти источники используются там, где они объясняют конкретный механизм, ограничение или способ оценки, а не как самостоятельные «истории атак»:

- Ptacek & Newsham — вставка и уклонение (`insertion/evasion`) и различия интерпретации данных сенсором и конечной системой; английские термины приведены только для связи с терминологией исходной работы;
- Stefan Axelsson — влияние низкой базовой частоты событий на интерпретацию результатов обнаружения;
- отчёты CISA и Microsoft об инцидентах — как источники конкретных случаев, если эпизод действительно демонстрирует разбираемый механизм;
- разбор случая Cisco CSIRT — для примеров архитектуры и эксплуатации IPS.

## Suricata — ЛР №1

Для команд и формата первой лабораторной используются официальные материалы OISF:

- Suricata User Guide — Quickstart: https://docs.suricata.io/en/latest/quickstart.html
- Adding Your Own Rules: https://docs.suricata.io/en/latest/rule-management/adding-your-own-rules.html
- EVE JSON Output: https://docs.suricata.io/en/latest/output/eve/eve-json-output.html
- EVE JSON Format: https://docs.suricata.io/en/latest/output/eve/eve-json-format.html

По состоянию на 19.09.2026 актуальный стабильный выпуск ветки Suricata 8 — **8.0.7 (15.09.2026)**; для ветки Suricata 7 объявлено прекращение поддержки (end of life, EOL). В лаборатории студент всё равно фиксирует фактически установленную версию через `suricata --build-info`, поскольку учебные среды могут обновляться.


## Правила обнаружения и воспроизводимая проверка

Основные технические источники:

- Suricata Rules Format — https://docs.suricata.io/en/latest/rules/intro.html
- Suricata Flow Keywords — https://docs.suricata.io/en/latest/rules/flow-keywords.html
- Suricata HTTP Keywords — https://docs.suricata.io/en/latest/rules/http-keywords.html
- Suricata Payload Keywords / PCRE — https://docs.suricata.io/en/latest/rules/payload-keywords.html
- Suricata Fast Pattern — https://docs.suricata.io/en/latest/rules/fast-pattern-explained.html
- Suricata Thresholding Keywords — https://docs.suricata.io/en/latest/rules/thresholding.html
- OISF suricata-verify — https://github.com/OISF/suricata-verify
- suricata-update Quick Start / Emerging Threats Open — https://github.com/OISF/suricata-update/blob/master/doc/quickstart.rst

Эти источники поддерживают Главу 6 (семантика правил) и Главу 8 (воспроизводимая оценка). ЛР №2 отдельно посвящена сравнению сетевого и хостового источников данных.

## Компоненты и функциональная архитектура IDS/IPS

- NIST SP 800-94 — исторический фундаментальный источник по типичным компонентам IDPS: сенсор/агент (`sensor/agent`), сервер управления (`management server`), сервер базы данных (`database server`) и консоль (`console`). Английские названия здесь приведены для связи с терминологией самого документа.
- NIST SP 800-94 — также источник для различения обнаружения, отчётности и предотвращающих действий: сетевые IDPS могут выполнять локальное воздействие либо инициировать изменение на другом средстве контроля. Это используется как историческая инженерная модель, а не как исчерпывающая современная архитектура.
- Suricata User Guide — конкретная реализация сетевого сбора, анализа и структурированного вывода EVE JSON; не используется как универсальное определение архитектуры всех IDS/IPS.

## ЛР №2 — сетевой и хостовый источники

- Suricata User Guide — запуск NIDS и EVE JSON.
- пользовательские утилиты Linux Audit (`auditctl`, `ausearch`) — системный источник событий конечного узла для учебного эксперимента.
- `auditctl(8)` — https://man7.org/linux/man-pages/man8/auditctl.8.html
- `ausearch(8)` — https://man7.org/linux/man-pages/man8/ausearch.8.html

Linux Audit в ЛР №2 используется только для демонстрации различий телеметрии. Лабораторная не утверждает, что Linux Audit сам по себе является полноценной HIDS-платформой.

## Размещение и точки наблюдения

Основные источники по размещению и точкам наблюдения:

- NIST SP 800-94 — исторический фундаментальный источник по архитектуре сетевых IDPS: выбор места сенсоров, пассивное подключение и подключение в разрыв (`inline`), сетевой ответвитель (`network tap`) и зеркалирование порта коммутатора как способы получения копии трафика пассивным сенсором.
- William Stallings, *Computer Security: Principles and Practice* — учебное описание пассивных NIDS, сетевых IDS/IPS, включённых в разрыв (`inline`), и типовых мест размещения.
- Wireshark User’s Guide, раздел *Checksum Offloading* — техническая основа для оговорок об аппаратной разгрузке вычисления контрольных сумм (`checksum offloading`) при локальном захвате.
- Suricata 8.0.7, *IPS Concept* — конкретный пример IPS-режима, в котором `drop`/`reject` применяются как блокирующие действия при подходящем inline-режиме: https://docs.suricata.io/en/suricata-8.0.7/ips/ips-concept.html
- Suricata 8.0.7, *Setting up IPS/inline for Linux* — конкретный пример влияния механизма очереди на доступность: для NFQUEUE опция `bypass` позволяет пропускать трафик при отсутствии пользовательского обработчика, тогда как без неё пакеты очереди не проходят. Это используется только как иллюстрация инженерного выбора поведения при отказе, а не как универсальная реализация fail-open/fail-closed: https://docs.suricata.io/en/suricata-8.0.7/ips/setting-up-ipsinline-for-linux.html

В главе сознательно не делается универсального вывода «до межсетевого экрана лучше, чем после» или наоборот. Полезность точки определяется тем, какой набор сетевых событий требуется наблюдать для конкретной задачи.

## ЛР №3 — точка наблюдения

ЛР №3 использует синтетический двухмашинный стенд курса:

- `idps-client` — `10.13.37.10/24`;
- `idps-server` — `10.13.37.20/24`;
- отдельный NAT-интерфейс;
- отдельный интерфейс учебной сети `IDPS-LAB`.

Одинаковое правило Suricata запускается поочерёдно на двух интерфейсах. Журнал учебного веб-сервиса используется как независимое подтверждение существования контролируемого запроса. Границы вывода из каждого источника отдельно оговорены в инструкции ЛР №3.

- OISF: выпуск Suricata 8.0.7 — https://suricata.io/2026/09/15/suricata-8-0-7-released/
- OISF: конфигурация Suricata 8.0.7 и проверка контрольных сумм — https://docs.suricata.io/en/suricata-8.0.7/configuration/suricata-yaml.html

## Методы обнаружения

Основные источники по методам обнаружения:

- NIST SP 800-94, §2.3 — исторический фундаментальный источник для сигнатурного обнаружения (`signature-based detection`), обнаружения аномалий (`anomaly-based detection`) и анализа протокола с учётом состояния (`stateful protocol analysis`), а также для тезиса о совместном использовании нескольких подходов. Английские названия приведены только для связи с терминологией документа. Публикация 2007 года не используется как исчерпывающая современная продуктовая классификация.
- руководство по правилам Suricata 8.0.7 — проверка на конкретной реализации: `flow`, `flowbits`, события прикладного уровня и HTTP-ключевые слова показывают, что язык движка правил способен выражать условия над состоянием потока и разобранными полями протокола. Это не превращает синтаксис правила в отдельный метод обнаружения.

Курс не вводит английскую метку `behavioral` («поведенческий») как отдельную четвёртую универсальную методологию. Для случая без базовой модели используется точное описание **фиксированное условие над серией событий**. Аномальное обнаружение отдельно требует модели, профиля или ожидаемого диапазона, относительно которого определяется отклонение.

- NIST SP 800-94 — https://csrc.nist.gov/pubs/sp/800/94/final
- Suricata 8.0.7 flow keywords — https://docs.suricata.io/en/suricata-8.0.7/rules/flow-keywords.html
- Suricata 8.0.7 generic app-layer keywords — https://docs.suricata.io/en/suricata-8.0.7/rules/app-layer.html
- Suricata 8.0.7 HTTP-ключевые слова — https://docs.suricata.io/en/suricata-8.0.7/rules/http-keywords.html

## ЛР №4 — один набор данных, разные основания аналитического решения

ЛР №4 является **синтетической инженерной моделью и контролируемым экспериментом**. Один контролируемый HTTP-сценарий формирует один JSONL-журнал, после чего четыре предоставленных режима анализируют неизменный набор событий по разным основаниям:

- точное совпадение с маркером — сигнатурное условие;
- синтетическая машина состояний `IDLE → OPEN → IDLE` — анализ состояния;
- `>= 5 /catalog` за `2 s` — фиксированное условие над серией событий без базового профиля;
- отношение медианных интервалов базового профиля и всплеска — аномальное сравнение с базовой моделью.

`START → DATA → END` не является стандартом HTTP, а поле `phase` — служебная метка контролируемого эксперимента, не индикатор атаки. Этот сценарий используется только как синтетическая модель для разделения оснований принятия решения.

Параллельно Suricata наблюдает тот же HTTP-маркер `/download/LAB4-KNOWN-BAD` на LAB-интерфейсе и применяет готовое учебное правило `SID 1000005`. Этот мост нужен только для связи прозрачной Python-модели с реальным EVE JSON. Правило остаётся готовым: его проектирование и изменение относятся к ЛР №5. HTTP-событие и alert подтверждают факт наблюдения/совпадения условия, но не доказывают компрометацию; `action: allowed` отдельно показывает, что alert в этой работе не означает предотвращение.

## Правила и их структура

Основной технический источник раздела о правилах — официальная документация Suricata 8.x. Suricata используется как конкретная реализация обнаружения на основе правил; её синтаксис не обобщается на все IDS/IPS.

- Suricata Rules Format — https://docs.suricata.io/en/suricata-8.0.7/rules/intro.html
- Suricata Meta Keywords — https://docs.suricata.io/en/suricata-8.0.7/rules/meta.html
- Suricata Flow Keywords — https://docs.suricata.io/en/suricata-8.0.7/rules/flow-keywords.html
- Suricata HTTP Keywords — https://docs.suricata.io/en/suricata-8.0.7/rules/http-keywords.html
- Suricata Thresholding Keywords — https://docs.suricata.io/en/suricata-8.0.7/rules/thresholding.html
- Suricata Global Thresholds / suppress — https://docs.suricata.io/en/suricata-8.0.7/configuration/global-thresholds.html
- Suricata configuration / action order — https://docs.suricata.io/en/suricata-8.0.7/configuration/suricata-yaml.html

Сквозной пример раздела о правилах — правило `SID 1000001` из ЛР №1. Оно является **синтетической инженерной моделью**: маркер `ATTACK-LAB` создан для учебного стенда и не является индикатором реальной атаки.

Ключевые границы:

- действие, заголовок и параметры (`action/header/options`) — элементы формата правила Suricata, а не универсальная грамматика любой IDPS;
- `http.uri` выбирает нормализованное представление URI, тогда как `http.uri.raw` предназначен для ненормализованного URI;
- `flow` и `flowbits` предоставляют контекст/состояние, но отдельное ключевое слово не определяет методологию обнаружения;
- `msg`, `sid`, `rev`, `classtype` и `priority` относятся к идентификации/описанию результата и не заменяют условие совпадения;
- ограничение частоты выдачи результатов (`thresholding`) не исправляет логическую причину слишком широкого условия обнаружения;
- действие `drop` имеет предотвращающий эффект только в подходящем IPS/inline-режиме.

## ЛР №5 — изменение условия правила

ЛР №5 является **синтетической инженерной моделью и контролируемым экспериментом**. На одном стенде студент выполняет две серии положительных и отрицательных тестов для `SID 1000005`:

- исходное условие: `http.uri; content:"/LAB5-ALPHA";`;
- изменённое условие: `http.uri; content:"/LAB5-BETA";`.

!!! warning "Область уникальности учебного SID"
    ЛР №4 и ЛР №5 повторно используют `SID 1000005` в **разных, отдельно загружаемых** наборах правил и независимых прогонах. При совместном использовании этих ruleset возникает коллизия идентификатора: правила необходимо предварительно развести по SID. Анализируя EVE разных лабораторных, сопоставляйте не только SID, но и конкретный прогон, загруженный файл правил, `msg` и `rev`. Существующие лабораторные №1–5 и их архивы намеренно не изменяются.

`rev` увеличивается как метаданные версии и не считается вторым содержательным условием обнаружения. HTTP-ответ учебного приложения используется как независимое подтверждение существования запроса, а EVE JSON — как подтверждение результата конкретного правила. Отсутствие оповещения (`alert`) не трактуется как отсутствие трафика.

Технические источники:

- Suricata Rules Format — https://docs.suricata.io/en/suricata-8.0.7/rules/intro.html
- Suricata HTTP Keywords — https://docs.suricata.io/en/suricata-8.0.7/rules/http-keywords.html
- Suricata EVE JSON Output — https://docs.suricata.io/en/suricata-8.0.7/output/eve/eve-json-output.html



## Ошибки, слепые зоны и границы наблюдаемости

Основные источники по ограничениям, FP/FN и границам наблюдаемости:

- NIST SP 800-94 — исторический фундаментальный источник по ограничениям IDPS, ложноположительным и ложноотрицательным результатам и эксплуатационным факторам. Документ 2007 года не используется как исчерпывающее описание современных продуктов: https://csrc.nist.gov/pubs/sp/800/94/final
- RFC 9846, TLS 1.3 — актуальная спецификация, заменившая RFC 8446; после `ServerHello` сообщения процедуры установления TLS-соединения (`handshake`) защищаются шифрованием, что используется для объяснения границы видимости сетевого сенсора: https://www.rfc-editor.org/rfc/rfc9846.html
- RFC 9849, зашифрованный `ClientHello` (Encrypted Client Hello, ECH) — актуальная спецификация о том, что SNI и другие поля `ClientHello` могут быть защищены: https://www.rfc-editor.org/rfc/rfc9849.html
- Suricata 8.0.7 EVE Index — `stats.capture`, `kernel_drops`, счётчики политики обработки исключительных ситуаций (`exception-policy`), `alert_queue_overflow`, `alerts_suppressed`, метаданные TLS и другие диагностические поля: https://docs.suricata.io/en/suricata-8.0.7/appendix/eve-index.html
- Suricata 8.0.7 Flow Keywords — направление, состояние потока, `only_stream`, `only_frag` и связанный контекст: https://docs.suricata.io/en/suricata-8.0.7/rules/flow-keywords.html
- Suricata TLS Keywords — пример конкретных TLS-представлений, доступных движку при соответствующей видимости: https://docs.suricata.io/en/suricata-8.0.7/rules/tls-keywords.html

Глава не учит техникам обхода IDS/IPS. Фрагментация, восстановление потока (`reassembly`), неоднозначность представлений и шифрование рассматриваются только как инженерные причины, по которым наблюдаемое событие, данные сенсора и решение детектора могут расходиться.


## Оценка эффективности и доказательная отчётность

Основные источники по оценке эффективности и предотвращению:

- NIST SP 800-94 — исторический фундаментальный источник по оценке, ложноположительным и ложноотрицательным результатам, настройке и эксплуатационным факторам IDPS. Документ 2007 года используется как базовый инженерный источник, а не как описание современной продуктовой классификации: https://csrc.nist.gov/pubs/sp/800/94/final
- Stefan Axelsson — *The Base-Rate Fallacy and the Difficulty of Intrusion Detection*; источник для объяснения того, как низкая базовая частота событий влияет на долю подтверждённых положительных решений (`precision`) системы обнаружения: https://doi.org/10.1145/357830.357849
- Suricata 8.0.7 EVE Index — конкретные счётчики для проверки состояния захвата данных, ресурсов и вывода реализации (`kernel_drops`, счётчики `exception-policy`, `alert_queue_overflow`, `alerts_suppressed` и др.): https://docs.suricata.io/en/suricata-8.0.7/appendix/eve-index.html
- Suricata 8.0.7, *IPS Concept* — конкретная реализация, показывающая, что IPS-режим, правила `drop`/`reject`, режим inline и политики исключительных ситуаций являются отдельными настраиваемыми аспектами, которые нельзя сворачивать в утверждение «alert = блокирование»: https://docs.suricata.io/en/suricata-8.0.7/ips/ips-concept.html

Глава различает:

- оценку конкретного правила;
- оценку детектора/движка;
- оценку защитного контроля как сквозной цепочки;
- качество обнаружения и отдельно качество предотвращения/исполнительного воздействия;
- качество классификации и эксплуатационные характеристики: наблюдаемость, способность работать при заданной нагрузке, задержку и доставку результата.

## Протоколы, приложения и зашифрованный трафик

### Первичные протокольные источники

- RFC 9846 — актуальная спецификация TLS 1.3, заменившая RFC 8446: https://www.rfc-editor.org/rfc/rfc9846.html
- RFC 9849 — зашифрованный `ClientHello` (Encrypted Client Hello, ECH), защита внутреннего `ClientHello`, включая SNI и другие чувствительные поля: https://www.rfc-editor.org/rfc/rfc9849.html
- RFC 9000 — QUIC как защищённый мультиплексированный транспорт поверх UDP: https://www.rfc-editor.org/rfc/rfc9000.html
- RFC 9114 — HTTP/3, отображение семантики HTTP на QUIC: https://www.rfc-editor.org/rfc/rfc9114.html
- RFC 9110 — *HTTP Semantics*, общая семантика HTTP независимо от конкретного сетевого представления протокола: https://www.rfc-editor.org/rfc/rfc9110.html
- RFC 1035 и его обновления — базовая модель DNS: https://www.rfc-editor.org/rfc/rfc1035.html
- RFC 7858 — DNS поверх TLS (DNS over TLS, DoT): https://www.rfc-editor.org/rfc/rfc7858.html
- RFC 8484 — DNS поверх HTTPS (DNS over HTTPS, DoH): https://www.rfc-editor.org/rfc/rfc8484.html
- RFC 9250 — DNS поверх QUIC (DNS over QUIC, DoQ): https://www.rfc-editor.org/rfc/rfc9250.html
- RFC 4253 и его обновления — спецификация транспортного уровня SSH (*SSH Transport Layer Protocol*): https://www.rfc-editor.org/rfc/rfc4253.html
- Microsoft Open Specifications `[MS-SMB2]` — SMB Protocol Versions 2 and 3: https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-smb2/5606ad47-5ee0-437a-817e-70c366052962
- Microsoft Learn, *SMB features in Windows and Windows Server* — SMB поверх QUIC (`SMB over QUIC`) для SMB 3.1.1 в актуальных Windows-сценариях: https://learn.microsoft.com/en-us/windows-server/storage/file-server/smb-feature-descriptions

### Криптографический и сетевой фундамент

- ITU-T X.200 / ISO/IEC 7498-1 — эталонная модель OSI и уровни взаимодействия: https://www.itu.int/rec/T-REC-X.200
- NIST FIPS 197 — Advanced Encryption Standard (AES): https://csrc.nist.gov/pubs/fips/197/final
- NIST SP 800-56B Rev. 2 — рекомендации по парным механизмам на основе RSA в контексте установления ключевого материала: https://csrc.nist.gov/pubs/sp/800/56/b/r2/final
- NIST SP 800-186 — параметры эллиптических кривых для федеральных криптографических стандартов: https://csrc.nist.gov/pubs/sp/800/186/final

Эти документы используются только для базовых понятий и примеров алгоритмов. Курс не является курсом по проектированию криптографических протоколов.

### Документация реализации

- Suricata 8.0.7 Generic App Layer Keywords — состояния определения прикладного протокола и сопоставление условий по данным прикладного уровня: https://docs.suricata.io/en/suricata-8.0.7/rules/app-layer.html
- Suricata 8.0.7 Flow Keywords — контекст сетевого потока и представление восстановленного потока/фрагментов: https://docs.suricata.io/en/suricata-8.0.7/rules/flow-keywords.html
- Suricata 8.0.7 EVE JSON Format — записи HTTP/DNS/TLS/SMB/SSH и других протоколов в структурированном выводе EVE JSON: https://docs.suricata.io/en/suricata-8.0.7/output/eve/eve-json-format.html

Глава использует DNS, HTTP, TLS, QUIC, SSH и SMB как контрастные примеры того, как меняется доступное представление данных. Она не задаёт универсальную последовательность обработки и не является заменой отдельного курса по сетевым протоколам. Suricata используется как конкретный проверяемый пример реализации, а не как источник универсальной классификации IDPS.

## Контекстный модуль — прикладная и веб-безопасность

Модуль даёт прикладной контекст, необходимый для понимания телеметрии и границ IDPS, и не заменяет отдельную дисциплину по безопасной разработке.

Основные источники:

- OWASP Application Security Verification Standard (ASVS) 5.0.0 — требования к проверке технических контролей веб-приложений: https://owasp.org/projects/asvs
- OWASP Web Security Testing Guide — систематизация тестирования веб-приложений: https://owasp.org/www-project-web-security-testing-guide/
- OWASP Cheat Sheet Series — первичные практические рекомендации по SQL Injection Prevention, Cross Site Scripting Prevention, CSRF Prevention, Authentication и Session Management: https://cheatsheetseries.owasp.org/
- OWASP API Security Project / API Security Top 10 2023 — контекст объектной/функциональной авторизации, аутентификации и злоупотребления ресурсами API: https://owasp.org/projects/api-security-project
- NIST SP 800-218, Secure Software Development Framework (SSDF) Version 1.1 — интеграция практик безопасной разработки в жизненный цикл ПО: https://csrc.nist.gov/pubs/sp/800/218/final
- RFC 9700, Best Current Practice for OAuth 2.0 Security — актуальные рекомендации безопасности OAuth 2.0: https://www.rfc-editor.org/rfc/rfc9700.html
- OpenID Connect Core 1.0 incorporating errata set 2 — аутентификация и identity layer поверх OAuth 2.0: https://openid.net/specs/openid-connect-core-1_0-errata2.html
- RFC 9110 — семантика HTTP: https://www.rfc-editor.org/rfc/rfc9110.html
- RFC 9846 — TLS 1.3: https://www.rfc-editor.org/rfc/rfc9846.html

Ключевая граница модуля: наблюдение подозрительного HTTP-представления не является доказательством успешной эксплуатации приложения. Для более сильного вывода требуются независимые прикладные/хостовые/БД-свидетельства.

## Контекстный модуль — защита конечных систем

Основные источники:

- NIST SP 800-83 Rev. 1 — исторический фундамент по предотвращению и обработке инцидентов, связанных с вредоносным ПО: https://csrc.nist.gov/pubs/sp/800/83/r1/final
- NIST SP 800-94 — хостовые IDPS и границы источников данных: https://csrc.nist.gov/pubs/sp/800/94/final
- MITRE ATT&CK Enterprise — примеры поведения на конечных системах и связанных источников телеметрии: https://attack.mitre.org/

Классические термины «сканер / монитор / фильтр / иммунизатор» рассматриваются как учебная историческая классификация функций, а не как обязательные современные продуктовые классы. Современный анализ строится по фактическим источникам данных и возможностям продукта.

## Контекстный модуль — профессиональная практика специалиста

Модуль не задаёт единственную карьерную траекторию и не ранжирует профессии или сертификации. Он связывает учебные результаты курса с задачами, знаниями, навыками, практикой и профессиональной ответственностью.

Основные источники:

- NIST SP 800-181 Rev. 1, Workforce Framework for Cybersecurity (NICE Framework) — общий язык для описания кибербезопасностной работы через задачи, знания и навыки: https://csrc.nist.gov/pubs/sp/800/181/r1/final
- NIST NICE Framework Resource Center, Current Versions — актуальные компоненты NICE Framework (рабочие роли, competency areas, Task/Knowledge/Skill statements): https://www.nist.gov/itl/applied-cybersecurity/nice/nice-framework-resource-center/nice-framework-current-versions
- NIST SP 800-61 Rev. 3 — современный контекст реагирования на инциденты и связи с управлением киберриском: https://csrc.nist.gov/pubs/sp/800/61/r3/final
- NIST SP 800-86 — фундаментальная модель интеграции forensic techniques в incident response; используется только для общих принципов сохранения и анализа артефактов, а не как актуальная исчерпывающая методика: https://csrc.nist.gov/pubs/sp/800/86/final
- NIST SP 800-218 — безопасная разработка как часть профессиональной практики: https://csrc.nist.gov/pubs/sp/800/218/final

Стандарты и сертификации в модуле рассматриваются как разные способы структурирования требований и подтверждения определённых знаний/навыков. Ни один из них не используется как самостоятельное доказательство универсальной практической компетентности.

## Эксплуатация и жизненный цикл возможностей обнаружения

Глава продолжает модель Глав 8–9: проверенная возможность обнаружения относится к конкретному состоянию системы и после существенного изменения требует повторного подтверждения затронутой части причинной цепочки. Жизненный цикл в главе — **учебная инженерная модель**, а не универсальный нормативный процесс для всех IDPS.

Основные источники:

- NIST SP 800-94 — историческая инженерная основа по проектированию, внедрению, конфигурированию, защите, мониторингу и сопровождению IDPS. Документ 2007 года не используется как актуальная продуктовая классификация: https://csrc.nist.gov/pubs/sp/800/94/final
- Suricata 8.0.7, Rule Management with Suricata-Update — получение и управление наборами правил конкретной реализации: https://docs.suricata.io/en/suricata-8.0.7/rule-management/suricata-update.html
- Suricata 8.0.7, Rule Reloads — повторная загрузка правил во время работы, затрагиваемые ресурсы и переключение движка обнаружения: https://docs.suricata.io/en/suricata-8.0.7/rule-management/rule-reload.html
- Suricata 8.0.7, Statistics — эксплуатационные счётчики и признаки потерь/разрывов обработки: https://docs.suricata.io/en/suricata-8.0.7/performance/statistics.html
- Suricata 8.0.7, Interacting via Unix Socket — получение рабочей версии, статистики интерфейса и состояния набора правил: https://docs.suricata.io/en/suricata-8.0.7/unix-socket.html
- Suricata 8.0.7, EVE JSON Output — конфигурация вывода, статистики и буферизации событий: https://docs.suricata.io/en/suricata-8.0.7/output/eve/eve-json-output.html

Дополнительная книга Joshua Wright, *Dynamic Incident Response: A Framework for Security Teams* (SANS Institute, 2026) используется только для примеров постоянной настройки детекторов, поддержания готовности и проверки покрытий. Её модель реагирования и терминология не задают структуру жизненного цикла IDPS в курсе.

Ключевые границы:

- успешное получение нового файла правил не доказывает его активацию в рабочем движке;
- успешная активация не доказывает ожидаемый результат на нужном представлении данных;
- статус запущенного процесса не доказывает получение нужного трафика, отсутствие потерь или доставку результата;
- эксплуатационный счётчик поддерживает вывод о конкретном наблюдаемом состоянии, но не устанавливает автоматически причину отдельного FP/FN;
- команды Suricata приводятся только как пример конкретной реализации и не считаются универсальными командами IDPS.

## Сопоставление нескольких источников и контекст угроз

Глава продолжает доказательную модель курса: корреляция рассматривается как формализованное условие над несколькими наблюдениями, а не как способ автоматически получить «единую истину». Каждый источник сохраняет собственное происхождение, представление и границу доказательности.

Основные источники:

- OASIS, *STIX Version 2.1* — стандарт машинно-читаемого представления информации об угрозах: https://docs.oasis-open.org/cti/stix/v2.1/stix-v2.1.html
- OASIS, *TAXII Version 2.1* — прикладной протокол обмена информацией об угрозах: https://docs.oasis-open.org/cti/taxii/v2.1/taxii-v2.1.html
- NIST SP 800-150, *Guide to Cyber Threat Information Sharing* (2016) — фундаментальная общая модель информации о киберугрозах, индикаторов, источников и обмена; современные детали реализации проверяются по более новым первичным источникам: https://csrc.nist.gov/pubs/sp/800/150/final
- NIST SP 800-61 Rev. 3 — актуальные рекомендации 2025 года по реагированию; используется только для связи информации об угрозах и совместного анализа с последующими процессами реагирования, а не как структура главы: https://csrc.nist.gov/pubs/sp/800/61/r3/final
- MITRE ATT&CK, *Get Started / FAQ* — ATT&CK как база знаний о поведении противника, а не источник локальной телеметрии: https://attack.mitre.org/resources/ и https://attack.mitre.org/resources/faq/
- MITRE ATT&CK, *ATT&CK Data & Tools* — официальное представление ATT&CK в STIX и доступ через TAXII: https://attack.mitre.org/resources/working-with-attack/
- Suricata 8.0.7, *EVE JSON Format* — `flow_id`, `tx_id` и сопоставление записей EVE внутри модели Suricata: https://docs.suricata.io/en/suricata-8.0.7/output/eve/eve-json-format.html
- Suricata 8.0.7, *suricata.yaml* — Community ID как дополнительный механизм сопоставления сетевых потоков между совместимыми средствами: https://docs.suricata.io/en/suricata-8.0.7/configuration/suricata-yaml.html
- Zeek 9.0.0 LTS, `conn.log` и руководство по журналам — `uid` как внутренний идентификатор соединения и необязательное поле `community_id`: https://docs.zeek.org/en/lts/scripts/base/protocols/conn/main.zeek.html и https://docs.zeek.org/en/lts/tutorial/logs.html

Дополнительная книга Joshua Wright, *Dynamic Incident Response: A Framework for Security Teams* (SANS Institute, 2026) используется для эксплуатационных примеров сочетания источников, применения информации об угрозах и расширения области проверки. Она не задаёт универсальную классификацию корреляции и не заменяет первичные стандарты/официальную документацию.

Ключевые границы главы:

- агрегация записей не равна доказанной связи между ними;
- временная близость не доказывает причинность;
- `flow_id` Suricata и `uid` Zeek являются внутренними идентификаторами своих реализаций;
- Community ID помогает связывать совместимые сетевые представления, но не является универсальным идентификатором события после NAT, прокси или других преобразований;
- совпадение индикатора добавляет внешний контекст, но не доказывает компрометацию или атрибуцию;
- STIX описывает структуру информации, TAXII — механизм обмена;
- ATT&CK является базой знаний о поведении противника, а не первичным источником событий.


## Архитектура, интеграция и современный контекст IDS/IPS

- NIST SP 800-94 — исторический фундаментальный источник по архитектуре IDPS, распределённым компонентам, журналированию, управлению и эксплуатации: https://csrc.nist.gov/pubs/sp/800/94/final
- NIST SP 800-150, *Guide to Cyber Threat Information Sharing* — общая модель cyber threat information и обмена: https://csrc.nist.gov/pubs/sp/800/150/final
- MISP Project Documentation — официальная документация открытой платформы обмена и управления threat intelligence: https://misp-project.org/documentation/
- OpenCTI Documentation — официальная документация платформы управления knowledge/observables/threat intelligence: https://docs.opencti.io/latest/
- PCI DSS v4.0.1, Requirement 11.5.1 — прямой пример требований к intrusion-detection/intrusion-prevention techniques, мониторингу периметра и критических точек CDE, alerting и актуальности engines/baselines/signatures: https://www.pcisecuritystandards.org/document_library/
- NIST SP 800-53 Rev. 5, control SI-4 System Monitoring — системный мониторинг и control enhancements, включая intrusion detection, automated analysis, alerts, encrypted communications visibility, traffic anomalies и correlation: https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

Упоминание конкретных продуктов и платформ в Главе 8A приведено как иллюстрация роли и архитектуры. Оно не означает рейтинг, рекомендацию производителя или функциональную эквивалентность продуктов.
